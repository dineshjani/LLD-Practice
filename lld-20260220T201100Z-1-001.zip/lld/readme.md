this repo will have a collection of lld problems and solutions. we will be using python to solve the problems. will follow the design principles and patterns.
## Project Structure
problems/
    - problem1/
        - problem1.py
        - problem1.md
    - problem2/
        - problem2.py
        - problem2.md