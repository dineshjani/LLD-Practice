import sys
import os
import time

# Add the parent directory to the path so we can import the package
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.broker.message_broker import MessageBroker
from src.broker.partitioners import KeyHashPartitioner
from src.utils.logging_config import configure_logging  

def key_partitioning_example():
    """Example demonstrating key-based partitioning"""
    # Configure logging
    configure_logging()
    
    # Create broker with key hash partitioner
    broker = MessageBroker(partitioner=KeyHashPartitioner())
    
    # Create a topic with multiple partitions
    broker.create_topic("orders", num_partitions=5)
    
    # Create publisher
    publisher = broker.register_publisher("order-service")
    
    # Create subscriber
    subscriber = broker.register_subscriber("order-processor")
    subscriber.subscribe("orders")
    
    # Publish messages with different keys
    customer_ids = ["customer-1", "customer-2", "customer-3", "customer-4"]
    
    # Send multiple messages for each customer
    for _ in range(3):
        for customer_id in customer_ids:
            # Use customer ID as the message key
            publisher.publish(
                "orders", 
                {"customer_id": customer_id, "amount": 100}, 
                key=customer_id
            )
    
    # Wait for processing
    time.sleep(1)
    
    # Get topic stats
    stats = broker.get_topic_stats()
    print("\nTopic Statistics:")
    print(f"orders: {stats['orders']}")
    
    # Check partition distribution
    topic = broker.topics["orders"]
    print("\nPartition Distribution:")
    for i, partition in enumerate(topic.partitions):
        print(f"Partition {i}: {partition.get_message_count()} messages")
    
    # Verify that messages with the same key went to the same partition
    print("\nVerifying key-based routing:")
    key_to_partition = {}
    
    # Poll messages and check their partitions
    messages = broker.poll_messages(subscriber.subscriber_id, "orders", batch_size=100)
    
    for message in messages:
        if message.key not in key_to_partition:
            key_to_partition[message.key] = message.partition
        else:
            # Verify same key went to same partition
            assert key_to_partition[message.key] == message.partition, \
                f"Key {message.key} was routed to different partitions"
    
    # Print key to partition mapping
    for key, partition in key_to_partition.items():
        print(f"Key '{key}' -> Partition {partition}")
    
    print("\nKey-based partitioning test passed!")
    broker.shutdown()

if __name__ == "__main__":
    key_partitioning_example() 