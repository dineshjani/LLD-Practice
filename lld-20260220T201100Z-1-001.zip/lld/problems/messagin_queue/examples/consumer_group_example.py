import sys
import os
import time
import threading

# Add the parent directory to the path so we can import the package
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.broker.message_broker import MessageBroker
from src.utils.logging_config import configure_logging

def consumer_group_example():
    """Example demonstrating consumer groups"""
    # Configure logging
    configure_logging()
    
    # Create broker
    broker = MessageBroker()
    
    # Create a topic with multiple partitions
    broker.create_topic("orders", num_partitions=8)
    
    # Create publisher
    publisher = broker.register_publisher("order-service")
    
    # Create multiple subscribers in the same consumer group
    subscribers = []
    message_counts = {}
    message_lock = threading.Lock()
    
    # Create a message handler that counts messages
    def create_handler(subscriber_id):
        def handler(message):
            with message_lock:
                if subscriber_id not in message_counts:
                    message_counts[subscriber_id] = 0
                message_counts[subscriber_id] += 1
            print(f"{subscriber_id} processing message: {message.payload} from partition {message.partition}")
            time.sleep(0.01)  # Simulate processing time
        return handler
    
    # Create 3 subscribers in the same group
    for i in range(3):
        subscriber_id = f"order-processor-{i}"
        subscriber = broker.register_subscriber(subscriber_id)
        
        # Subscribe to the topic as part of the consumer group
        subscriber.subscribe_with_group(
            "orders", 
            "order-processors-group", 
            create_handler(subscriber_id)
        )
        
        subscribers.append(subscriber)
    
    # Publish messages
    for i in range(100):
        # Use order ID as key for consistent routing
        order_id = f"order-{i}"
        publisher.publish(
            "orders", 
            {"order_id": order_id, "amount": 100 + i},
            key=order_id
        )
    
    # Wait for processing
    time.sleep(3)
    
    # Print message counts
    print("\nMessage counts by subscriber:")
    total = 0
    for subscriber_id, count in message_counts.items():
        print(f"{subscriber_id}: {count} messages")
        total += count
    
    print(f"\nTotal messages processed: {total}")
    print(f"Total messages published: 100")
    
    # Get consumer group info
    group = broker.get_consumer_group("order-processors-group")
    print("\nPartition assignments:")
    for subscriber_id in [s.subscriber_id for s in subscribers]:
        partitions = group.get_assigned_partitions(subscriber_id, "orders")
        print(f"{subscriber_id}: {partitions}")
    
    # Shutdown
    broker.shutdown()

if __name__ == "__main__":
    consumer_group_example() 