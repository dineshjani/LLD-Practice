import sys
import os
import time

# Add the parent directory to the path so we can import the package
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.broker.message_broker import MessageBroker
from src.utils.logging_config import configure_logging

def basic_usage_example():
    # Configure logging
    configure_logging()
    
    # Create broker
    broker = MessageBroker()
    
    # Create topics
    broker.create_topic("orders", num_partitions=3)
    broker.create_topic("notifications", num_partitions=2)
    
    # Create publishers
    order_publisher = broker.register_publisher("order-service")
    notification_publisher = broker.register_publisher("notification-service")
    
    # Create subscribers
    order_processor = broker.register_subscriber("order-processor")
    email_service = broker.register_subscriber("email-service")
    analytics_service = broker.register_subscriber("analytics-service")
    
    # Define message handlers
    def process_order(message):
        print(f"Processing order: {message.payload}")
    
    def send_email(message):
        print(f"Sending email for: {message.payload}")
    
    def log_analytics(message):
        print(f"Logging analytics: {message.payload}")
    
    # Subscribe to topics with handlers
    order_processor.subscribe("orders", process_order)
    email_service.subscribe("notifications", send_email)
    analytics_service.subscribe("orders", log_analytics)
    analytics_service.subscribe("notifications", log_analytics)
    
    # Publish messages
    for i in range(5):
        order_id = f"ORD-{1000 + i}"
        order_publisher.publish("orders", {"order_id": order_id, "amount": 100 * (i + 1)})
        notification_publisher.publish("notifications", {"type": "order_created", "order_id": order_id})
    
    # Let messages be processed
    time.sleep(1)
    
    # Print stats
    print("\nTopic Statistics:")
    for topic, stats in broker.get_topic_stats().items():
        print(f"{topic}: {stats}")
    
    # Shutdown
    broker.shutdown()

if __name__ == "__main__":
    basic_usage_example()
