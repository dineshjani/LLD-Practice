import sys
import os
import time
import threading

# Add the parent directory to the path so we can import the package
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.broker.message_broker import MessageBroker
from src.utils.logging_config import configure_logging

def concurrency_test():
    """Test concurrent publishers and subscribers"""
    # Configure logging
    configure_logging()
    
    # Create broker
    broker = MessageBroker()
    broker.create_topic("test-topic", num_partitions=5)
    
    # Create multiple publishers
    publishers = [broker.register_publisher(f"pub-{i}") for i in range(5)]
    
    # Create multiple subscribers
    subscribers = [broker.register_subscriber(f"sub-{i}") for i in range(3)]
    
    # Message counters for verification
    message_counts = {sub.subscriber_id: 0 for sub in subscribers}
    counter_lock = threading.Lock()
    
    # Message handler that counts messages
    def count_message(subscriber_id):
        def handler(message):
            nonlocal message_counts
            with counter_lock:
                message_counts[subscriber_id] += 1
            time.sleep(0.001)  # Simulate processing time
        return handler
    
    # Subscribe all subscribers to the topic
    for sub in subscribers:
        sub.subscribe("test-topic", count_message(sub.subscriber_id))
    
    # Publish messages concurrently
    def publish_messages(publisher, count):
        for i in range(count):
            publisher.publish("test-topic", f"Message {i} from {publisher.publisher_id}")
            time.sleep(0.001)  # Small delay
    
    # Start publisher threads
    threads = []
    messages_per_publisher = 100
    for pub in publishers:
        thread = threading.Thread(target=publish_messages, args=(pub, messages_per_publisher))
        threads.append(thread)
        thread.start()
    
    # Wait for all publishers to finish
    for thread in threads:
        thread.join()
    
    # Wait for processing to complete
    time.sleep(2)
    
    # Verify results
    total_messages = len(publishers) * messages_per_publisher
    print(f"\nTotal messages published: {total_messages}")
    
    for sub_id, count in message_counts.items():
        print(f"{sub_id} received {count} messages")
        assert count == total_messages, f"Expected {total_messages} messages, got {count}"
    
    print("Concurrency test passed!")
    broker.shutdown()

if __name__ == "__main__":
    concurrency_test()
