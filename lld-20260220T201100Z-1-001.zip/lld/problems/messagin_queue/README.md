messaging_queue/
├── README.md
├── src/
│   ├── __init__.py
│   ├── core/
│   │   ├── __init__.py
│   │   ├── message.py
│   │   ├── topic.py
│   │   └── partition.py
│   ├── broker/
│   │   ├── __init__.py
│   │   ├── message_broker.py
│   │   └── delivery_tracker.py
│   ├── clients/
│   │   ├── __init__.py
│   │   ├── publisher.py
│   │   └── subscriber.py
│   ├── interfaces/
│   │   ├── __init__.py
│   │   ├── broker_interface.py
│   │   ├── publisher_interface.py
│   │   └── subscriber_interface.py
│   └── utils/
│       ├── __init__.py
│       └── logging_config.py
├── examples/
│   ├── __init__.py
│   ├── basic_usage.py
│   └── concurrency_test.py
└── tests/
    ├── __init__.py
    ├── test_broker.py
    ├── test_publisher.py
    └── test_subscriber.py

## Design Principles

This implementation follows SOLID principles:

- **Single Responsibility Principle**: Each class has a single responsibility
- **Open/Closed Principle**: Components are open for extension but closed for modification
- **Liskov Substitution Principle**: Interfaces can be substituted without affecting behavior
- **Interface Segregation Principle**: Specific interfaces for publishers and subscribers
- **Dependency Inversion Principle**: High-level modules depend on abstractions

## Design Patterns

- **Observer Pattern**: For publisher-subscriber communication
- **Factory Method**: For creating publishers and subscribers
- **Strategy Pattern**: For message routing and partition selection
- **Command Pattern**: Messages encapsulate operations
