import threading
from typing import List, Dict
import logging
from .message import Message

logger = logging.getLogger("MessageQueue")

class Partition:
    """Represents a partition within a topic"""
    def __init__(self, topic_name: str, partition_id: int):
        self.topic_name = topic_name
        self.partition_id = partition_id
        self.messages = []  # List of messages in order
        self.lock = threading.RLock()  # For thread-safe operations
        self.offset_map = {}  # Maps subscriber_id to current offset
        logger.info(f"Created partition {partition_id} for topic {topic_name}")
    
    def add_message(self, message: Message) -> None:
        """Add a message to this partition"""
        with self.lock:
            self.messages.append(message)
            logger.debug(f"Added message {message.id} to {self.topic_name}:{self.partition_id}")
    
    def get_messages(self, subscriber_id: str, batch_size: int = 10) -> List[Message]:
        """Get messages for a subscriber starting from their current offset"""
        with self.lock:
            # Initialize offset if this is a new subscriber
            if subscriber_id not in self.offset_map:
                self.offset_map[subscriber_id] = 0
            
            current_offset = self.offset_map[subscriber_id]
            
            # No new messages
            if current_offset >= len(self.messages):
                return []
            
            # Get batch of messages
            end_offset = min(current_offset + batch_size, len(self.messages))
            messages_to_return = self.messages[current_offset:end_offset]
            
            # Update offset
            self.offset_map[subscriber_id] = end_offset
            
            return messages_to_return
    
    def get_message_count(self) -> int:
        """Get the total number of messages in this partition"""
        with self.lock:
            return len(self.messages)
    
    def get_subscriber_offset(self, subscriber_id: str) -> int:
        """Get the current offset for a subscriber"""
        with self.lock:
            return self.offset_map.get(subscriber_id, 0)
    
    def get_consumer_lag(self, subscriber_id: str) -> int:
        """Calculate how far behind a subscriber is from the latest message"""
        with self.lock:
            # If subscriber hasn't consumed any messages yet, lag is the total message count
            if subscriber_id not in self.offset_map:
                return len(self.messages)
            
            current_offset = self.offset_map[subscriber_id]
            return len(self.messages) - current_offset