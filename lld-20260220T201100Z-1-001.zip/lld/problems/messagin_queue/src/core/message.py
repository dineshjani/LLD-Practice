from dataclasses import dataclass
from datetime import datetime
import uuid
from typing import Dict, Any, Optional

@dataclass
class Message:
    """Represents a single message in the queue"""
    id: str  # Unique identifier for the message
    topic: str  # Topic this message belongs to
    partition: int  # Partition within the topic
    payload: Any  # Actual message content
    timestamp: datetime  # When the message was created
    headers: Dict[str, str]  # Optional metadata
    key: Optional[str] = None  # Message key for partitioning
    
    def __init__(self, topic: str, partition: int, payload: Any, 
                 headers: Dict[str, str] = None, key: str = None):
        self.id = str(uuid.uuid4())
        self.topic = topic
        self.partition = partition
        self.payload = payload
        self.timestamp = datetime.now()
        self.headers = headers or {}
        self.key = key
    
    def __str__(self) -> str:
        return f"Message(id={self.id}, topic={self.topic}, partition={self.partition}, key={self.key}, payload={self.payload})"
