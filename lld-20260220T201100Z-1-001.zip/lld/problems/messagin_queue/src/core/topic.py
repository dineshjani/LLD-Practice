import threading
from typing import List, Set, Dict
import logging
from .partition import Partition
from .message import Message

logger = logging.getLogger("MessageQueue")

class Topic:
    """Represents a topic in the message queue"""
    def __init__(self, name: str, num_partitions: int = 3):
        self.name = name
        self.partitions = [Partition(name, i) for i in range(num_partitions)]
        self.lock = threading.RLock()
        self.subscribers = set()  # Set of subscriber IDs
        logger.info(f"Created topic {name} with {num_partitions} partitions")
    
    def add_message(self, message: Message) -> None:
        """Add a message to the appropriate partition"""
        partition = self.partitions[message.partition]
        partition.add_message(message)
    
    def add_subscriber(self, subscriber_id: str) -> None:
        """Register a new subscriber to this topic"""
        with self.lock:
            self.subscribers.add(subscriber_id)
            logger.info(f"Subscriber {subscriber_id} subscribed to topic {self.name}")
    
    def remove_subscriber(self, subscriber_id: str) -> None:
        """Remove a subscriber from this topic"""
        with self.lock:
            if subscriber_id in self.subscribers:
                self.subscribers.remove(subscriber_id)
                logger.info(f"Subscriber {subscriber_id} unsubscribed from topic {self.name}")
    
    def get_partition_count(self) -> int:
        """Get the number of partitions in this topic"""
        return len(self.partitions)
    
    def get_subscriber_count(self) -> int:
        """Get the number of subscribers to this topic"""
        with self.lock:
            return len(self.subscribers)
    
    def get_message_count(self) -> int:
        """Get the total number of messages across all partitions"""
        return sum(partition.get_message_count() for partition in self.partitions)
    
    def get_consumer_lag(self, subscriber_id: str) -> Dict[int, int]:
        """Get consumer lag for each partition in this topic"""
        lag_by_partition = {}
        for partition in self.partitions:
            lag_by_partition[partition.partition_id] = partition.get_consumer_lag(subscriber_id)
        return lag_by_partition
    
    def get_total_consumer_lag(self, subscriber_id: str) -> int:
        """Get total consumer lag across all partitions"""
        return sum(lag for lag in self.get_consumer_lag(subscriber_id).values())
