from abc import ABC, abstractmethod
from typing import Optional

class PartitionerInterface(ABC):
    """Interface for message partitioning strategies"""
    
    @abstractmethod
    def get_partition(self, topic_name: str, key: Optional[str], partition_count: int) -> int:
        """
        Determine which partition a message should go to
        
        Args:
            topic_name: The topic the message is being sent to
            key: The message key (can be None)
            partition_count: The number of partitions in the topic
            
        Returns:
            The partition ID to use
        """
        pass 