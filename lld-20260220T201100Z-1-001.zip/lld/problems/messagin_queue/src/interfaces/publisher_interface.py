from abc import ABC, abstractmethod
from typing import Dict, Any, Optional

class PublisherInterface(ABC):
    """Interface for message publishers"""
    
    @property
    @abstractmethod
    def publisher_id(self) -> str:
        """Get the publisher ID"""
        pass
    
    @abstractmethod
    def publish(self, topic_name: str, payload: Any, 
                headers: Dict[str, str] = None, key: str = None) -> Optional[str]:
        """Publish a message to a topic and return the message ID"""
        pass
    
    @abstractmethod
    def stop(self) -> None:
        """Stop this publisher"""
        pass