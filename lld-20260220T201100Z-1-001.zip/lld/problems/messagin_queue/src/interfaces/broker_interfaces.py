from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional

class BrokerInterface(ABC):
    """Interface for message broker implementations"""
    
    @abstractmethod
    def create_topic(self, topic_name: str, num_partitions: int = 3) -> bool:
        """Create a new topic with the specified number of partitions"""
        pass
    
    @abstractmethod
    def delete_topic(self, topic_name: str) -> bool:
        """Delete an existing topic"""
        pass
    
    @abstractmethod
    def topic_exists(self, topic_name: str) -> bool:
        """Check if a topic exists"""
        pass
    
    @abstractmethod
    def register_publisher(self, publisher_id: str = None):
        """Register a new publisher and return it"""
        pass
    
    @abstractmethod
    def register_subscriber(self, subscriber_id: str = None, auto_commit: bool = True):
        """Register a new subscriber and return it"""
        pass
    
    @abstractmethod
    def publish_message(self, publisher_id: str, topic_name: str, payload: Any, 
                        headers: Dict[str, str] = None) -> Optional[str]:
        """Publish a message to a topic and return the message ID"""
        pass
    
    @abstractmethod
    def subscribe_to_topic(self, subscriber_id: str, topic_name: str) -> bool:
        """Subscribe to a topic"""
        pass
    
    @abstractmethod
    def unsubscribe_from_topic(self, subscriber_id: str, topic_name: str) -> bool:
        """Unsubscribe from a topic"""
        pass
    
    @abstractmethod
    def poll_messages(self, subscriber_id: str, topic_name: str, batch_size: int = 10) -> List:
        """Poll for new messages from a topic"""
        pass
    
    @abstractmethod
    def commit_message(self, subscriber_id: str, message) -> bool:
        """Mark a message as successfully processed by a subscriber"""
        pass
    
    @abstractmethod
    def get_topic_stats(self) -> Dict[str, Dict[str, Any]]:
        """Get statistics for all topics"""
        pass
    
    @abstractmethod
    def shutdown(self) -> None:
        """Shutdown the broker and all publishers/subscribers"""
        pass

class PublisherInterface(ABC):
    """Interface for message publishers"""
    
    @property
    @abstractmethod
    def publisher_id(self) -> str:
        """Get the publisher ID"""
        pass
    
    @abstractmethod
    def publish(self, topic_name: str, payload: Any, headers: Dict[str, str] = None) -> Optional[str]:
        """Publish a message to a topic and return the message ID"""
        pass
    
    @abstractmethod
    def stop(self) -> None:
        """Stop this publisher"""
        pass
