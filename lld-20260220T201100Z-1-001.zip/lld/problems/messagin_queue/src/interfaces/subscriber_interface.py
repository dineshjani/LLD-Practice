from abc import ABC, abstractmethod
from typing import Callable, Optional

class SubscriberInterface(ABC):
    """Interface for message subscribers"""
    
    @property
    @abstractmethod
    def subscriber_id(self) -> str:
        """Get the subscriber ID"""
        pass
    
    @abstractmethod
    def subscribe(self, topic_name: str, message_handler: Callable = None) -> bool:
        """Subscribe to a topic with an optional message handler"""
        pass
    
    @abstractmethod
    def subscribe_with_group(self, topic_name: str, group_id: str, 
                            message_handler: Callable = None) -> bool:
        """Subscribe to a topic as part of a consumer group"""
        pass
    
    @abstractmethod
    def unsubscribe(self, topic_name: str) -> bool:
        """Unsubscribe from a topic"""
        pass
    
    @abstractmethod
    def commit_message(self, message) -> bool:
        """Manually commit a message"""
        pass
    
    @abstractmethod
    def stop(self) -> None:
        """Stop this subscriber"""
        pass
