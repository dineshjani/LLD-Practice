import threading
import random
import logging
from typing import Dict, List, Any, Optional, Set

from ..interfaces import BrokerInterface
from ..core.message import Message
from ..core.topic import Topic
from .delivery_tracker import DeliveryTracker
from ..clients.publisher import Publisher
from ..clients.subscriber import Subscriber
from .partitioners import KeyHashPartitioner, RandomPartitioner, RoundRobinPartitioner
from ..interfaces.partitioner_interface import PartitionerInterface
from .consumer_group import ConsumerGroup

logger = logging.getLogger("MessageQueue")

class MessageBroker(BrokerInterface):
    """Central component that manages topics, publishers, and subscribers"""
    
    def __init__(self, partitioner: PartitionerInterface = None):
        self.topics: Dict[str, Topic] = {}
        self.publishers: Dict[str, Publisher] = {}
        self.subscribers: Dict[str, Subscriber] = {}
        self.consumer_groups: Dict[str, ConsumerGroup] = {}  # group_id -> ConsumerGroup
        self.topic_lock = threading.RLock()
        self.group_lock = threading.RLock()
        self.delivery_tracker = DeliveryTracker()
        # Default to key hash partitioner if none provided
        self.partitioner = partitioner or KeyHashPartitioner()
        logger.info("Message broker initialized")
    
    def create_topic(self, topic_name: str, num_partitions: int = 3) -> bool:
        """Create a new topic"""
        with self.topic_lock:
            if topic_name in self.topics:
                logger.warning(f"Topic {topic_name} already exists")
                return False
            
            self.topics[topic_name] = Topic(topic_name, num_partitions)
            return True
    
    def delete_topic(self, topic_name: str) -> bool:
        """Delete a topic"""
        with self.topic_lock:
            if topic_name not in self.topics:
                logger.warning(f"Topic {topic_name} does not exist")
                return False
            
            del self.topics[topic_name]
            logger.info(f"Topic {topic_name} deleted")
            return True
    
    def topic_exists(self, topic_name: str) -> bool:
        """Check if a topic exists"""
        with self.topic_lock:
            return topic_name in self.topics
    
    def register_publisher(self, publisher_id: str = None) -> Publisher:
        """Register a new publisher"""
        publisher = Publisher(self, publisher_id)
        self.publishers[publisher.publisher_id] = publisher
        return publisher
    
    def register_subscriber(self, subscriber_id: str = None, auto_commit: bool = True) -> Subscriber:
        """Register a new subscriber"""
        subscriber = Subscriber(self, subscriber_id, auto_commit)
        self.subscribers[subscriber.subscriber_id] = subscriber
        return subscriber
    
    def publish_message(self, publisher_id: str, topic_name: str, payload: Any, 
                        headers: Dict[str, str] = None, key: str = None) -> Optional[str]:
        """Publish a message to a topic"""
        # Ensure topic exists
        with self.topic_lock:
            if topic_name not in self.topics:
                # Auto-create topic if it doesn't exist
                self.topics[topic_name] = Topic(topic_name)
                logger.info(f"Auto-created topic {topic_name}")
            
            topic = self.topics[topic_name]
        
        # Determine partition using the partitioner
        partition_id = self.partitioner.get_partition(
            topic_name, key, topic.get_partition_count()
        )
        
        # Create and add message
        message = Message(topic_name, partition_id, payload, headers, key)
        topic.add_message(message)
        
        logger.info(f"Published message {message.id} to {topic_name}:{partition_id}" + 
                   (f" with key '{key}'" if key else ""))
        return message.id
    
    def subscribe_to_topic(self, subscriber_id: str, topic_name: str) -> bool:
        """Subscribe to a topic"""
        with self.topic_lock:
            if topic_name not in self.topics:
                # Auto-create topic if it doesn't exist
                self.topics[topic_name] = Topic(topic_name)
                logger.info(f"Auto-created topic {topic_name}")
            
            topic = self.topics[topic_name]
            topic.add_subscriber(subscriber_id)
            return True
    
    def unsubscribe_from_topic(self, subscriber_id: str, topic_name: str) -> bool:
        """Unsubscribe from a topic"""
        with self.topic_lock:
            if topic_name not in self.topics:
                return False
            
            topic = self.topics[topic_name]
            topic.remove_subscriber(subscriber_id)
            return True
    
    def poll_messages(self, subscriber_id: str, topic_name: str, batch_size: int = 10) -> List[Message]:
        """Poll for new messages from a topic"""
        with self.topic_lock:
            if topic_name not in self.topics:
                return []
            
            topic = self.topics[topic_name]
            
            # Collect messages from all partitions
            all_messages = []
            for partition in topic.partitions:
                messages = partition.get_messages(subscriber_id, batch_size)
                all_messages.extend(messages)
                
                # Track messages for exactly-once delivery
                for message in messages:
                    self.delivery_tracker.track_message(subscriber_id, message.id)
            
            return all_messages
    
    def commit_message(self, subscriber_id: str, message: Message) -> bool:
        """Mark a message as successfully processed by a subscriber"""
        return self.delivery_tracker.commit_message(subscriber_id, message.id)
    
    def get_topic_stats(self) -> Dict[str, Dict[str, Any]]:
        """Get statistics for all topics"""
        stats = {}
        with self.topic_lock:
            for topic_name, topic in self.topics.items():
                stats[topic_name] = {
                    "partitions": topic.get_partition_count(),
                    "subscribers": topic.get_subscriber_count(),
                    "messages": topic.get_message_count()
                }
        return stats
    
    def shutdown(self) -> None:
        """Shutdown the broker and all publishers/subscribers"""
        logger.info("Shutting down message broker")
        
        # Stop all subscribers
        for subscriber in self.subscribers.values():
            subscriber.stop()
        
        # Stop all publishers
        for publisher in self.publishers.values():
            publisher.stop()
        
        logger.info("Message broker shutdown complete")
    
    def get_consumer_lag(self, subscriber_id: str, topic_name: str = None) -> Dict[str, Dict[int, int]]:
        """
        Get consumer lag for a subscriber
        
        If topic_name is provided, returns lag for that topic only
        Otherwise, returns lag for all topics the subscriber is subscribed to
        """
        with self.topic_lock:
            result = {}
            
            # If topic is specified, get lag for just that topic
            if topic_name:
                if topic_name in self.topics and subscriber_id in self.subscribers:
                    topic = self.topics[topic_name]
                    result[topic_name] = topic.get_consumer_lag(subscriber_id)
                return result
            
            # Otherwise get lag for all topics the subscriber is subscribed to
            for topic_name, topic in self.topics.items():
                if subscriber_id in topic.subscribers:
                    result[topic_name] = topic.get_consumer_lag(subscriber_id)
            
            return result
    
    def get_total_consumer_lag(self, subscriber_id: str) -> Dict[str, int]:
        """Get total consumer lag across all topics for a subscriber"""
        with self.topic_lock:
            result = {}
            for topic_name, topic in self.topics.items():
                if subscriber_id in topic.subscribers:
                    result[topic_name] = topic.get_total_consumer_lag(subscriber_id)
            return result
    
    def create_consumer_group(self, group_id: str) -> ConsumerGroup:
        """Create a new consumer group"""
        with self.group_lock:
            if group_id in self.consumer_groups:
                logger.warning(f"Consumer group {group_id} already exists")
                return self.consumer_groups[group_id]
            
            group = ConsumerGroup(group_id)
            self.consumer_groups[group_id] = group
            return group
    
    def get_consumer_group(self, group_id: str) -> Optional[ConsumerGroup]:
        """Get an existing consumer group"""
        with self.group_lock:
            return self.consumer_groups.get(group_id)
    
    def delete_consumer_group(self, group_id: str) -> bool:
        """Delete a consumer group"""
        with self.group_lock:
            if group_id not in self.consumer_groups:
                return False
            
            del self.consumer_groups[group_id]
            logger.info(f"Deleted consumer group {group_id}")
            return True
    
    def add_subscriber_to_group(self, subscriber_id: str, group_id: str) -> bool:
        """Add a subscriber to a consumer group"""
        with self.group_lock:
            if group_id not in self.consumer_groups:
                # Auto-create the group
                self.create_consumer_group(group_id)
            
            group = self.consumer_groups[group_id]
            group.add_subscriber(subscriber_id)
            return True
    
    def remove_subscriber_from_group(self, subscriber_id: str, group_id: str) -> bool:
        """Remove a subscriber from a consumer group"""
        with self.group_lock:
            if group_id not in self.consumer_groups:
                return False
            
            group = self.consumer_groups[group_id]
            group.remove_subscriber(subscriber_id)
            return True
    
    def subscribe_group_to_topic(self, group_id: str, topic_name: str) -> bool:
        """Subscribe a consumer group to a topic"""
        with self.group_lock:
            if group_id not in self.consumer_groups:
                return False
            
            with self.topic_lock:
                if topic_name not in self.topics:
                    # Auto-create the topic
                    self.create_topic(topic_name)
                
                topic = self.topics[topic_name]
                partition_count = topic.get_partition_count()
            
            group = self.consumer_groups[group_id]
            group.subscribe_to_topic(topic_name, partition_count)
            return True
    
    def poll_messages_for_group_member(self, subscriber_id: str, group_id: str, 
                                      topic_name: str, batch_size: int = 10) -> List[Message]:
        """
        Poll for messages from a topic for a specific group member
        Only returns messages from partitions assigned to this subscriber
        """
        with self.group_lock:
            if group_id not in self.consumer_groups:
                return []
            
            group = self.consumer_groups[group_id]
            assigned_partitions = group.get_assigned_partitions(subscriber_id, topic_name)
            
            if not assigned_partitions:
                return []
        
        with self.topic_lock:
            if topic_name not in self.topics:
                return []
            
            topic = self.topics[topic_name]
            
            # Collect messages only from assigned partitions
            all_messages = []
            for partition_id in assigned_partitions:
                if partition_id < len(topic.partitions):
                    partition = topic.partitions[partition_id]
                    messages = partition.get_messages(subscriber_id, batch_size)
                    all_messages.extend(messages)
                    
                    # Track messages for exactly-once delivery
                    for message in messages:
                        self.delivery_tracker.track_message(subscriber_id, message.id)
            
            return all_messages
