import threading
from typing import Dict, Tuple

class DeliveryTracker:
    """Tracks message delivery status for exactly-once delivery"""
    
    def __init__(self):
        self.delivery_status = {}  # Maps (subscriber_id, message_id) to delivery status
        self.lock = threading.RLock()
    
    def track_message(self, subscriber_id: str, message_id: str) -> None:
        """Start tracking a message for a subscriber"""
        with self.lock:
            key = (subscriber_id, message_id)
            self.delivery_status[key] = False  # Not yet committed
    
    def commit_message(self, subscriber_id: str, message_id: str) -> bool:
        """Mark a message as committed by a subscriber"""
        with self.lock:
            key = (subscriber_id, message_id)
            if key in self.delivery_status:
                self.delivery_status[key] = True
                return True
            return False
    
    def is_committed(self, subscriber_id: str, message_id: str) -> bool:
        """Check if a message has been committed by a subscriber"""
        with self.lock:
            key = (subscriber_id, message_id)
            return self.delivery_status.get(key, False)
    
    def cleanup_old_entries(self, max_entries: int = 10000) -> None:
        """Clean up old entries to prevent memory leaks"""
        with self.lock:
            # If we have too many entries, remove the committed ones
            if len(self.delivery_status) > max_entries:
                to_remove = [k for k, v in self.delivery_status.items() if v]
                for key in to_remove:
                    del self.delivery_status[key]