import random
import hashlib
from typing import Optional
from ..interfaces.partitioner_interface import PartitionerInterface

class RandomPartitioner(PartitionerInterface):
    """Randomly assigns messages to partitions"""
    
    def get_partition(self, topic_name: str, key: Optional[str], partition_count: int) -> int:
        """Randomly select a partition"""
        return random.randint(0, partition_count - 1)

class KeyHashPartitioner(PartitionerInterface):
    """Assigns messages to partitions based on key hash"""
    
    def get_partition(self, topic_name: str, key: Optional[str], partition_count: int) -> int:
        """
        Hash the key to determine partition
        If key is None, use random partitioning
        """
        if key is None:
            return random.randint(0, partition_count - 1)
        
        # Use MD5 hash of the key modulo partition count
        key_hash = hashlib.md5(key.encode('utf-8')).digest()
        # Convert first 4 bytes to integer
        hash_value = int.from_bytes(key_hash[:4], byteorder='little')
        return hash_value % partition_count

class RoundRobinPartitioner(PartitionerInterface):
    """Assigns messages to partitions in round-robin fashion"""
    
    def __init__(self):
        self.counters = {}  # Topic -> counter
    
    def get_partition(self, topic_name: str, key: Optional[str], partition_count: int) -> int:
        """
        Use round-robin for messages without keys
        Use key hash for messages with keys
        """
        if key is not None:
            # Use key hash for consistent routing
            key_hash = hashlib.md5(key.encode('utf-8')).digest()
            hash_value = int.from_bytes(key_hash[:4], byteorder='little')
            return hash_value % partition_count
        
        # Round-robin for messages without keys
        if topic_name not in self.counters:
            self.counters[topic_name] = 0
        
        partition = self.counters[topic_name]
        self.counters[topic_name] = (self.counters[topic_name] + 1) % partition_count
        
        return partition 