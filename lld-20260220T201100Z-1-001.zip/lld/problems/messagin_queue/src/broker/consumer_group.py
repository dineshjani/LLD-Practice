import threading
import logging
from typing import Dict, Set, List

logger = logging.getLogger("MessageQueue")

class ConsumerGroup:
    """
    Represents a group of subscribers that collectively consume messages from a topic.
    Each partition is assigned to exactly one subscriber in the group.
    """
    
    def __init__(self, group_id: str):
        self.group_id = group_id
        self.subscribers: Set[str] = set()  # Set of subscriber IDs in this group
        self.topic_assignments: Dict[str, Dict[str, List[int]]] = {}  # topic -> {subscriber_id -> [partition_ids]}
        self.lock = threading.RLock()
        logger.info(f"Created consumer group {group_id}")
    
    def add_subscriber(self, subscriber_id: str) -> None:
        """Add a subscriber to this consumer group"""
        with self.lock:
            self.subscribers.add(subscriber_id)
            logger.info(f"Added subscriber {subscriber_id} to consumer group {self.group_id}")
            
            # Rebalance partitions for all topics this group is subscribed to
            for topic_name in self.topic_assignments:
                self._rebalance_partitions(topic_name)
    
    def remove_subscriber(self, subscriber_id: str) -> None:
        """Remove a subscriber from this consumer group"""
        with self.lock:
            if subscriber_id in self.subscribers:
                self.subscribers.remove(subscriber_id)
                logger.info(f"Removed subscriber {subscriber_id} from consumer group {self.group_id}")
                
                # Remove this subscriber from all topic assignments
                for topic_assignments in self.topic_assignments.values():
                    if subscriber_id in topic_assignments:
                        del topic_assignments[subscriber_id]
                
                # Rebalance partitions for all topics this group is subscribed to
                for topic_name in self.topic_assignments:
                    self._rebalance_partitions(topic_name)
    
    def subscribe_to_topic(self, topic_name: str, partition_count: int) -> None:
        """Subscribe this consumer group to a topic"""
        with self.lock:
            if topic_name not in self.topic_assignments:
                self.topic_assignments[topic_name] = {}
                logger.info(f"Consumer group {self.group_id} subscribed to topic {topic_name}")
            
            self._rebalance_partitions(topic_name, partition_count)
    
    def unsubscribe_from_topic(self, topic_name: str) -> None:
        """Unsubscribe this consumer group from a topic"""
        with self.lock:
            if topic_name in self.topic_assignments:
                del self.topic_assignments[topic_name]
                logger.info(f"Consumer group {self.group_id} unsubscribed from topic {topic_name}")
    
    def get_assigned_partitions(self, subscriber_id: str, topic_name: str) -> List[int]:
        """Get the partitions assigned to a subscriber for a topic"""
        with self.lock:
            if (topic_name in self.topic_assignments and 
                subscriber_id in self.topic_assignments[topic_name]):
                return self.topic_assignments[topic_name][subscriber_id]
            return []
    
    def _rebalance_partitions(self, topic_name: str, partition_count: int = None) -> None:
        """
        Rebalance partitions among subscribers in this group
        
        This is called when:
        - A new subscriber joins the group
        - A subscriber leaves the group
        - The group subscribes to a new topic
        """
        if not self.subscribers:
            return
        
        # Clear existing assignments for this topic
        self.topic_assignments[topic_name] = {}
        
        # Get or use provided partition count
        if partition_count is None:
            # This would be provided by the broker in a real implementation
            # For now, assume we know the partition count
            return
        
        # Convert subscribers to list for indexing
        subscribers_list = list(self.subscribers)
        num_subscribers = len(subscribers_list)
        
        # Assign partitions to subscribers
        for partition_id in range(partition_count):
            # Simple round-robin assignment
            subscriber_id = subscribers_list[partition_id % num_subscribers]
            
            # Initialize subscriber's assignment list if needed
            if subscriber_id not in self.topic_assignments[topic_name]:
                self.topic_assignments[topic_name][subscriber_id] = []
            
            # Add partition to subscriber's assignments
            self.topic_assignments[topic_name][subscriber_id].append(partition_id)
        
        # Log the assignments
        for subscriber_id, partitions in self.topic_assignments[topic_name].items():
            logger.info(f"Assigned partitions {partitions} of topic {topic_name} to subscriber {subscriber_id}") 