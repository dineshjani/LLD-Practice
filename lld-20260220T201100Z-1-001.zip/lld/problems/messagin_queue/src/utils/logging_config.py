import logging
import sys

def configure_logging(level=logging.INFO):
    """Configure logging for the message queue system"""
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    # Create logger
    logger = logging.getLogger("MessageQueue")
    logger.setLevel(level)
    
    return logger
