import uuid
import threading
import time
import logging
from typing import Dict, List, Set, Callable, Optional

from ..interfaces.subscriber_interface import SubscriberInterface
from ..core.message import Message

logger = logging.getLogger("MessageQueue")

class Subscriber(SubscriberInterface):
    """Consumes messages from topics"""
    
    def __init__(self, broker, subscriber_id: str = None, auto_commit: bool = True):
        self._broker = broker
        self._subscriber_id = subscriber_id or f"subscriber-{str(uuid.uuid4())[:8]}"
        self._subscribed_topics = set()
        self._group_subscriptions = {}  # topic_name -> group_id
        self._message_handlers = {}  # Maps topic_name to handler function
        self._is_running = True
        self._auto_commit = auto_commit
        self._consumer_thread = None
        self._processing_lock = threading.RLock()
        logger.info(f"Created subscriber {self._subscriber_id}")
    
    @property
    def subscriber_id(self) -> str:
        """Get the subscriber ID"""
        return self._subscriber_id
    
    def subscribe(self, topic_name: str, message_handler: Callable[[Message], None] = None) -> bool:
        """Subscribe to a topic with an optional message handler"""
        with self._processing_lock:
            if not self._is_running:
                logger.warning(f"Subscriber {self._subscriber_id} is stopped")
                return False
            
            success = self._broker.subscribe_to_topic(self._subscriber_id, topic_name)
            if success:
                self._subscribed_topics.add(topic_name)
                if message_handler:
                    self._message_handlers[topic_name] = message_handler
                
                # Start consumer thread if not already running
                if self._consumer_thread is None or not self._consumer_thread.is_alive():
                    self._consumer_thread = threading.Thread(target=self._consume_loop)
                    self._consumer_thread.daemon = True
                    self._consumer_thread.start()
            
            return success
    
    def subscribe_with_group(self, topic_name: str, group_id: str, 
                            message_handler: Callable[[Message], None] = None) -> bool:
        """Subscribe to a topic as part of a consumer group"""
        with self._processing_lock:
            if not self._is_running:
                logger.warning(f"Subscriber {self._subscriber_id} is stopped")
                return False
            
            # Add to consumer group
            success = self._broker.add_subscriber_to_group(self._subscriber_id, group_id)
            if not success:
                return False
            
            # Subscribe group to topic
            success = self._broker.subscribe_group_to_topic(group_id, topic_name)
            if not success:
                return False
            
            # Track this subscription
            self._subscribed_topics.add(topic_name)
            self._group_subscriptions[topic_name] = group_id
            
            if message_handler:
                self._message_handlers[topic_name] = message_handler
            
            # Start consumer thread if not already running
            if self._consumer_thread is None or not self._consumer_thread.is_alive():
                self._consumer_thread = threading.Thread(target=self._consume_loop)
                self._consumer_thread.daemon = True
                self._consumer_thread.start()
            
            return True
    
    def unsubscribe(self, topic_name: str) -> bool:
        """Unsubscribe from a topic"""
        with self._processing_lock:
            if topic_name in self._subscribed_topics:
                success = self._broker.unsubscribe_from_topic(self._subscriber_id, topic_name)
                if success:
                    self._subscribed_topics.remove(topic_name)
                    if topic_name in self._message_handlers:
                        del self._message_handlers[topic_name]
                return success
            return False
    
    def _consume_loop(self) -> None:
        """Background thread that continuously polls for new messages"""
        while self._is_running:
            try:
                with self._processing_lock:
                    if not self._subscribed_topics:
                        time.sleep(0.1)
                        continue
                    
                    for topic_name in list(self._subscribed_topics):
                        # Check if this is a group subscription
                        if topic_name in self._group_subscriptions:
                            group_id = self._group_subscriptions[topic_name]
                            messages = self._broker.poll_messages_for_group_member(
                                self._subscriber_id, group_id, topic_name
                            )
                        else:
                            # Regular subscription
                            messages = self._broker.poll_messages(self._subscriber_id, topic_name)
                        
                        for message in messages:
                            self._process_message(message)
                            
                            # Auto-commit after processing if enabled
                            if self._auto_commit:
                                self._broker.commit_message(self._subscriber_id, message)
                
                # Sleep to avoid busy waiting
                time.sleep(0.01)
            
            except Exception as e:
                logger.error(f"Error in consumer loop: {str(e)}")
                time.sleep(1)  # Back off on error
    
    def _process_message(self, message: Message) -> None:
        """Process a single message"""
        try:
            # Call the registered handler if available
            if message.topic in self._message_handlers:
                handler = self._message_handlers[message.topic]
                handler(message)
            else:
                # Default handling - just log the message
                logger.debug(f"Received message: {message}")
        except Exception as e:
            logger.error(f"Error processing message {message.id}: {str(e)}")
    
    def commit_message(self, message: Message) -> bool:
        """Manually commit a message (only needed if auto_commit is False)"""
        if not self._auto_commit:
            return self._broker.commit_message(self._subscriber_id, message)
        return True
    
    def stop(self) -> None:
        """Stop this subscriber"""
        self._is_running = False
        if self._consumer_thread and self._consumer_thread.is_alive():
            self._consumer_thread.join(timeout=2.0)
        logger.info(f"Subscriber {self._subscriber_id} stopped")
    
    def get_lag(self, topic_name: str = None) -> Dict[str, Dict[int, int]]:
        """Get current lag for this subscriber"""
        return self._broker.get_consumer_lag(self._subscriber_id, topic_name)
    
    def get_total_lag(self) -> Dict[str, int]:
        """Get total lag across all topics for this subscriber"""
        return self._broker.get_total_consumer_lag(self._subscriber_id)
