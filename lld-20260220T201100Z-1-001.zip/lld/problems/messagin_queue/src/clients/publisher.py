import uuid
import logging
from typing import Dict, Any, Optional

from ..interfaces.publisher_interface import PublisherInterface
from ..interfaces import BrokerInterface
logger = logging.getLogger("MessageQueue")

class Publisher(PublisherInterface):
    """Produces messages to topics"""
    
    def __init__(self, broker: BrokerInterface, publisher_id: str = None):
        self._broker = broker
        self._publisher_id = publisher_id or f"publisher-{str(uuid.uuid4())[:8]}"
        self._is_running = True
        logger.info(f"Created publisher {self._publisher_id}")
    
    @property
    def publisher_id(self) -> str:
        """Get the publisher ID"""
        return self._publisher_id
    
    def publish(self, topic_name: str, payload: Any, 
                headers: Dict[str, str] = None, key: str = None) -> Optional[str]:
        """Publish a message to a topic"""
        if not self._is_running:
            logger.warning(f"Publisher {self._publisher_id} is stopped")
            return None
        
        # Let the broker handle the message
        message_id = self._broker.publish_message(
            self._publisher_id, topic_name, payload, headers, key
        )
        return message_id
    
    def stop(self) -> None:
        """Stop this publisher"""
        self._is_running = False
        logger.info(f"Publisher {self._publisher_id} stopped")