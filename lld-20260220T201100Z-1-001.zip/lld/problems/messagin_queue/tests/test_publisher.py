import unittest
from unittest.mock import MagicMock
from src.clients.publisher import Publisher

class TestPublisher(unittest.TestCase):
    def setUp(self):
        self.mock_broker = MagicMock()
        self.publisher = Publisher(self.mock_broker, "test-publisher")
    
    def test_publisher_id(self):
        self.assertEqual(self.publisher.publisher_id, "test-publisher")
    
    def test_publish(self):
        # Set up mock
        self.mock_broker.publish_message.return_value = "message-id-123"
        
        # Publish a message
        message_id = self.publisher.publish("test-topic", "test-payload", {"header1": "value1"})
        
        # Verify broker was called correctly
        self.mock_broker.publish_message.assert_called_once_with(
            "test-publisher", "test-topic", "test-payload", {"header1": "value1"}
        )
        
        # Verify return value
        self.assertEqual(message_id, "message-id-123")
    
    def test_publish_when_stopped(self):
        # Stop the publisher
        self.publisher.stop()
        
        # Try to publish a message
        message_id = self.publisher.publish("test-topic", "test-payload")
        
        # Verify broker was not called
        self.mock_broker.publish_message.assert_not_called()
        
        # Verify return value is None
        self.assertIsNone(message_id)

if __name__ == '__main__':
    unittest.main()
