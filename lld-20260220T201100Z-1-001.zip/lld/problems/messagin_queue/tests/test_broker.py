import unittest
import threading
import time
from src.broker.message_broker import MessageBroker

class TestMessageBroker(unittest.TestCase):
    def setUp(self):
        self.broker = MessageBroker()
    
    def tearDown(self):
        self.broker.shutdown()
    
    def test_create_topic(self):
        # Create a topic
        result = self.broker.create_topic("test-topic", 3)
        self.assertTrue(result)
        self.assertTrue(self.broker.topic_exists("test-topic"))
        
        # Try to create the same topic again
        result = self.broker.create_topic("test-topic", 3)
        self.assertFalse(result)
    
    def test_delete_topic(self):
        # Create and then delete a topic
        self.broker.create_topic("test-topic")
        result = self.broker.delete_topic("test-topic")
        self.assertTrue(result)
        self.assertFalse(self.broker.topic_exists("test-topic"))
        
        # Try to delete a non-existent topic
        result = self.broker.delete_topic("non-existent-topic")
        self.assertFalse(result)
    
    def test_publish_and_poll(self):
        # Create a topic
        self.broker.create_topic("test-topic")
        
        # Register a publisher and subscriber
        publisher = self.broker.register_publisher("test-publisher")
        subscriber = self.broker.register_subscriber("test-subscriber")
        
        # Subscribe to the topic
        subscriber.subscribe("test-topic")
        
        # Publish a message
        message_id = publisher.publish("test-topic", "test-message")
        self.assertIsNotNone(message_id)
        
        # Wait a bit for processing
        time.sleep(0.1)
        
        # Check topic stats
        stats = self.broker.get_topic_stats()
        self.assertIn("test-topic", stats)
        self.assertEqual(stats["test-topic"]["messages"], 1)
    
    def test_concurrent_publish(self):
        # Create a topic
        self.broker.create_topic("test-topic", 5)
        
        # Register publishers
        publishers = [self.broker.register_publisher(f"pub-{i}") for i in range(5)]
        
        # Function to publish messages
        def publish_messages(publisher, count):
            for i in range(count):
                publisher.publish("test-topic", f"Message {i}")
        
        # Start publisher threads
        threads = []
        messages_per_publisher = 20
        for pub in publishers:
            thread = threading.Thread(target=publish_messages, args=(pub, messages_per_publisher))
            threads.append(thread)
            thread.start()
        
        # Wait for all publishers to finish
        for thread in threads:
            thread.join()
        
        # Check total message count
        stats = self.broker.get_topic_stats()
        self.assertEqual(stats["test-topic"]["messages"], len(publishers) * messages_per_publisher)

if __name__ == '__main__':
    unittest.main()
