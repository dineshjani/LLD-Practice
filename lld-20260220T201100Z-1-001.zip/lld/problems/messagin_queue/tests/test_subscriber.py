import unittest
import time
from unittest.mock import MagicMock, patch

from src.clients.subscriber import Subscriber
from src.core.message import Message

class TestSubscriber(unittest.TestCase):
    def setUp(self):
        self.mock_broker = MagicMock()
        self.subscriber = Subscriber(self.mock_broker, "test-subscriber")
    
    def tearDown(self):
        self.subscriber.stop()
        time.sleep(0.1)  # Give time for threads to stop
    
    def test_subscriber_id(self):
        self.assertEqual(self.subscriber.subscriber_id, "test-subscriber")
    
    def test_subscribe(self):
        # Set up mock
        self.mock_broker.subscribe_to_topic.return_value = True
        
        # Define a handler
        handler = MagicMock()
        
        # Subscribe to a topic
        result = self.subscriber.subscribe("test-topic", handler)
        
        # Verify broker was called correctly
        self.mock_broker.subscribe_to_topic.assert_called_once_with("test-subscriber", "test-topic")
        
        # Verify return value
        self.assertTrue(result)
    
    def test_unsubscribe(self):
        # Set up mocks
        self.mock_broker.subscribe_to_topic.return_value = True
        self.mock_broker.unsubscribe_from_topic.return_value = True
        
        # Subscribe first
        self.subscriber.subscribe("test-topic")
        
        # Then unsubscribe
        result = self.subscriber.unsubscribe("test-topic")
        
        # Verify broker was called correctly
        self.mock_broker.unsubscribe_from_topic.assert_called_once_with("test-subscriber", "test-topic")
        
        # Verify return value
        self.assertTrue(result)
    
    def test_message_processing(self):
        # Set up mocks
        self.mock_broker.subscribe_to_topic.return_value = True
        
        # Create a test message
        test_message = Message("test-topic", 0, "test-payload")
        
        # Set up poll_messages to return our test message once, then empty list
        self.mock_broker.poll_messages.side_effect = [[test_message], []]
        
        # Create a handler that we can verify was called
        handler = MagicMock()
        
        # Subscribe with the handler
        self.subscriber.subscribe("test-topic", handler)
        
        # Wait a bit for the consumer thread to process
        time.sleep(0.2)
        
        # Verify handler was called with our message
        handler.assert_called_with(test_message)
        
        # Verify commit was called (auto-commit is True by default)
        self.mock_broker.commit_message.assert_called_with("test-subscriber", test_message)
    
    def test_manual_commit(self):
        # Create subscriber with auto_commit=False
        manual_subscriber = Subscriber(self.mock_broker, "manual-subscriber", auto_commit=False)
        
        try:
            # Set up mocks
            self.mock_broker.subscribe_to_topic.return_value = True
            
            # Create a test message
            test_message = Message("test-topic", 0, "test-payload")
            
            # Manually commit the message
            manual_subscriber.commit_message(test_message)
            
            # Verify broker was called correctly
            self.mock_broker.commit_message.assert_called_once_with("manual-subscriber", test_message)
        finally:
            manual_subscriber.stop()

if __name__ == '__main__':
    unittest.main()
