# Distributed Cache System Design

Design a distributed in-memory caching system similar to Redis or Memcached.

## Requirements

### Core Features
- In-memory key-value storage using hash maps
- Support for different data types (string, list, hash, set, sorted set)
- TTL (Time-To-Live) for keys with automatic expiration
- Eviction policies (LRU, LFU) when memory limit is reached
- Basic operations: GET, SET, DELETE, UPDATE, etc.

### Advanced Features
- Sharding and consistent hashing for data distribution
- Master-slave replication for high availability
- Persistence mechanisms (AOF, RDB snapshots)
- Transactions and atomic operations
- Pub/Sub messaging capabilities
- Lua scripting support

### Performance Requirements
- Low latency for read/write operations (<1ms)
- High throughput (thousands of operations per second)
- Efficient memory usage
- Graceful degradation under high load

### System Design Components
1. **Storage Engine**
   - In-memory hash table for fast lookups
   - Doubly linked list for LRU/LFU implementation
   - Background cleanup for expired keys

2. **Cluster Management**
   - Consistent hashing for shard allocation
   - Node discovery and health monitoring
   - Rebalancing mechanism when nodes join/leave

3. **Replication**
   - Master-slave architecture
   - Asynchronous replication
   - Failover mechanism

4. **Persistence**
   - Append-only file (AOF) for durability
   - Point-in-time snapshots (RDB)
   - Recovery mechanism

5. **Client Interface**
   - TCP/HTTP protocol support
   - Client-side sharding
   - Connection pooling

## Implementation Guidelines
- Use thread-safe data structures or implement proper locking mechanisms
- Implement efficient serialization/deserialization
- Design for horizontal scalability
- Consider memory fragmentation issues
- Implement proper error handling and logging

## Evaluation Criteria
- Correctness of the implementation
- Performance under various workloads
- Memory efficiency
- Code quality and organization
- Handling of edge cases and failure scenarios





 Design patterns used:

    LRU Cache: Uses Decorator, Command, Composite, Observer

    Eviction strategies: Strategy pattern

    Sharded architecture: Singleton for global state, Factory for shard management

🧠 Good balance of LLD patterns + performance optimization