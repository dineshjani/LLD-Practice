class RedBusException(Exception):
    """Base exception class for RedBus system"""
    pass


# Bus related exceptions
class BusNotFoundException(RedBusException):
    """Exception raised when a bus is not found"""
    pass


class InvalidBusDataException(RedBusException):
    """Exception raised when invalid bus data is provided"""
    pass


# Schedule related exceptions
class ScheduleNotFoundException(RedBusException):
    """Exception raised when a schedule is not found"""
    pass


class InvalidScheduleDataException(RedBusException):
    """Exception raised when invalid schedule data is provided"""
    pass


# Booking related exceptions
class BookingNotFoundException(RedBusException):
    """Exception raised when a booking is not found"""
    pass


class InvalidBookingDataException(RedBusException):
    """Exception raised when invalid booking data is provided"""
    pass


class SeatUnavailableException(RedBusException):
    """Exception raised when attempting to book an unavailable seat"""
    pass


# User related exceptions
class UserNotFoundException(RedBusException):
    """Exception raised when a user is not found"""
    pass


class InvalidUserDataException(RedBusException):
    """Exception raised when invalid user data is provided"""
    pass


class AuthenticationException(RedBusException):
    """Exception raised when authentication fails"""
    pass


# Payment related exceptions
class PaymentFailedException(RedBusException):
    """Exception raised when a payment fails"""
    pass


class InvalidPaymentDataException(RedBusException):
    """Exception raised when invalid payment data is provided"""
    pass


# Route related exceptions
class RouteNotFoundException(RedBusException):
    """Exception raised when a route is not found"""
    pass


class InvalidRouteDataException(RedBusException):
    """Exception raised when invalid route data is provided"""
    pass


# Stop related exceptions
class StopNotFoundException(RedBusException):
    """Exception raised when a stop is not found"""
    pass


class InvalidStopDataException(RedBusException):
    """Exception raised when invalid stop data is provided"""
    pass


# Operator related exceptions
class OperatorNotFoundException(RedBusException):
    """Exception raised when an operator is not found"""
    pass


class InvalidOperatorDataException(RedBusException):
    """Exception raised when invalid operator data is provided"""
    pass


# Cancellation related exceptions
class CancellationFailedException(RedBusException):
    """Exception raised when a cancellation fails"""
    pass


class InvalidCancellationDataException(RedBusException):
    """Exception raised when invalid cancellation data is provided"""
    pass


# Refund related exceptions
class RefundFailedException(RedBusException):
    """Exception raised when a refund fails"""
    pass


class InvalidRefundDataException(RedBusException):
    """Exception raised when invalid refund data is provided"""
    pass 