from abc import ABC, abstractmethod
from typing import List, Dict, Optional, Set, Any
from datetime import datetime
import uuid
import smtplib
import requests
import json
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

from ..models.booking import Booking

# Observer Pattern
class NotificationObserver(ABC):
    @abstractmethod
    def update(self, event_type: str, data: Dict[str, Any]) -> None:
        pass

class EmailNotifier(NotificationObserver):
    def __init__(self, smtp_server="smtp.gmail.com", smtp_port=587, 
                 sender_email="notifications@redbus.com", 
                 sender_password="your_app_password"):
        self.smtp_server = smtp_server
        self.smtp_port = smtp_port
        self.sender_email = sender_email
        self.sender_password = sender_password
    
    def update(self, event_type: str, data: Dict[str, Any]) -> None:
        user_id = data.get('user_id')
        email = data.get('email')
        if not email:
            return
            
        subject = data.get('subject', 'Notification from RedBus')
        message = data.get('message', '')
        
        try:
            self._send_email(email, subject, message)
            print(f"Email sent to {email}: {subject}")
        except Exception as e:
            print(f"Failed to send email to {email}: {str(e)}")
    
    def _send_email(self, recipient_email: str, subject: str, message: str) -> None:
        """Send an email using SMTP"""
        # Create a multipart message
        msg = MIMEMultipart()
        msg['From'] = self.sender_email
        msg['To'] = recipient_email
        msg['Subject'] = subject
        
        # Add message body
        msg.attach(MIMEText(message, 'plain'))
        
        # Connect to SMTP server and send email
        try:
            server = smtplib.SMTP(self.smtp_server, self.smtp_port)
            server.starttls()  # Secure the connection
            server.login(self.sender_email, self.sender_password)
            server.send_message(msg)
            server.quit()
        except Exception as e:
            print(f"SMTP Error: {str(e)}")
            raise

class SMSNotifier(NotificationObserver):
    def __init__(self, api_key="your_sms_api_key", api_secret="your_sms_api_secret"):
        self.api_key = api_key
        self.api_secret = api_secret
        self.sms_api_url = "https://api.sms-provider.com/send"
    
    def update(self, event_type: str, data: Dict[str, Any]) -> None:
        user_id = data.get('user_id')
        phone = data.get('phone')
        if not phone:
            return
            
        message = data.get('message', '')
        
        try:
            self._send_sms(phone, message)
            print(f"SMS sent to {phone}")
        except Exception as e:
            print(f"Failed to send SMS to {phone}: {str(e)}")
    
    def _send_sms(self, phone_number: str, message: str) -> None:
        """Send SMS using a third-party API"""
        payload = {
            'api_key': self.api_key,
            'api_secret': self.api_secret,
            'to': phone_number,
            'text': message
        }
        
        try:
            response = requests.post(self.sms_api_url, json=payload)
            response.raise_for_status()  # Raise exception for HTTP errors
            
            result = response.json()
            if result.get('status') != 'success':
                raise Exception(f"SMS API error: {result.get('error_message')}")
                
        except requests.exceptions.RequestException as e:
            print(f"SMS API Error: {str(e)}")
            raise

class PushNotifier(NotificationObserver):
    def __init__(self, firebase_api_key="your_firebase_api_key"):
        self.firebase_api_key = firebase_api_key
        self.fcm_url = "https://fcm.googleapis.com/fcm/send"
    
    def update(self, event_type: str, data: Dict[str, Any]) -> None:
        user_id = data.get('user_id')
        if not user_id:
            return
            
        title = data.get('subject', 'Notification')
        message = data.get('message', '')
        
        # In a real system, we would retrieve the user's device tokens from a database
        device_tokens = self._get_user_device_tokens(user_id)
        
        if not device_tokens:
            print(f"No device tokens found for user {user_id}")
            return
            
        try:
            self._send_push_notification(device_tokens, title, message)
            print(f"Push notification sent to user {user_id}")
        except Exception as e:
            print(f"Failed to send push notification to user {user_id}: {str(e)}")
    
    def _get_user_device_tokens(self, user_id: str) -> List[str]:
        """Get the user's device tokens from database"""
        # In a real system, this would query a database
        # For this example, we'll return a dummy token
        return [f"device_token_{user_id}"]
    
    def _send_push_notification(self, device_tokens: List[str], title: str, message: str) -> None:
        """Send push notification using Firebase Cloud Messaging"""
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'key={self.firebase_api_key}'
        }
        
        payload = {
            'registration_ids': device_tokens,
            'notification': {
                'title': title,
                'body': message,
                'sound': 'default'
            }
        }
        
        try:
            response = requests.post(self.fcm_url, headers=headers, data=json.dumps(payload))
            response.raise_for_status()  # Raise exception for HTTP errors
            
            result = response.json()
            if result.get('failure') > 0:
                print(f"Some push notifications failed: {result}")
                
        except requests.exceptions.RequestException as e:
            print(f"FCM Error: {str(e)}")
            raise

class WhatsAppNotifier(NotificationObserver):
    def __init__(self, twilio_account_sid="your_twilio_sid", 
                 twilio_auth_token="your_twilio_token",
                 twilio_whatsapp_number="your_twilio_whatsapp_number"):
        self.twilio_account_sid = twilio_account_sid
        self.twilio_auth_token = twilio_auth_token
        self.twilio_whatsapp_number = twilio_whatsapp_number
        self.twilio_api_url = f"https://api.twilio.com/2010-04-01/Accounts/{twilio_account_sid}/Messages.json"
    
    def update(self, event_type: str, data: Dict[str, Any]) -> None:
        user_id = data.get('user_id')
        phone = data.get('phone')
        if not phone:
            return
            
        message = data.get('message', '')
        
        try:
            self._send_whatsapp(phone, message)
            print(f"WhatsApp message sent to {phone}")
        except Exception as e:
            print(f"Failed to send WhatsApp message to {phone}: {str(e)}")
    
    def _send_whatsapp(self, phone_number: str, message: str) -> None:
        """Send WhatsApp message using Twilio"""
        # Format phone number for WhatsApp (add whatsapp: prefix)
        whatsapp_to = f"whatsapp:{phone_number}"
        whatsapp_from = f"whatsapp:{self.twilio_whatsapp_number}"
        
        payload = {
            'From': whatsapp_from,
            'To': whatsapp_to,
            'Body': message
        }
        
        try:
            response = requests.post(
                self.twilio_api_url, 
                data=payload,
                auth=(self.twilio_account_sid, self.twilio_auth_token)
            )
            response.raise_for_status()  # Raise exception for HTTP errors
            
            result = response.json()
            if result.get('error_code'):
                raise Exception(f"Twilio API error: {result.get('error_message')}")
                
        except requests.exceptions.RequestException as e:
            print(f"Twilio API Error: {str(e)}")
            raise

class NotificationService:
    """
    Service for sending notifications to users about bookings, cancellations, etc.
    """
    
    def __init__(self):
        # In a real system, this would connect to email/SMS services
        self.notifications: List[Dict] = []
        self.observers: Dict[str, Set[NotificationObserver]] = {}
        
        # Register default observers
        self.register_observer("all", EmailNotifier())
        self.register_observer("all", SMSNotifier())
        self.register_observer("all", PushNotifier())
        self.register_observer("all", WhatsAppNotifier())
    
    def register_observer(self, event_type: str, observer: NotificationObserver) -> None:
        """Register an observer for a specific event type"""
        if event_type not in self.observers:
            self.observers[event_type] = set()
        self.observers[event_type].add(observer)
    
    def remove_observer(self, event_type: str, observer: NotificationObserver) -> None:
        """Remove an observer from a specific event type"""
        if event_type in self.observers:
            self.observers[event_type].discard(observer)
    
    def notify(self, event_type: str, data: Dict[str, Any]) -> None:
        """Notify all observers registered for the event type"""
        # Add notification to history
        notification_record = {
            'notification_id': str(uuid.uuid4()),
            'event_type': event_type,
            'data': data,
            'sent_time': datetime.now()
        }
        self.notifications.append(notification_record)
        
        # Notify specific event observers
        if event_type in self.observers:
            for observer in self.observers[event_type]:
                observer.update(event_type, data)
                
        # Notify "all" event observers
        if "all" in self.observers and event_type != "all":
            for observer in self.observers["all"]:
                observer.update(event_type, data)
    
    def send_booking_confirmation(self, booking: Booking) -> None:
        """
        Send booking confirmation notification
        
        Args:
            booking: Booking to send confirmation for
        """
        # Create notification message
        message = f"Your booking (ID: {booking.booking_id}) is confirmed. " \
                 f"Journey from {booking.source.name} to {booking.destination.name} " \
                 f"on {booking.journey_date.strftime('%d %b %Y')}. " \
                 f"Total amount: ₹{booking.total_amount:.2f}"
        
        data = {
            "user_id": booking.user_id,
            "email": booking.user.email if hasattr(booking, 'user') and hasattr(booking.user, 'email') else None,
            "phone": booking.user.phone if hasattr(booking, 'user') and hasattr(booking.user, 'phone') else None,
            "subject": "Booking Confirmation",
            "message": message,
            "booking_id": booking.booking_id
        }
        
        self.notify("booking_confirmation", data)
        
        # Log notification
        print(f"Notification sent: {message}")
    
    def send_cancellation_confirmation(self, booking: Booking, refund_amount: float) -> None:
        """
        Send cancellation confirmation notification
        
        Args:
            booking: Cancelled booking
            refund_amount: Amount refunded
        """
        # Create notification message
        message = f"Your booking (ID: {booking.booking_id}) has been cancelled. " \
                 f"Refund amount: ₹{refund_amount:.2f} will be credited to your account " \
                 f"within 5-7 working days."
        
        data = {
            "user_id": booking.user_id,
            "email": booking.user.email if hasattr(booking, 'user') and hasattr(booking.user, 'email') else None,
            "phone": booking.user.phone if hasattr(booking, 'user') and hasattr(booking.user, 'phone') else None,
            "subject": "Booking Cancellation",
            "message": message,
            "booking_id": booking.booking_id,
            "refund_amount": refund_amount
        }
        
        self.notify("booking_cancellation", data)
        
        # Log notification
        print(f"Notification sent: {message}")
    
    def send_journey_reminder(self, booking: Booking) -> None:
        """
        Send journey reminder notification
        
        Args:
            booking: Booking to send reminder for
        """
        # Create notification message
        message = f"Reminder: Your journey from {booking.source.name} to " \
                 f"{booking.destination.name} is scheduled for tomorrow " \
                 f"({booking.journey_date.strftime('%d %b %Y')})"
        
        data = {
            "user_id": booking.user_id,
            "email": booking.user.email if hasattr(booking, 'user') and hasattr(booking.user, 'email') else None,
            "phone": booking.user.phone if hasattr(booking, 'user') and hasattr(booking.user, 'phone') else None,
            "subject": "Journey Reminder",
            "message": message,
            "booking_id": booking.booking_id
        }
        
        self.notify("journey_reminder", data)
        
        # Log notification
        print(f"Notification sent: {message}")
    
    def send_partial_cancellation_confirmation(self, booking: Booking, 
                                              cancelled_passenger_names: List[str],
                                              refund_amount: float) -> None:
        """
        Send partial cancellation confirmation notification
        
        Args:
            booking: Partially cancelled booking
            cancelled_passenger_names: Names of cancelled passengers
            refund_amount: Amount refunded
        """
        # Create notification message
        passenger_list = ", ".join(cancelled_passenger_names)
        message = f"Partial cancellation for booking (ID: {booking.booking_id}) is confirmed. " \
                 f"Cancelled passengers: {passenger_list}. " \
                 f"Refund amount: ₹{refund_amount:.2f} will be credited to your account " \
                 f"within 5-7 working days."
        
        data = {
            "user_id": booking.user_id,
            "email": booking.user.email if hasattr(booking, 'user') and hasattr(booking.user, 'email') else None,
            "phone": booking.user.phone if hasattr(booking, 'user') and hasattr(booking.user, 'phone') else None,
            "subject": "Partial Cancellation Confirmation",
            "message": message,
            "booking_id": booking.booking_id,
            "cancelled_passengers": cancelled_passenger_names,
            "refund_amount": refund_amount
        }
        
        self.notify("partial_cancellation", data)
        
        # Log notification
        print(f"Notification sent: {message}")
    
    def send_payment_confirmation(self, booking: Booking, amount: float, payment_method: str) -> None:
        """
        Send payment confirmation notification
        
        Args:
            booking: Booking that was paid for
            amount: Amount paid
            payment_method: Method of payment
        """
        # Create notification message
        message = f"Payment of ₹{amount:.2f} received for booking {booking.booking_id}. " \
                 f"Payment method: {payment_method}. " \
                 f"Journey from {booking.source.name} to {booking.destination.name} " \
                 f"on {booking.journey_date.strftime('%d %b %Y')}"
        
        data = {
            "user_id": booking.user_id,
            "email": booking.user.email if hasattr(booking, 'user') and hasattr(booking.user, 'email') else None,
            "phone": booking.user.phone if hasattr(booking, 'user') and hasattr(booking.user, 'phone') else None,
            "subject": "Payment Confirmation",
            "message": message,
            "booking_id": booking.booking_id,
            "amount": amount,
            "payment_method": payment_method
        }
        
        self.notify("payment_confirmation", data)
        
        # Log notification
        print(f"Notification sent: {message}") 