from typing import Dict, Optional
from datetime import date, datetime, timedelta
from enum import Enum

class PricingStrategy(Enum):
    DEFAULT = "DEFAULT"
    WEEKEND = "WEEKEND"
    PEAK_SEASON = "PEAK_SEASON"
    LAST_MINUTE = "LAST_MINUTE"

class PricingService:
    """
    Service for calculating ticket prices based on various factors.
    """
    
    def __init__(self):
        # Pricing multipliers
        self.strategy_multipliers = {
            PricingStrategy.DEFAULT: 1.0,
            PricingStrategy.WEEKEND: 1.2,
            PricingStrategy.PEAK_SEASON: 1.5,
            PricingStrategy.LAST_MINUTE: 1.3
        }
        
        # Peak season dates (example: summer and winter holidays)
        self.peak_seasons = [
            (date(datetime.now().year, 5, 1), date(datetime.now().year, 6, 30)),  # Summer
            (date(datetime.now().year, 12, 15), date(datetime.now().year, 1, 15))  # Winter
        ]
    
    def calculate_fare(self, base_fare: float, journey_date: date, 
                      seat_price_multiplier: float = 1.0) -> float:
        """
        Calculate the final fare based on various factors
        
        Args:
            base_fare: Base fare for the schedule
            journey_date: Date of journey
            seat_price_multiplier: Price multiplier for the seat
            
        Returns:
            Final calculated fare
        """
        # Determine pricing strategy
        strategy = self._determine_pricing_strategy(journey_date)
        
        # Apply strategy multiplier
        strategy_multiplier = self.strategy_multipliers[strategy]
        
        # Calculate final fare
        final_fare = base_fare * strategy_multiplier * seat_price_multiplier
        
        # Round to nearest whole number
        return round(final_fare)
    
    def calculate_refund(self, fare: float, booking_date: datetime, 
                        journey_date: date, cancellation_date: datetime) -> float:
        """
        Calculate refund amount based on cancellation policy
        
        Args:
            fare: Original fare paid
            booking_date: Date when booking was made
            journey_date: Date of journey
            cancellation_date: Date when cancellation was requested
            
        Returns:
            Refund amount
        """
        # Convert journey_date to datetime for comparison
        journey_datetime = datetime.combine(journey_date, datetime.min.time())
        
        # Calculate hours before departure
        hours_before_departure = (journey_datetime - cancellation_date).total_seconds() / 3600
        
        # Apply refund policy
        if hours_before_departure >= 72:  # More than 3 days before
            refund_percentage = 0.9  # 90% refund
        elif hours_before_departure >= 48:  # 2-3 days before
            refund_percentage = 0.75  # 75% refund
        elif hours_before_departure >= 24:  # 1-2 days before
            refund_percentage = 0.5  # 50% refund
        elif hours_before_departure >= 6:  # 6-24 hours before
            refund_percentage = 0.25  # 25% refund
        else:  # Less than 6 hours before
            refund_percentage = 0.0  # No refund
        
        # Calculate refund amount
        refund_amount = fare * refund_percentage
        
        # Round to nearest whole number
        return round(refund_amount)
    
    def _determine_pricing_strategy(self, journey_date: date) -> PricingStrategy:
        """Determine the pricing strategy based on journey date"""
        # Check if weekend
        if journey_date.weekday() >= 5:  # Saturday or Sunday
            return PricingStrategy.WEEKEND
        
        # Check if peak season
        for start_date, end_date in self.peak_seasons:
            if start_date <= journey_date <= end_date:
                return PricingStrategy.PEAK_SEASON
        
        # Check if last minute (within 2 days)
        today = date.today()
        if (journey_date - today).days <= 2:
            return PricingStrategy.LAST_MINUTE
        
        # Default strategy
        return PricingStrategy.DEFAULT 