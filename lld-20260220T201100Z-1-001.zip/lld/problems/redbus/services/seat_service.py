from typing import List, Dict, Optional
from datetime import datetime, timedelta, date
import threading
import uuid

from models.seat import Seat, SeatType, SeatStatus, BusLayout
from models.schedule import Schedule
from models.bus import BusType

class SeatService:
    """
    Service for managing seat layouts, availability, and locking.
    """
    
    def __init__(self):
        # In-memory storage for seat layouts and seats
        self.seat_layouts: Dict[str, BusLayout] = {}
        self.seats: Dict[str, Dict[str, Seat]] = {}  # schedule_id -> {seat_id -> Seat}
        self.locks: Dict[str, Dict[str, tuple]] = {}  # schedule_id -> {seat_id -> (user_id, expiry)}
        self.lock = threading.Lock()
        
        # Lock expiry time in seconds
        self.lock_expiry_seconds = 300  # 5 minutes
    
    def create_seat_layout(self, schedule: Schedule) -> BusLayout:
        """
        Create a seat layout for a schedule based on the bus type
        
        Args:
            schedule: Schedule to create layout for
            
        Returns:
            Created BusLayout
        """
        bus = schedule.bus
        layout_id = f"{schedule.schedule_id}_layout"
        
        # Determine layout dimensions based on bus type
        rows, columns, decks = self._get_layout_dimensions(bus.bus_type)
        
        # Create layout
        layout = BusLayout(layout_id, rows, columns, decks)
        
        # Create seats
        self._create_seats_for_layout(layout, bus.bus_type, schedule.schedule_id)
        
        # Store layout
        self.seat_layouts[schedule.schedule_id] = layout
        
        # Store seats
        self.seats[schedule.schedule_id] = {seat.seat_id: seat for seat in layout.seats.values()}
        
        return layout
    
    def get_seat_layout(self, schedule_id: str) -> Optional[BusLayout]:
        """Get the seat layout for a schedule"""
        return self.seat_layouts.get(schedule_id)
    
    def get_available_seats(self, schedule_id: str) -> List[Seat]:
        """Get available seats for a schedule"""
        if schedule_id not in self.seats:
            return []
            
        # Clean expired locks first
        self._clean_expired_locks(schedule_id)
        
        # Return seats that are available
        return [seat for seat in self.seats[schedule_id].values() 
                if seat.status == SeatStatus.AVAILABLE]
    
    def lock_seat(self, schedule_id: str, seat_id: str, user_id: str, duration_seconds: int = 300) -> bool:
        """Lock a seat temporarily during booking process"""
        if schedule_id not in self.locks:
            self.locks[schedule_id] = {}
            
        # Check if seat is already locked
        if seat_id in self.locks[schedule_id]:
            lock_user, lock_expiry = self.locks[schedule_id][seat_id]
            if lock_expiry > datetime.now() and lock_user != user_id:
                return False  # Locked by another user
                
        # Set or update lock
        expiry = datetime.now() + timedelta(seconds=duration_seconds)
        self.locks[schedule_id][seat_id] = (user_id, expiry)
        return True
    
    def unlock_seat(self, schedule_id: str, seat_id: str, user_id: str) -> bool:
        """Unlock a seat"""
        if (schedule_id in self.locks and 
            seat_id in self.locks[schedule_id] and 
            self.locks[schedule_id][seat_id][0] == user_id):
            del self.locks[schedule_id][seat_id]
            return True
        return False
    
    def is_seat_locked(self, schedule_id: str, seat_id: str, user_id: str = None) -> bool:
        """Check if a seat is locked"""
        if schedule_id not in self.locks or seat_id not in self.locks[schedule_id]:
            return False
            
        lock_user, lock_expiry = self.locks[schedule_id][seat_id]
        
        # If lock has expired, remove it and return False
        if lock_expiry <= datetime.now():
            del self.locks[schedule_id][seat_id]
            return False
            
        # If user_id is provided, check if locked by this user
        if user_id is not None:
            return lock_user != user_id
            
        return True
    
    def book_seats(self, schedule_id: str, seat_ids: List[str], booking_id: str, 
                  journey_date: date, source_idx: int, dest_idx: int) -> bool:
        """Book seats for a booking"""
        with self.lock:
            if schedule_id not in self.seats:
                return False
                
            # Check if all seats are available or locked
            for seat_id in seat_ids:
                if seat_id not in self.seats[schedule_id]:
                    return False
                    
                seat = self.seats[schedule_id][seat_id]
                if seat.status not in [SeatStatus.AVAILABLE, SeatStatus.LOCKED]:
                    return False
            
            # Book all seats
            for seat_id in seat_ids:
                seat = self.seats[schedule_id][seat_id]
                success = seat.book(journey_date, booking_id, source_idx, dest_idx)
                if not success:
                    # Rollback previous bookings
                    for rollback_id in seat_ids:
                        if rollback_id == seat_id:
                            break
                        rollback_seat = self.seats[schedule_id][rollback_id]
                        rollback_seat.cancel_booking(journey_date, booking_id)
                    return False
                
                # Remove any locks
                if schedule_id in self.locks and seat_id in self.locks[schedule_id]:
                    del self.locks[schedule_id][seat_id]
            
            return True
    
    def cancel_seats(self, schedule_id: str, seat_ids: List[str], booking_id: str, 
                    journey_date: date) -> bool:
        """Cancel booked seats"""
        with self.lock:
            if schedule_id not in self.seats:
                return False
                
            for seat_id in seat_ids:
                if seat_id in self.seats[schedule_id]:
                    seat = self.seats[schedule_id][seat_id]
                    seat.cancel_booking(journey_date, booking_id)
            
            return True
    
    def _clean_expired_locks(self, schedule_id: str) -> None:
        """Clean expired locks for a schedule"""
        if schedule_id not in self.locks:
            return
            
        now = datetime.now()
        expired_seat_ids = []
        
        for seat_id, (user_id, expiry_time) in self.locks[schedule_id].items():
            if now > expiry_time:
                expired_seat_ids.append(seat_id)
        
        # Unlock expired seats
        for seat_id in expired_seat_ids:
            if seat_id in self.seats[schedule_id]:
                seat = self.seats[schedule_id][seat_id]
                if seat.status == SeatStatus.LOCKED:
                    seat.unlock()
                del self.locks[schedule_id][seat_id]
    
    def _get_layout_dimensions(self, bus_type: BusType) -> tuple:
        """Get layout dimensions based on bus type"""
        from ..models.bus import BusType
        
        # Default dimensions
        rows, columns, decks = 10, 4, 1
        
        if bus_type == BusType.SEATER:
            rows, columns = 12, 4
        elif bus_type == BusType.SLEEPER:
            rows, columns = 10, 3
        elif bus_type == BusType.AC_SEATER:
            rows, columns = 12, 4
        elif bus_type == BusType.AC_SLEEPER:
            rows, columns = 10, 3
        elif bus_type == BusType.VOLVO:
            rows, columns = 12, 4
        elif bus_type == BusType.MINI_BUS:
            rows, columns = 8, 3
        
        # Sleeper buses often have two decks
        if bus_type in [BusType.SLEEPER, BusType.AC_SLEEPER]:
            decks = 2
        
        return rows, columns, decks
    
    def _create_seats_for_layout(self, layout: BusLayout, bus_type, schedule_id: str) -> None:
        """Create seats for a layout based on bus type"""
        from ..models.bus import BusType
        from ..models.seat import SeatType
        
        # Map bus type to seat type
        seat_type_map = {
            BusType.SEATER: SeatType.SEATER,
            BusType.SLEEPER: SeatType.SLEEPER,
            BusType.AC_SEATER: SeatType.SEATER,
            BusType.AC_SLEEPER: SeatType.SLEEPER,
            BusType.VOLVO: SeatType.SEMI_SLEEPER,
            BusType.MINI_BUS: SeatType.SEATER
        }
        
        seat_type = seat_type_map.get(bus_type, SeatType.SEATER)
        
        # Create seats
        for deck in range(1, layout.decks + 1):
            for row in range(1, layout.rows + 1):
                for col in range(1, layout.columns + 1):
                    # Skip some positions to create aisle
                    if col == 2 and layout.columns >= 4:
                        continue
                    
                    seat_id = f"{schedule_id}_seat_d{deck}r{row}c{col}"
                    seat_number = f"{deck}{row}{col}"
                    
                    # Determine if window seat
                    is_window = (col == 1 or col == layout.columns)
                    
                    # Price multiplier based on position
                    price_multiplier = 1.0
                    if is_window:
                        price_multiplier = 1.1
                    if deck == 2:  # Upper deck
                        price_multiplier *= 1.05
                    
                    seat = Seat(
                        seat_id=seat_id,
                        seat_number=seat_number,
                        seat_type=seat_type,
                        is_window=is_window,
                        price_multiplier=price_multiplier
                    )
                    
                    layout.add_seat(seat)
    
    def get_available_seats_count(self, schedule_id: str) -> int:
        """Get the count of available seats for a schedule"""
        available_seats = self.get_available_seats(schedule_id)
        return len(available_seats) 