from typing import List, Optional, Dict
from uuid import uuid4
from datetime import date

from models.bus import Bus
from models.bus import BusOperator
from models.bus import BusType
from models.bus import BusAmenity
from models.seat import Seat
from models.seat import SeatType
from exceptions import BusNotFoundException, InvalidBusDataException
from services.schedule_service import ScheduleService

class BusService:
    def __init__(self, schedule_service:ScheduleService=None):
        self.buses: Dict[str, Bus] = {}  # Dictionary to store buses with bus_id as key
        self.schedule_service = schedule_service
    
    def create_bus(self, operator: BusOperator, bus_type: BusType, 
                  registration_number: str, total_seats: int,
                  seat_type: SeatType = SeatType.REGULAR) -> Bus:
        """
        Create a new bus with the given details
        """
        # Validate input data
        if not operator or not bus_type or not registration_number:
            raise InvalidBusDataException("Bus operator, type, and registration number are required")
        
        if total_seats <= 0:
            raise InvalidBusDataException("Total seats must be greater than zero")
        
        # Check if registration number is already used
        for bus in self.buses.values():
            if bus.registration_number == registration_number:
                raise InvalidBusDataException(f"Bus with registration number {registration_number} already exists")
        
        # Generate a unique bus ID
        bus_id = str(uuid4())
        
        # Create the bus
        bus = Bus(bus_id, operator, bus_type, registration_number, total_seats)
        
        # Initialize seats
        self._initialize_seats(bus, seat_type)
        
        # Store the bus
        self.buses[bus_id] = bus
        
        return bus
    
    def _initialize_seats(self, bus: Bus, seat_type: SeatType) -> None:
        """
        Initialize seats for a bus based on total_seats count
        """
        bus.seats = []
        for i in range(1, bus.total_seats + 1):
            seat_id = f"{bus.bus_id}_seat_{i}"
            seat_number = str(i)
            bus.seats.append(Seat(seat_id, seat_number, seat_type))
    
    def get_bus(self, bus_id: str) -> Bus:
        """
        Get a bus by its ID
        """
        if bus_id not in self.buses:
            raise BusNotFoundException(f"Bus with ID {bus_id} not found")
        
        return self.buses[bus_id]
    
    def get_all_buses(self) -> List[Bus]:
        """
        Get all buses
        """
        return list(self.buses.values())
    
    def update_bus(self, bus_id: str, operator: Optional[BusOperator] = None, 
                  bus_type: Optional[BusType] = None, 
                  registration_number: Optional[str] = None) -> Bus:
        """
        Update bus details
        """
        bus = self.get_bus(bus_id)
        
        if operator:
            bus.operator = operator
        
        if bus_type:
            bus.bus_type = bus_type
        
        if registration_number:
            # Check if registration number is already used by another bus
            for other_bus in self.buses.values():
                if (other_bus.bus_id != bus_id and 
                    other_bus.registration_number == registration_number):
                    raise InvalidBusDataException(
                        f"Bus with registration number {registration_number} already exists")
            
            bus.registration_number = registration_number
        
        return bus
    
    def delete_bus(self, bus_id: str) -> None:
        """
        Delete a bus
        """
        if bus_id not in self.buses:
            raise BusNotFoundException(f"Bus with ID {bus_id} not found")
        
        del self.buses[bus_id]
    
    def add_amenity(self, bus_id: str, amenity: BusAmenity) -> Bus:
        """
        Add an amenity to a bus
        """
        bus = self.get_bus(bus_id)
        
        if amenity not in bus.amenities:
            bus.amenities.append(amenity)
        
        return bus
    
    def remove_amenity(self, bus_id: str, amenity: BusAmenity) -> Bus:
        """
        Remove an amenity from a bus
        """
        bus = self.get_bus(bus_id)
        
        if amenity in bus.amenities:
            bus.amenities.remove(amenity)
        
        return bus
    
    def add_schedule(self, bus_id: str, schedule_id: str) -> Bus:
        """
        Add a schedule to a bus
        """
        bus = self.get_bus(bus_id)
        
        if schedule_id not in bus.schedules:
            bus.schedules.append(schedule_id)
        
        return bus
    
    def remove_schedule(self, bus_id: str, schedule_id: str) -> Bus:
        """
        Remove a schedule from a bus
        """
        bus = self.get_bus(bus_id)
        
        if schedule_id in bus.schedules:
            bus.schedules.remove(schedule_id)
        
        return bus
    
    def get_available_seats(self, bus_id: str) -> List[Seat]:
        """
        Get all available seats for a bus
        """
        bus = self.get_bus(bus_id)
        return [seat for seat in bus.seats if seat.is_available]
    
    def get_buses_by_operator(self, operator_id: str) -> List[Bus]:
        """
        Get all buses operated by a specific operator
        """
        return [bus for bus in self.buses.values() if bus.operator.operator_id == operator_id]
    
    def get_buses_by_type(self, bus_type: BusType) -> List[Bus]:
        """
        Get all buses of a specific type
        """
        return [bus for bus in self.buses.values() if bus.bus_type == bus_type]
    
    def search_buses(self, from_city: str, to_city: str, journey_date: date, 
                    bus_type: Optional[BusType] = None) -> List[Dict]:
        """
        Search for buses between cities on a specific date
        """
        # This method requires integration with the ScheduleService to find schedules
        # that match the route and date criteria
        
        # Assuming we have access to a schedule_service instance
        matching_schedules = self.schedule_service.get_schedules_by_route_and_date(
            from_city, to_city, journey_date)
        
        results = []
        for schedule in matching_schedules:
            # Get the bus for this schedule
            try:
                bus = self.get_bus(schedule.bus_id)
                
                # Filter by bus_type if specified
                if bus_type and bus.bus_type != bus_type:
                    continue
                
                # Get available seats for this schedule
                available_seats = self.schedule_service.get_available_seats(schedule.schedule_id)
                
                # Create result entry with relevant information
                result = {
                    "schedule_id": schedule.schedule_id,
                    "bus_id": bus.bus_id,
                    "operator_name": bus.operator.name,
                    "bus_type": bus.bus_type.name,
                    "departure_time": schedule.departure_time,
                    "arrival_time": schedule.arrival_time,
                    "journey_duration": schedule.get_duration(),
                    "fare": schedule.fare,
                    "available_seats": len(available_seats),
                    "total_seats": bus.total_seats,
                    "amenities": [amenity.name for amenity in bus.amenities]
                }
                
                results.append(result)
                
            except BusNotFoundException:
                # Skip schedules with missing buses
                continue
        
        # Sort results by departure time
        results.sort(key=lambda x: x["departure_time"])
        
        return results
        
