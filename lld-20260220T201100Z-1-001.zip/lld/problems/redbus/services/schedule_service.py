from typing import List, Dict, Optional
from datetime import date, datetime
from uuid import uuid4

from problems.redbus.models.schedule import Schedule, DayOfWeek
from problems.redbus.models.bus import Bus
from problems.redbus.models.route import Route
from problems.redbus.models.seat import Seat
from problems.redbus.exceptions import ScheduleNotFoundException, InvalidScheduleDataException
from problems.redbus.pricing.fare_strategy import FareStrategy, DefaultFareStrategy
from problems.redbus.pricing.surge_pricing_service import SurgePricingService
from problems.redbus.services.pricing_service import PricingService

class ScheduleService:
    def __init__(self, seat_service=None):
        self.schedules: Dict[str, Schedule] = {}  # Dictionary to store schedules with schedule_id as key
        self.seat_service = seat_service
        self.pricing_service = PricingService()
        self.surge_pricing_service = SurgePricingService()
        self.fare_strategy: FareStrategy = DefaultFareStrategy()
    
    def create_schedule(self, bus: Bus, route: Route, 
                       departure_date: datetime, base_fare: float) -> Schedule:
        """
        Create a new schedule for a bus on a route
        """
        # Validate input data
        if not bus or not route or not departure_date:
            raise InvalidScheduleDataException("Bus, route, and departure date are required")
        
        if base_fare <= 0:
            raise InvalidScheduleDataException("Base fare must be greater than zero")
        
        # Generate a unique schedule ID
        schedule_id = str(uuid4())
        
        # Create the schedule
        schedule = Schedule(schedule_id, bus, route, departure_date, base_fare)
        
        # Add the schedule to the bus
        bus.add_schedule(schedule_id)
        
        # Store the schedule
        self.schedules[schedule_id] = schedule
        
        # Initialize seat layout if seat service is available
        if self.seat_service:
            self.seat_service.create_seat_layout(schedule)
        
        return schedule
    
    def get_schedule(self, schedule_id: str) -> Schedule:
        """
        Get a schedule by its ID
        """
        if schedule_id not in self.schedules:
            raise ScheduleNotFoundException(f"Schedule with ID {schedule_id} not found")
        
        return self.schedules[schedule_id]
    
    def get_all_schedules(self) -> List[Schedule]:
        """
        Get all schedules
        """
        return list(self.schedules.values())
    
    def get_schedules_by_route_and_date(self, from_city: str, to_city: str, 
                                       journey_date: date) -> List[Schedule]:
        """
        Get schedules between cities on a specific date
        """
        matching_schedules = []
        
        for schedule in self.schedules.values():
            # Check if schedule operates on the given date
            if not schedule.is_operating_on_date(journey_date):
                continue
            
            # Check if route contains the cities
            route = schedule.route
            from_stops = [stop.stop for stop in route.stops if stop.stop.city == from_city]
            to_stops = [stop.stop for stop in route.stops if stop.stop.city == to_city]
            
            if not from_stops or not to_stops:
                continue
            
            # Check if from_stop comes before to_stop in the route
            for from_stop in from_stops:
                for to_stop in to_stops:
                    try:
                        from_idx = route.get_stop_index(from_stop)
                        to_idx = route.get_stop_index(to_stop)
                        
                        if from_idx < to_idx:
                            matching_schedules.append(schedule)
                            # Record search for surge pricing
                            self.surge_pricing_service.record_search(from_city, to_city, journey_date)
                            break
                    except ValueError:
                        continue
                else:
                    continue
                break
        
        return matching_schedules
    
    def get_available_seats(self, schedule_id: str) -> List[Seat]:
        """
        Get available seats for a schedule
        """
        if not self.seat_service:
            return []
        
        return self.seat_service.get_available_seats(schedule_id)
    
    def update_schedule(self, schedule_id: str, base_fare: Optional[float] = None, 
                       status: Optional[str] = None) -> Schedule:
        """
        Update schedule details
        """
        schedule = self.get_schedule(schedule_id)
        
        if base_fare is not None and base_fare > 0:
            schedule.base_fare = base_fare
        
        if status is not None:
            schedule.status = status
        
        return schedule
    
    def add_operating_day(self, schedule_id: str, day: DayOfWeek) -> Schedule:
        """
        Add an operating day to a schedule
        """
        schedule = self.get_schedule(schedule_id)
        schedule.add_operating_day(day)
        return schedule
    
    def remove_operating_day(self, schedule_id: str, day: DayOfWeek) -> Schedule:
        """
        Remove an operating day from a schedule
        """
        schedule = self.get_schedule(schedule_id)
        if day in schedule.operating_days:
            schedule.operating_days.remove(day)
        return schedule
    
    def set_fare_strategy(self, strategy: FareStrategy) -> None:
        """
        Set the fare calculation strategy
        """
        self.fare_strategy = strategy
    
    def calculate_seat_fare(self, schedule_id: str, seat: Seat) -> float:
        """
        Calculate fare for a specific seat on a schedule using the current fare strategy
        """
        schedule = self.get_schedule(schedule_id)
        
        # Get base fare from schedule
        base_fare = schedule.base_fare
        
        # Calculate fare using the fare strategy
        fare = self.fare_strategy.calculate_fare(base_fare, seat, schedule)
        
        # Apply pricing service adjustments based on journey date
        journey_date = schedule.departure_date.date()
        fare = self.pricing_service.calculate_fare(fare, journey_date, seat.price_multiplier)
        
        # Apply surge pricing if applicable
        from_city = schedule.route.stops[0].stop.city  # First stop city
        to_city = schedule.route.stops[-1].stop.city   # Last stop city
        surge_factor = self.surge_pricing_service.get_surge_factor(
            from_city, to_city, schedule.departure_date)
        
        # Apply surge factor
        fare = fare * surge_factor
        
        # Round to nearest whole number
        return round(fare)
    
    def update_capacity_for_surge_pricing(self, schedule_id: str) -> None:
        """
        Update capacity information for surge pricing calculations
        """
        schedule = self.get_schedule(schedule_id)
        from_city = schedule.route.stops[0].stop.city
        to_city = schedule.route.stops[-1].stop.city
        
        # Get booked and total seats
        available_seats = len(self.get_available_seats(schedule_id))
        total_seats = schedule.bus.total_seats
        booked_seats = total_seats - available_seats
        
        # Update surge pricing service
        self.surge_pricing_service.record_capacity(
            from_city, to_city, schedule.departure_date, 
            booked_seats, total_seats) 