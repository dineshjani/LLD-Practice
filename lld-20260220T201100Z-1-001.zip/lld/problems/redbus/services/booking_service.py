from typing import List, Dict, Optional, Tuple
from datetime import datetime, date
import uuid

from ..models.booking import Booking, Passenger, BookingStatus
from ..models.schedule import Schedule
from ..models.location import BusStop
from ..services.seat_service import SeatService
from ..services.pricing_service import PricingService
from ..services.notification_service import NotificationService
from ..patterns.observer import Subject

class BookingService(Subject):
    """
    Service for managing bookings, including creation, retrieval, and cancellation.
    """
    
    def __init__(self, seat_service: SeatService, pricing_service: PricingService, notification_service: NotificationService = None):
        super().__init__()  # Initialize the Subject
        self.seat_service = seat_service
        self.pricing_service = pricing_service
        self.notification_service = notification_service
        self.bookings: Dict[str, Booking] = {}
    
    def create_booking(self, user_id: str, schedule: Schedule, 
                      source: BusStop, destination: BusStop, 
                      journey_date: date, passengers: List[Passenger], 
                      seat_ids: List[str]) -> Booking:
        """
        Create a new booking
        
        Args:
            user_id: ID of the user making the booking
            schedule: Schedule being booked
            source: Source bus stop
            destination: Destination bus stop
            journey_date: Date of journey
            passengers: List of passengers
            seat_ids: List of seat IDs to book
            
        Returns:
            Created Booking object
        """
        # Validate inputs
        if len(passengers) != len(seat_ids):
            raise ValueError("Number of passengers must match number of seats")
            
        # Check if route contains source and destination
        route = schedule.route
        if not route.is_stop_on_route(source) or not route.is_stop_on_route(destination):
            raise ValueError("Source or destination not on route")
            
        # Get stop indices
        source_idx = route.get_stop_index(source)
        dest_idx = route.get_stop_index(destination)
        
        if source_idx >= dest_idx:
            raise ValueError("Source must come before destination")
        
        # Lock seats
        if not self.seat_service.lock_seats(schedule.schedule_id, seat_ids, user_id):
            raise ValueError("Failed to lock seats")
        
        try:
            # Create booking
            booking_id = f"BK{uuid.uuid4().hex[:8].upper()}"
            booking = Booking(
                booking_id=booking_id,
                user_id=user_id,
                schedule=schedule,
                source=source,
                destination=destination,
                journey_date=journey_date
            )
            
            # Set stop indices for seat availability tracking
            booking.source_stop_index = source_idx
            booking.destination_stop_index = dest_idx
            
            # Add passengers
            for i, passenger in enumerate(passengers):
                booking.add_passenger(passenger)
            
            # Calculate total fare
            total_fare = 0.0
            for i, seat_id in enumerate(seat_ids):
                # Get seat
                seat = self.seat_service.seats[schedule.schedule_id][seat_id]
                
                # Calculate fare for this seat
                fare = self.pricing_service.calculate_fare(
                    schedule.base_fare,
                    journey_date,
                    seat.price_multiplier
                )
                
                # Assign seat to passenger
                passengers[i].assign_seat(seat)
                
                # Add to total
                total_fare += fare
            
            # Set total amount
            booking.total_amount = total_fare
            
            # Book seats
            if not self.seat_service.book_seats(
                schedule.schedule_id, 
                seat_ids, 
                booking_id, 
                journey_date, 
                source_idx, 
                dest_idx
            ):
                raise ValueError("Failed to book seats")
            
            # Store booking
            self.bookings[booking_id] = booking
            
            # Send notification
            if self.notification_service:
                self.notification_service.send_booking_confirmation(booking)
            
            # Notify observers
            self.notify("booking_created", {
                "booking_id": booking_id,
                "user_id": user_id,
                "schedule_id": schedule.schedule_id,
                "seat_ids": seat_ids,
                "total_fare": total_fare,
                "from_city": source.city,
                "to_city": destination.city,
                "journey_date": journey_date
            })
            
            return booking
            
        except Exception as e:
            # Unlock seats in case of error
            self.seat_service.unlock_seats(schedule.schedule_id, seat_ids)
            raise e
    
    def get_booking_by_id(self, booking_id: str) -> Optional[Booking]:
        """Get a booking by ID"""
        return self.bookings.get(booking_id)
    
    def get_user_bookings(self, user_id: str) -> List[Booking]:
        """Get all bookings for a user"""
        return [booking for booking in self.bookings.values() if booking.user_id == user_id]
    
    def cancel_booking(self, booking_id: str) -> Tuple[bool, float]:
        """
        Cancel a booking
        
        Args:
            booking_id: ID of the booking to cancel
            
        Returns:
            Tuple of (success, refund_amount)
        """
        booking = self.get_booking_by_id(booking_id)
        if not booking:
            return False, 0.0
            
        # Check if already cancelled
        if booking.status == BookingStatus.CANCELLED:
            return False, 0.0
            
        # Calculate refund
        refund_amount = self.pricing_service.calculate_refund(
            booking.total_amount,
            booking.booking_time,
            booking.journey_date,
            datetime.now()
        )
        
        # Get seat IDs
        seat_ids = [passenger.seat.seat_id for passenger in booking.passengers if passenger.seat]
        
        # Cancel seats
        self.seat_service.cancel_seats(
            booking.schedule.schedule_id,
            seat_ids,
            booking_id,
            booking.journey_date
        )
        
        # Update booking status
        booking.cancel()
        
        # Send notification
        if self.notification_service:
            self.notification_service.send_cancellation_confirmation(booking, refund_amount)
        
        # Notify observers
        self.notify("booking_cancelled", {
            "booking_id": booking_id,
            "user_id": booking.user_id,
            "schedule_id": booking.schedule.schedule_id,
            "seat_ids": seat_ids,
            "refund_amount": refund_amount,
            "from_city": booking.source.city,
            "to_city": booking.destination.city,
            "journey_date": booking.journey_date
        })
        
        return True, refund_amount
    
    def send_journey_reminder(self, days_before: int = 1) -> int:
        """
        Send journey reminders for upcoming bookings
        
        Args:
            days_before: Number of days before journey to send reminder
            
        Returns:
            Number of reminders sent
        """
        today = date.today()
        reminder_count = 0
        
        for booking in self.bookings.values():
            # Skip cancelled bookings
            if booking.status == BookingStatus.CANCELLED:
                continue
                
            # Check if journey is in 'days_before' days
            days_until_journey = (booking.journey_date - today).days
            if days_until_journey == days_before:
                # Send reminder
                if self.notification_service:
                    self.notification_service.send_journey_reminder(booking)
                    reminder_count += 1
                
                # Notify observers
                self.notify("journey_reminder_sent", {
                    "booking_id": booking.booking_id,
                    "user_id": booking.user_id,
                    "journey_date": booking.journey_date
                })
        
        return reminder_count 