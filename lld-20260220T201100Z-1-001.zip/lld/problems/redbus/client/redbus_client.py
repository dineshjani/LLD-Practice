from datetime import date, time, datetime
from typing import List, Dict, Optional, Tuple

from ..models.bus import Bus, BusType, BusOperator, BusAmenity
from ..models.route import Route
from ..models.schedule import Schedule, DayOfWeek
from ..models.location import BusStop
from ..models.seat import Seat, SeatType
from ..models.booking import Booking, Passenger, Gender, BookingStatus
from ..models.user import User

from ..services.bus_service import BusService
from ..services.booking_service import BookingService
from ..services.seat_service import SeatService
from ..services.pricing_service import PricingService
from ..services.notification_service import NotificationService
from ..services.notification_service import BookingAnalyticsObserver
from ..services.notification_service import InventoryObserver
from ..services.notification_service import SurgePricingObserver
from ..services.notification_service import UserActivityObserver


class RedBusClient:
    """
    Main client class for interacting with the RedBus bus booking system.
    This serves as a facade to the underlying services.
    """
    
    def __init__(self):
        # Initialize services
        self.bus_service = BusService()
        self.seat_service = SeatService()
        self.pricing_service = PricingService()
        self.booking_service = BookingService(
            self.seat_service,
            self.pricing_service
        )
        self.notification_service = NotificationService()
        
        # Initialize data store for bus stops
        self.bus_stops: Dict[str, BusStop] = {}
        self._setup_observers()
    
    def _setup_observers(self):
        """
        Set up observers for the booking service
        """
        # Create observers
        analytics_observer = BookingAnalyticsObserver()
        inventory_observer = InventoryObserver(self.seat_service)
        surge_pricing_observer = SurgePricingObserver(self.surge_pricing_service)
        user_activity_observer = UserActivityObserver()
        
        # Attach observers to booking service
        self.booking_service.attach(analytics_observer)
        self.booking_service.attach(inventory_observer)
        self.booking_service.attach(surge_pricing_observer)
        self.booking_service.attach(user_activity_observer)
        
        print("Observer pattern set up successfully")
    
    # Bus Stop Management
    def add_bus_stop(self, stop_id: str, name: str, city: str) -> BusStop:
        """Add a new bus stop to the system"""
        if stop_id in self.bus_stops:
            raise ValueError(f"Bus stop with ID {stop_id} already exists")
        
        bus_stop = BusStop(stop_id, name, city)
        self.bus_stops[stop_id] = bus_stop
        return bus_stop
    
    def get_bus_stop(self, stop_id: str) -> BusStop:
        """Get a bus stop by its ID"""
        if stop_id not in self.bus_stops:
            raise ValueError(f"Bus stop with ID {stop_id} not found")
        return self.bus_stops[stop_id]
    
    # Bus Management
    def add_bus(self, bus_id: str, operator_name: str, bus_type: BusType, 
               registration_number: str, total_seats: int) -> Bus:
        """Add a new bus to the system"""
        return self.bus_service.add_bus(
            bus_id, operator_name, bus_type, registration_number, total_seats
        )
    
    def create_route(self, route_id: str, name: str) -> Route:
        """Create a new route"""
        return self.bus_service.create_route(route_id, name)
    
    def add_route_stop(self, route_id: str, stop_id: str, distance_from_prev: int = 0) -> None:
        """Add a stop to a route"""
        route = self.bus_service.get_route(route_id)
        bus_stop = self.get_bus_stop(stop_id)
        self.bus_service.add_route_stop(route, bus_stop, distance_from_prev)
    
    def create_schedule(self, schedule_id: str, bus_id: str, route_id: str, 
                      departure_date: datetime, base_fare: float) -> Schedule:
        """Create a new schedule for a bus on a route"""
        bus = self.bus_service.get_bus(bus_id)
        route = self.bus_service.get_route(route_id)
        return self.bus_service.create_schedule(
            schedule_id, bus, route, departure_date, base_fare
        )
    
    def add_operating_day(self, schedule_id: str, day: DayOfWeek) -> None:
        """Add an operating day to a schedule"""
        schedule = self.bus_service.get_schedule(schedule_id)
        schedule.add_operating_day(day)
    
    # Search and Availability
    def search_buses(self, from_city: str, to_city: str, journey_date: date, 
                    bus_type: Optional[BusType] = None) -> List[Dict]:
        """Search for buses between cities on a specific date"""
        schedules = self.bus_service.search_buses(from_city, to_city, journey_date, bus_type)
        
        result = []
        for schedule in schedules:
            result.append({
                'schedule_id': schedule.schedule_id,
                'bus_type': schedule.bus.bus_type.value,
                'operator_name': schedule.bus.operator.name,
                'departure_time': schedule.departure_date.strftime("%Y-%m-%d %H:%M"),
                'arrival_time': schedule.get_arrival_date().strftime("%Y-%m-%d %H:%M"),
                'fare': schedule.base_fare,
                'available_seats': schedule.get_available_seats_count()
            })
        
        return result
    
    def get_available_seats(self, schedule_id: str) -> List[Dict]:
        """Get available seats for a schedule"""
        schedule = self.bus_service.get_schedule(schedule_id)
        seats = self.seat_service.get_available_seats(schedule_id)
        
        result = []
        for seat in seats:
            result.append({
                'seat_id': seat.seat_id,
                'seat_number': seat.seat_number,
                'seat_type': seat.seat_type.value,
                'is_window': seat.is_window,
                'price': schedule.base_fare * seat.price_multiplier
            })
        
        return result
    
    def get_seat_layout(self, schedule_id: str) -> Dict:
        """Get the seat layout for a schedule"""
        layout = self.seat_service.get_seat_layout(schedule_id)
        if not layout:
            return {}
        
        return {
            'layout_id': layout.layout_id,
            'rows': layout.rows,
            'columns': layout.columns,
            'decks': layout.decks,
            'seats': [
                {
                    'seat_id': seat.seat_id,
                    'seat_number': seat.seat_number,
                    'seat_type': seat.seat_type.value,
                    'is_window': seat.is_window,
                    'status': seat.status.value
                }
                for seat in layout.seats.values()
            ]
        }
    
    # Booking Management
    def book_tickets(self, user_id: str, schedule_id: str, source_id: str, 
                   destination_id: str, journey_date: date, 
                   passengers: List[Dict], seat_ids: List[str]) -> Dict:
        """Book tickets for multiple passengers"""
        schedule = self.bus_service.get_schedule(schedule_id)
        source = self.get_bus_stop(source_id)
        destination = self.get_bus_stop(destination_id)
        
        # Convert passenger dictionaries to Passenger objects
        passenger_objects = []
        for p in passengers:
            gender = Gender[p['gender']]
            passenger = Passenger(p['name'], p['age'], gender)
            passenger_objects.append(passenger)
        
        # Book tickets
        booking = self.booking_service.create_booking(
            user_id, schedule, source, destination, journey_date,
            passenger_objects, seat_ids
        )
        
        # Send notification
        self.notification_service.send_booking_confirmation(booking)
        
        return {
            'booking_id': booking.booking_id,
            'status': booking.status.value,
            'total_amount': booking.total_amount,
            'journey_date': journey_date.strftime("%Y-%m-%d"),
            'passengers': len(booking.passengers)
        }
    
    def get_booking_details(self, booking_id: str) -> Optional[Dict]:
        """Get booking details by booking ID"""
        booking = self.booking_service.get_booking_by_id(booking_id)
        if not booking:
            return None
        
        return {
            'booking_id': booking.booking_id,
            'user_id': booking.user_id,
            'schedule_id': booking.schedule.schedule_id,
            'source': booking.source.name,
            'destination': booking.destination.name,
            'journey_date': booking.journey_date.strftime("%Y-%m-%d"),
            'status': booking.status.value,
            'total_amount': booking.total_amount,
            'passengers': [
                {
                    'name': p.name,
                    'age': p.age,
                    'gender': p.gender.value,
                    'seat_number': p.seat.seat_number if p.seat else None
                }
                for p in booking.passengers
            ]
        }
    
    def cancel_booking(self, booking_id: str) -> Tuple[bool, float]:
        """Cancel a booking"""
        success, refund_amount = self.booking_service.cancel_booking(booking_id)
        
        if success:
            booking = self.booking_service.get_booking_by_id(booking_id)
            self.notification_service.send_cancellation_confirmation(booking, refund_amount)
        
        return success, refund_amount 