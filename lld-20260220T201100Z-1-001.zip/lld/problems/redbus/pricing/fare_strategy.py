from abc import ABC, abstractmethod
from typing import Optional
from datetime import datetime

from problems.redbus.models.seat import Seat
from problems.redbus.models.schedule import Schedule

class FareStrategy(ABC):
    """
    Abstract base class for fare calculation strategies
    """
    @abstractmethod
    def calculate_fare(self, base_fare: float, seat: Seat, schedule: Optional[Schedule] = None) -> float:
        """
        Calculate fare based on the strategy
        
        Args:
            base_fare: Base fare for the schedule
            seat: Seat for which fare is being calculated
            schedule: Optional schedule information
            
        Returns:
            Calculated fare
        """
        pass


class DefaultFareStrategy(FareStrategy):
    """
    Default fare strategy that applies seat multiplier to base fare
    """
    def calculate_fare(self, base_fare: float, seat: Seat, schedule: Optional[Schedule] = None) -> float:
        """
        Calculate fare by applying seat price multiplier to base fare
        """
        return base_fare * seat.price_multiplier


class DistanceBasedFareStrategy(FareStrategy):
    """
    Fare strategy that calculates fare based on distance between stops
    """
    def calculate_fare(self, base_fare: float, seat: Seat, schedule: Optional[Schedule] = None) -> float:
        """
        Calculate fare based on distance and seat type
        """
        if not schedule:
            return base_fare * seat.price_multiplier
        
        # Calculate distance between stops
        route = schedule.route
        total_distance = route.get_total_distance()
        
        # Apply distance-based pricing
        distance_multiplier = 1.0
        if total_distance > 500:  # Long distance
            distance_multiplier = 1.5
        elif total_distance > 200:  # Medium distance
            distance_multiplier = 1.2
        
        return base_fare * distance_multiplier * seat.price_multiplier


class TimeBasedFareStrategy(FareStrategy):
    """
    Fare strategy that calculates fare based on time of day
    """
    def calculate_fare(self, base_fare: float, seat: Seat, schedule: Optional[Schedule] = None) -> float:
        """
        Calculate fare based on time of day and seat type
        """
        if not schedule:
            return base_fare * seat.price_multiplier
        
        # Get departure hour
        departure_hour = schedule.departure_date.hour
        
        # Apply time-based pricing
        time_multiplier = 1.0
        if 6 <= departure_hour < 9:  # Morning peak
            time_multiplier = 1.3
        elif 17 <= departure_hour < 21:  # Evening peak
            time_multiplier = 1.3
        elif 22 <= departure_hour or departure_hour < 5:  # Night
            time_multiplier = 0.9
        
        return base_fare * time_multiplier * seat.price_multiplier


class DynamicFareStrategy(FareStrategy):
    """
    Dynamic fare strategy that combines multiple factors
    """
    def calculate_fare(self, base_fare: float, seat: Seat, schedule: Optional[Schedule] = None) -> float:
        """
        Calculate fare based on multiple factors including distance, time, and seat type
        """
        if not schedule:
            return base_fare * seat.price_multiplier
        
        # Calculate distance multiplier
        route = schedule.route
        total_distance = route.get_total_distance()
        
        distance_multiplier = 1.0
        if total_distance > 500:  # Long distance
            distance_multiplier = 1.4
        elif total_distance > 200:  # Medium distance
            distance_multiplier = 1.2
        
        # Calculate time multiplier
        departure_hour = schedule.departure_date.hour
        
        time_multiplier = 1.0
        if 6 <= departure_hour < 9:  # Morning peak
            time_multiplier = 1.2
        elif 17 <= departure_hour < 21:  # Evening peak
            time_multiplier = 1.2
        elif 22 <= departure_hour or departure_hour < 5:  # Night
            time_multiplier = 0.9
        
        # Calculate days in advance
        days_in_advance = (schedule.departure_date.date() - datetime.now().date()).days
        
        advance_multiplier = 1.0
        if days_in_advance <= 1:  # Last minute
            advance_multiplier = 1.3
        elif days_in_advance <= 3:  # Short notice
            advance_multiplier = 1.1
        elif days_in_advance >= 30:  # Far in advance
            advance_multiplier = 0.9
        
        # Combine all multipliers
        combined_multiplier = (distance_multiplier * time_multiplier * 
                              advance_multiplier * seat.price_multiplier)
        
        return base_fare * combined_multiplier 