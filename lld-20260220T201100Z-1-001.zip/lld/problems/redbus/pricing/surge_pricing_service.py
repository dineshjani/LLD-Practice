from datetime import datetime
from typing import Dict, Optional, Tuple

class SurgePricingService:
    def __init__(self):
        # Track demand for each route on each date
        self.search_tracker: Dict[str, int] = {}  # Track searches
        self.booking_tracker: Dict[str, int] = {}  # Track actual bookings
        self.capacity_tracker: Dict[str, Tuple[int, int]] = {}  # Track (booked seats, total seats)
    
    def record_search(self, from_city: str, to_city: str, date: datetime) -> None:
        """Record a search to track demand"""
        key = self._get_route_date_key(from_city, to_city, date)
        if key in self.search_tracker:
            self.search_tracker[key] += 1
        else:
            self.search_tracker[key] = 1
    
    def record_booking(self, from_city: str, to_city: str, date: datetime, num_seats: int = 1) -> None:
        """Record a booking to track actual demand"""
        key = self._get_route_date_key(from_city, to_city, date)
        if key in self.booking_tracker:
            self.booking_tracker[key] += num_seats
        else:
            self.booking_tracker[key] = num_seats
    
    def record_capacity(self, from_city: str, to_city: str, date: datetime, 
                       booked_seats: int, total_seats: int) -> None:
        """Record capacity information for a route"""
        key = self._get_route_date_key(from_city, to_city, date)
        self.capacity_tracker[key] = (booked_seats, total_seats)
    
    def get_surge_factor(self, from_city: str, to_city: str, date: datetime) -> float:
        """Calculate surge factor based on demand and capacity"""
        key = self._get_route_date_key(from_city, to_city, date)
        search_demand = self.search_tracker.get(key, 0)
        booking_demand = self.booking_tracker.get(key, 0)
        capacity = self.capacity_tracker.get(key, (0, 100))  # Default to 0 booked out of 100
        
        # Calculate occupancy percentage if we have capacity data
        occupancy_percentage = 0
        if capacity[1] > 0:  # Avoid division by zero
            occupancy_percentage = (capacity[0] / capacity[1]) * 100
        
        # Combined demand factor (weighted average of searches and bookings)
        # Bookings are weighted more heavily as they represent actual demand
        combined_demand = (0.3 * search_demand + 0.7 * booking_demand * 10)
        
        # Surge based on combined demand
        demand_surge = 1.0
        if combined_demand > 1000:
            demand_surge = 2.0  # 2x pricing for very high demand
        elif combined_demand > 500:
            demand_surge = 1.5  # 1.5x pricing for high demand
        elif combined_demand > 200:
            demand_surge = 1.2  # 1.2x pricing for medium demand
        
        # Surge based on occupancy
        occupancy_surge = 1.0
        if occupancy_percentage > 80:
            occupancy_surge = 2.0  # 2x pricing when >80% full
        elif occupancy_percentage > 60:
            occupancy_surge = 1.5  # 1.5x pricing when >60% full
        elif occupancy_percentage > 40:
            occupancy_surge = 1.2  # 1.2x pricing when >40% full
        
        # Take the maximum of the two surge factors
        return max(demand_surge, occupancy_surge)
    
    def _get_route_date_key(self, from_city: str, to_city: str, date: datetime) -> str:
        """Create a key for tracking demand on a specific route and date"""
        date_str = date.strftime("%Y-%m-%d")
        return f"{from_city}_{to_city}_{date_str}" 