from datetime import datetime, date
from typing import List, Optional
from enum import Enum
import uuid

from .bus import Bus
from .seat import Seat
from .location import BusStop
from .schedule import Schedule

class Gender(Enum):
    MALE = "MALE"
    FEMALE = "FEMALE"
    OTHER = "OTHER"

class BookingStatus(Enum):
    CONFIRMED = "CONFIRMED"
    CANCELLED = "CANCELLED"
    PENDING = "PENDING"

class Passenger:
    def __init__(self, name: str, age: int, gender: Gender):
        self.name = name
        self.age = age
        self.gender = gender
        self.seat: Optional[Seat] = None
    
    def assign_seat(self, seat: Seat) -> None:
        self.seat = seat

class Booking:
    def __init__(self, booking_id: str, user_id: str, schedule: Schedule, 
                source: BusStop, destination: BusStop, journey_date: date):
        self.booking_id = booking_id
        self.user_id = user_id
        self.schedule = schedule
        self.source = source
        self.destination = destination
        self.journey_date = journey_date
        self.passengers: List[Passenger] = []
        self.status = BookingStatus.CONFIRMED
        self.booking_time = datetime.now()
        self.cancellation_time: Optional[datetime] = None
        self.total_amount: float = 0.0
        
        # For seat availability tracking
        self.source_stop_index: int = -1
        self.destination_stop_index: int = -1
    
    def add_passenger(self, passenger: Passenger) -> None:
        self.passengers.append(passenger)
    
    def cancel(self) -> None:
        self.status = BookingStatus.CANCELLED
        self.cancellation_time = datetime.now() 