class BusStop:
    def __init__(self, stop_id: str, name: str, city: str):
        self.stop_id = stop_id
        self.name = name
        self.city = city
    
    def __eq__(self, other):
        if not isinstance(other, BusStop):
            return False
        return self.stop_id == other.stop_id
    
    def __hash__(self):
        return hash(self.stop_id) 