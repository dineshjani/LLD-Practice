from typing import List, Dict
from .location import BusStop

class RouteStop:
    def __init__(self, stop: BusStop, distance_from_prev: int = 0):
        self.stop = stop
        self.distance_from_prev = distance_from_prev

class Route:
    def __init__(self, route_id: str, name: str):
        self.route_id = route_id
        self.name = name
        self.stops: List[RouteStop] = []
        self._stop_indices: Dict[str, int] = {}  # stop_id -> index
    
    def add_stop(self, stop: BusStop, distance_from_prev: int = 0) -> None:
        """Add a stop to the route with distance from previous stop"""
        route_stop = RouteStop(stop, distance_from_prev)
        stop_idx = len(self.stops)
        self.stops.append(route_stop)
        self._stop_indices[stop.stop_id] = stop_idx
    
    def get_distance(self, source: BusStop, destination: BusStop) -> int:
        """Calculate total distance between two stops on the route"""
        if source.stop_id not in self._stop_indices or destination.stop_id not in self._stop_indices:
            raise ValueError("Stops not on this route")
            
        source_idx = self._stop_indices[source.stop_id]
        dest_idx = self._stop_indices[destination.stop_id]
        
        if source_idx > dest_idx:
            raise ValueError("Source stop comes after destination stop")
            
        total_distance = 0
        for i in range(source_idx, dest_idx):
            total_distance += self.stops[i+1].distance_from_prev
            
        return total_distance
    
    def is_stop_on_route(self, stop: BusStop) -> bool:
        return stop.stop_id in self._stop_indices
    
    def get_stop_index(self, stop: BusStop) -> int:
        if not self.is_stop_on_route(stop):
            raise ValueError(f"Stop {stop.stop_id} not on route {self.route_id}")
        return self._stop_indices[stop.stop_id] 