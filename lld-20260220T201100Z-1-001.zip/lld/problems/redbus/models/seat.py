from enum import Enum
from typing import Dict, List, Optional, Tuple
from datetime import date
from .booking import Booking
class SeatType(Enum):
    REGULAR = "REGULAR"
    SLEEPER = "SLEEPER"
    LUXURY = "LUXURY"

class SeatStatus(Enum):
    AVAILABLE = "AVAILABLE"
    BOOKED = "BOOKED"
    LOCKED = "LOCKED"
    MAINTENANCE = "MAINTENANCE"

class Seat:
    def __init__(self, seat_id: str, seat_type: SeatType):
        self.seat_id = seat_id
        self.seat_type = seat_type
        self.status = SeatStatus.AVAILABLE
        # Map of schedule_id -> list of segment bookings
        # Each segment booking contains (from_stop, to_stop, booking_id)
        self.schedule_bookings: Dict[str, List[Booking]] = {}
    
    def is_available(self, schedule_id: str, from_stop: str, to_stop: str, route_stops: List[str]) -> bool:
        """Check if seat is available for a specific journey segment on a specific schedule"""
        if schedule_id not in self.schedule_bookings:
            return True
            
        # Get indices of stops in the route
        from_idx = route_stops.index(from_stop)
        to_idx = route_stops.index(to_stop)
        
        # Check if any existing booking overlaps with requested segment
        for booking in self.schedule_bookings[schedule_id]:
            booking_from_idx = route_stops.index(booking.from_stop)
            booking_to_idx = route_stops.index(booking.to_stop)
            
            # Check for overlap
            if max(from_idx, booking_from_idx) < min(to_idx, booking_to_idx):
                return False
                
        return True
    
    def add_booking(self, schedule_id: str, booking: Booking) -> None:
        """Add a booking for this seat on a specific schedule"""
        if schedule_id not in self.schedule_bookings:
            self.schedule_bookings[schedule_id] = []
        self.schedule_bookings[schedule_id].append(booking)
    
    def remove_booking(self, schedule_id: str, booking_id: str) -> None:
        """Remove a booking from this seat for a specific schedule"""
        if schedule_id in self.schedule_bookings:
            self.schedule_bookings[schedule_id] = [
                b for b in self.schedule_bookings[schedule_id] if b.id != booking_id
            ]
    
    def book(self, journey_date: date, booking: Booking, source_idx: int, dest_idx: int, route_stops: List[str]) -> bool:
        """Book this seat for a specific journey segment"""
        if self.status != SeatStatus.AVAILABLE:
            return False
        
        schedule_id = str(journey_date)
        
        # Check if seat is already booked for any overlapping segment
        if schedule_id in self.schedule_bookings:
            for existing_booking in self.schedule_bookings[schedule_id]:
                from_stop = existing_booking.from_stop
                to_stop = existing_booking.to_stop
                seg_source = route_stops.index(from_stop)
                seg_dest = route_stops.index(to_stop)
                
                # Check for overlap
                if (source_idx < seg_dest and dest_idx > seg_source):
                    return False
        
        # Book the seat using add_booking
        self.add_booking(schedule_id=schedule_id, booking=booking)
        
        self.status = SeatStatus.BOOKED
        return True
    
    def cancel_booking(self, journey_date: date, booking_id: str) -> bool:
        """Cancel a booking for this seat"""
        schedule_id = str(journey_date)
        
        if schedule_id not in self.schedule_bookings:
            return False
            
        # Check if booking exists
        booking_exists = any(b.id == booking_id for b in self.schedule_bookings[schedule_id])
        if not booking_exists:
            return False
        
        # Remove the booking using remove_booking
        self.remove_booking(schedule_id=schedule_id, booking_id=booking_id)
        
        self.status = SeatStatus.AVAILABLE
        return True
    
    def lock(self) -> bool:
        """Lock the seat temporarily during booking process"""
        if self.status != SeatStatus.AVAILABLE:
            return False
        
        self.status = SeatStatus.LOCKED
        return True
    
    def unlock(self) -> bool:
        """Unlock a previously locked seat"""
        if self.status != SeatStatus.LOCKED:
            return False
        
        self.status = SeatStatus.AVAILABLE
        return True

class BusLayout:
    def __init__(self, layout_id: str, rows: int, columns: int, decks: int = 1):
        self.layout_id = layout_id
        self.rows = rows
        self.columns = columns
        self.decks = decks
        self.seats: Dict[str, Seat] = {}  # seat_id -> Seat
    
    def add_seat(self, seat: Seat) -> None:
        self.seats[seat.seat_id] = seat
    
    def get_seat(self, seat_id: str) -> Optional[Seat]:
        return self.seats.get(seat_id) 