from datetime import date, time, datetime, timedelta
from typing import List, Dict, Optional, Set
from enum import Enum
import uuid

from .route import Route
from .location import BusStop
from .bus import Bus
from .seat import Seat

class DayOfWeek(Enum):
    MONDAY = 0
    TUESDAY = 1
    WEDNESDAY = 2
    THURSDAY = 3
    FRIDAY = 4
    SATURDAY = 5
    SUNDAY = 6

class Schedule:
    def __init__(self, schedule_id: str, bus: Bus, route: Route, 
                departure_date: datetime, base_fare: float):
        self.schedule_id = schedule_id
        self.bus = bus
        self.route = route
        self.departure_date = departure_date
        self.base_fare = base_fare
        self.operating_days: Set[DayOfWeek] = set()
        self.status = "ACTIVE"
    
    def add_operating_day(self, day: DayOfWeek) -> None:
        self.operating_days.add(day)
    
    def is_operating_on_date(self, journey_date: date) -> bool:
        schedule_date = self.departure_date.date()
        if journey_date != schedule_date:
            return False
            
        day_of_week = DayOfWeek(journey_date.weekday())
        return day_of_week in self.operating_days
    
    def get_arrival_date(self) -> datetime:
        # Calculate arrival time based on route distance and average speed
        # This is a simplified calculation
        total_distance = sum(stop.distance_from_prev for stop in self.route.stops)
        avg_speed_kmh = 60  # Average speed in km/h
        travel_hours = total_distance / avg_speed_kmh
        
        return self.departure_date + timedelta(hours=travel_hours)

    def get_available_seats(self, from_stop: str, to_stop: str) -> List[Seat]:
        """Get all available seats for this schedule and journey segment"""
        route_stops = [stop.name for stop in self.route.stops]
        return self.bus.get_available_seats(self.schedule_id, from_stop, to_stop, route_stops)