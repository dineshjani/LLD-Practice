from enum import Enum
from typing import List, Dict, Optional, Tuple
from datetime import datetime
from .seat import Seat, SeatType

class BusType:
    SLEEPER = "SLEEPER"
    AC_SLEEPER = "AC_SLEEPER"
    SEATER = "SEATER"
    AC_SEATER = "AC_SEATER"
    LUXURY = "LUXURY"

class BusAmenity(Enum):
    WIFI = "WIFI"
    CHARGING_POINT = "CHARGING_POINT"
    WATER_BOTTLE = "WATER_BOTTLE"
    BLANKET = "BLANKET"
    READING_LIGHT = "READING_LIGHT"
    ENTERTAINMENT = "ENTERTAINMENT"

class BusOperator:
    def __init__(self, operator_id: str, name: str):
        self.operator_id = operator_id
        self.name = name
        self.rating = 0.0
        self.buses: List[str] = []  # List of bus_ids
    
    def add_bus(self, bus_id: str) -> None:
        self.buses.append(bus_id)

class Bus:
    def __init__(self, bus_id: str, bus_type: str, total_seats: int, amenities: List[str] = None):
        self.bus_id = bus_id
        self.bus_type = bus_type
        self.amenities = amenities or []
        self.seats: Dict[str, Seat] = {}  # seat_id -> Seat
        
        # Initialize seats based on bus type and total seats
        self._initialize_seats(total_seats)
    
    def _initialize_seats(self, total_seats: int) -> None:
        """Initialize seats based on bus type and total seats"""
        # Logic to create seats based on bus type (sleeper, AC, etc.)
        for i in range(1, total_seats + 1):
            seat_id = f"S{i}"
            
            # Determine seat type based on bus type and position
            if self.bus_type in [BusType.SLEEPER, BusType.AC_SLEEPER]:
                seat_type = SeatType.SLEEPER
            elif self.bus_type == BusType.LUXURY:
                seat_type = SeatType.LUXURY
            else:
                seat_type = SeatType.REGULAR
                
            self.seats[seat_id] = Seat(seat_id, seat_type)
    
    def get_seat(self, seat_id: str) -> Optional[Seat]:
        """Get a seat by seat_id"""
        return self.seats.get(seat_id)
    
    def get_available_seats(self, schedule_id: str, from_stop: str, to_stop: str, route_stops: List[str]) -> List[Seat]:
        """Get all available seats for a specific journey segment"""
        available_seats = []
        for seat in self.seats.values():
            if seat.is_available(schedule_id, from_stop, to_stop, route_stops):
                available_seats.append(seat)
        return available_seats
    
    def add_amenity(self, amenity: BusAmenity) -> None:
        if amenity not in self.amenities:
            self.amenities.append(amenity)
    
    def add_schedule(self, schedule_id: str) -> None:
        """Add a schedule to this bus"""
        if schedule_id not in self.schedules:
            self.schedules.append(schedule_id) 