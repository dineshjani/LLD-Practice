1| Question: Design a bus ticket booking system like RedBus where users can search for buses, select seats, and book tickets.
2| Key Requirements:
3| Users should be able to search buses between cities on specific dates
4| System should display different bus operators, timings, and prices
5| Users should be able to select seats from a visual seat map
6| System should support different bus layouts (sleeper, semi-sleeper, etc.)
7| Users should be able to cancel tickets with refund based on cancellation policy
8| Follow-up Questions:
9| How would you design the seat map to support different bus layouts?
10| How would you handle partial cancellations in group bookings?
11| How would you implement surge pricing during peak seasons?
12| sms notification for booking, cancellation, etc.
13| payment gateway integration

## System Architecture

### Core Components and Interactions

The RedBus system follows a layered architecture with clear separation of concerns:

1. **Client Layer**: RedBusClient serves as a facade to the underlying services
2. **API Layer**: REST endpoints for search, booking, and other operations
3. **Controller Layer**: Handles request processing and response formatting
4. **Service Layer**: Contains core business logic
5. **Model Layer**: Domain entities representing the business objects

### Service Interactions

Services communicate with each other through well-defined interfaces following the Dependency Inversion principle:



Key service interactions:
- **SearchService** interacts with **BusService** to find available buses
- **BookingService** depends on **SeatService**, **PricingService**, and **PaymentService**
- **NotificationService** is triggered by booking events (confirmation, cancellation)
- **CancellationService** handles refund calculations based on policies

### Design Patterns Implemented

1. **Facade Pattern**: RedBusClient provides a simplified interface to the complex subsystem
2. **Strategy Pattern**: Different pricing strategies (DefaultFareStrategy, WeekendFareStrategy, PeakSeasonFareStrategy)
3. **Observer Pattern**: NotificationService implements observers for different notification channels
4. **Factory Method**: Creation of different bus layouts and seat configurations
5. **Repository Pattern**: Abstract data access for buses, routes, schedules
6. **DTO Pattern**: Data Transfer Objects for API requests/responses

### SOLID Principles Application

1. **Single Responsibility Principle**:
   - Each service has a single responsibility (BookingService handles bookings, SeatService manages seats)
   - Models represent single business entities (Bus, Route, Schedule)

2. **Open/Closed Principle**:
   - FareStrategy hierarchy allows adding new pricing strategies without modifying existing code
   - NotificationObserver interface enables adding new notification channels

3. **Liskov Substitution Principle**:
   - All fare strategies can be used interchangeably through the FareStrategy interface
   - Different bus types follow the same interface

4. **Interface Segregation Principle**:
   - Service interfaces are specific to their domain (IBookingService, ISeatService)
   - Notification observers implement only what they need

5. **Dependency Inversion Principle**:
   - High-level modules depend on abstractions (interfaces) not concrete implementations
   - Services are injected with their dependencies

### Key Flows

#### Search Flow
1. User submits search criteria (from_city, to_city, date)
2. SearchController processes request and creates SearchRequestDTO
3. SearchService queries BusService for matching schedules
4. Results are filtered, sorted, and converted to SearchResponseDTO
5. Response is returned to the client

#### Booking Flow
1. User selects seats and provides passenger details
2. BookingService locks selected seats via SeatService
3. PricingService calculates fare with appropriate strategy
4. Payment is processed through PaymentService
5. On successful payment, seats are marked as booked
6. NotificationService sends booking confirmation
7. Tickets are generated for each passenger

#### Cancellation Flow
1. User requests cancellation of booking or specific passengers
2. CancellationService calculates refund based on time until departure
3. Seats are released back to available status
4. Payment refund is processed
5. NotificationService sends cancellation confirmation

### Seat Layout Implementation

The system supports different bus layouts through:
- BusLayout class with configurable rows, columns, and decks
- SeatPosition class to track row, column, and deck
- SeatType enum for different seat types (SEATER, SLEEPER, etc.)
- Visual representation through get_seat_map() method

### Surge Pricing Implementation

Surge pricing is implemented through:
1. Strategy pattern with different fare calculation strategies
2. Time-based factors (weekends, holidays)
3. Demand-based multipliers for popular routes
4. Season-based pricing (summer, winter holidays)

### Partial Cancellation Handling

The system supports partial cancellations by:
1. Tracking individual passengers within a booking
2. Allowing cancellation of specific passengers
3. Recalculating booking totals after partial cancellation
4. Maintaining booking status even with some passengers cancelled

### Notification System

Notifications are sent through multiple channels:
- Email notifications for booking confirmations and e-tickets
- SMS notifications for time-sensitive updates
- Push notifications for mobile app users
- WhatsApp messages for booking details

### Payment Integration

The system supports multiple payment methods:
- Credit/debit cards
- Net banking
- Digital wallets
- UPI payments
- Payment status tracking
- Refund processing