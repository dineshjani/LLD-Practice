import random
from typing import List, Dict
from ..models.train import Train, Coach, Seat
from ..models.base_models import CoachType, SeatType

class TrainFactory:
    def __init__(self):
        self.trains: Dict[str, Train] = {}
    
    def create_express_train(self, train_number: str, name: str) -> Train:
        """Create a new express train with standard configuration"""
        if train_number in self.trains:
            raise ValueError(f"Train with number {train_number} already exists")
            
        train = Train(train_number, name)
        
        # Add sleeper coaches (S1-S10)
        for i in range(1, 11):
            coach = Coach(f"S{i}", CoachType.SLEEPER)
            self._add_sleeper_seats(coach)
            train.add_coach(coach)
            
        # Add AC 3 Tier coaches (B1-B5)
        for i in range(1, 6):
            coach = Coach(f"B{i}", CoachType.AC_3_TIER)
            self._add_ac3_seats(coach)
            train.add_coach(coach)
            
        # Add AC 2 Tier coaches (A1-A3)
        for i in range(1, 4):
            coach = Coach(f"A{i}", CoachType.AC_2_TIER)
            self._add_ac2_seats(coach)
            train.add_coach(coach)
        
        # Register the train
        self.trains[train_number] = train
        return train
        
    def create_shatabdi_train(self, train_number: str, name: str) -> Train:
        """Create a new Shatabdi train with standard configuration"""
        if train_number in self.trains:
            raise ValueError(f"Train with number {train_number} already exists")
            
        train = Train(train_number, name)
        
        # Add Chair Car coaches (C1-C12)
        for i in range(1, 13):
            coach = Coach(f"C{i}", CoachType.CHAIR_CAR)
            self._add_chair_car_seats(coach)
            train.add_coach(coach)
            
        # Add Executive Chair Car coaches (E1-E2)
        for i in range(1, 3):
            coach = Coach(f"E{i}", CoachType.AC_1_TIER)  # Using AC_1_TIER for Executive class
            self._add_executive_seats(coach)
            train.add_coach(coach)
        
        # Register the train
        self.trains[train_number] = train
        return train
    
    def get_train(self, train_number: str) -> Train:
        """Get a train by its number"""
        if train_number not in self.trains:
            raise ValueError(f"Train with number {train_number} not found")
        return self.trains[train_number]
    
    def get_all_trains(self) -> Dict[str, Train]:
        """Get all trains"""
        return self.trains
        
    @staticmethod
    def _add_sleeper_seats(coach: Coach) -> None:
        """Add 72 seats to a sleeper coach (9 compartments with 8 seats each)"""
        seat_types = [SeatType.LOWER, SeatType.MIDDLE, SeatType.UPPER, 
                     SeatType.LOWER, SeatType.MIDDLE, SeatType.UPPER,
                     SeatType.SIDE_LOWER, SeatType.SIDE_UPPER]
        
        for i in range(1, 10):  # 9 compartments
            for j, seat_type in enumerate(seat_types):
                seat_number = f"{i}{chr(65 + j)}"  # 1A, 1B, ..., 9H
                seat_id = f"{coach.coach_id}_{seat_number}"
                seat = Seat(seat_id, seat_number, seat_type)
                coach.add_seat(seat)
                
    @staticmethod
    def _add_ac3_seats(coach: Coach) -> None:
        """Add 64 seats to an AC 3 Tier coach (8 compartments with 8 seats each)"""
        seat_types = [SeatType.LOWER, SeatType.MIDDLE, SeatType.UPPER, 
                     SeatType.LOWER, SeatType.MIDDLE, SeatType.UPPER,
                     SeatType.SIDE_LOWER, SeatType.SIDE_UPPER]
        
        for i in range(1, 9):  # 8 compartments
            for j, seat_type in enumerate(seat_types):
                seat_number = f"{i}{chr(65 + j)}"  # 1A, 1B, ..., 8H
                seat_id = f"{coach.coach_id}_{seat_number}"
                seat = Seat(seat_id, seat_number, seat_type)
                coach.add_seat(seat)
                
    @staticmethod
    def _add_ac2_seats(coach: Coach) -> None:
        """Add 48 seats to an AC 2 Tier coach (8 compartments with 6 seats each)"""
        seat_types = [SeatType.LOWER, SeatType.UPPER, 
                     SeatType.LOWER, SeatType.UPPER,
                     SeatType.SIDE_LOWER, SeatType.SIDE_UPPER]
        
        for i in range(1, 9):  # 8 compartments
            for j, seat_type in enumerate(seat_types):
                seat_number = f"{i}{chr(65 + j)}"  # 1A, 1B, ..., 8F
                seat_id = f"{coach.coach_id}_{seat_number}"
                seat = Seat(seat_id, seat_number, seat_type)
                coach.add_seat(seat)
                
    @staticmethod
    def _add_chair_car_seats(coach: Coach) -> None:
        """Add 78 seats to a Chair Car coach (13 rows with 6 seats each)"""
        seat_types = [SeatType.WINDOW, SeatType.MIDDLE_SEAT, SeatType.AISLE,
                     SeatType.AISLE, SeatType.MIDDLE_SEAT, SeatType.WINDOW]
        
        for i in range(1, 14):  # 13 rows
            for j, seat_type in enumerate(seat_types):
                seat_number = f"{i}{chr(65 + j)}"  # 1A, 1B, ..., 13F
                seat_id = f"{coach.coach_id}_{seat_number}"
                seat = Seat(seat_id, seat_number, seat_type)
                coach.add_seat(seat)
                
    @staticmethod
    def _add_executive_seats(coach: Coach) -> None:
        """Add 56 seats to an Executive Chair Car coach (14 rows with 4 seats each)"""
        seat_types = [SeatType.WINDOW, SeatType.AISLE, SeatType.AISLE, SeatType.WINDOW]
        
        for i in range(1, 15):  # 14 rows
            for j, seat_type in enumerate(seat_types):
                seat_number = f"{i}{chr(65 + j)}"  # 1A, 1B, ..., 14D
                seat_id = f"{coach.coach_id}_{seat_number}"
                seat = Seat(seat_id, seat_number, seat_type)
                coach.add_seat(seat) 