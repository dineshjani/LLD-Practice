from datetime import date, time
from problems.irctc.client.irctc_client import IRCTCClient
from problems.irctc.models.base_models import Gender, CoachType, DayOfWeek

# Create client
irctc = IRCTCClient()

# Add stations
delhi = irctc.add_station("NDLS", "New Delhi", "Delhi")
agra = irctc.add_station("AGC", "Agra Cantt", "Agra")
kanpur = irctc.add_station("CNB", "Kanpur Central", "Kanpur")
lucknow = irctc.add_station("LKO", "Lucknow Jn", "Lucknow")

# Create a train
train = irctc.create_express_train("12301", "Rajdhani Express")

# Set up schedule
schedule = irctc.setup_train_schedule(
    "12301", 
    "NDLS-LKO", 
    date(2023, 1, 1), 
    date(2023, 12, 31)
)

# Add operating days
irctc.add_operating_day("12301", DayOfWeek.MONDAY)
irctc.add_operating_day("12301", DayOfWeek.WEDNESDAY)
irctc.add_operating_day("12301", DayOfWeek.FRIDAY)

# Add stops
irctc.add_scheduled_stop("12301", "NDLS", None, time(16, 0), 0, 0)  # First stop
irctc.add_scheduled_stop("12301", "AGC", time(18, 0), time(18, 5), 0, 200)
irctc.add_scheduled_stop("12301", "CNB", time(22, 0), time(22, 10), 0, 300)
irctc.add_scheduled_stop("12301", "LKO", time(1, 0), None, 1, 150)  # Last stop

# Search for trains
journey_date = date(2023, 6, 16)  # A Friday
trains = irctc.search_trains("NDLS", "LKO", journey_date)
print(f"Found {len(trains)} trains")

# Check seat availability
available_seats = irctc.check_seat_availability(
    "12301", "NDLS", "LKO", journey_date, CoachType.AC_2_TIER
)
print(f"Available AC 2-Tier seats: {available_seats}")

# Calculate fare with different strategies
regular_fare = irctc.calculate_fare(
    "12301", "NDLS", "LKO", CoachType.AC_2_TIER, journey_date
)
print(f"Regular fare: ₹{regular_fare}")

# Set dynamic pricing as default
irctc.fare_calculation_service.set_default_strategy("dynamic")

dynamic_fare = irctc.calculate_fare(
    "12301", "NDLS", "LKO", CoachType.AC_2_TIER, journey_date
)
print(f"Dynamic fare: ₹{dynamic_fare}")

# Book tickets
passengers = [
    {"name": "John Doe", "age": 35, "gender": "MALE"},
    {"name": "Jane Doe", "age": 32, "gender": "FEMALE"}
]

booking = irctc.book_tickets(
    "12301", "NDLS", "LKO", journey_date, passengers, CoachType.AC_2_TIER
)
print(f"Booking confirmed with PNR: {booking.pnr}")

# Get booking details
booking_details = irctc.get_booking_details(booking.pnr)
print(f"Booking status: {booking_details.status.value}")

# Get train schedule
schedule = irctc.get_train_schedule("12301")
for stop in schedule:
    print(f"{stop['station']} ({stop['station_code']}) - Arrival: {stop['arrival']}, Departure: {stop['departure']}, Day: {stop['day']}")

# Cancel booking
cancelled = irctc.cancel_booking(booking.pnr)
print(f"Booking cancelled: {cancelled}") 