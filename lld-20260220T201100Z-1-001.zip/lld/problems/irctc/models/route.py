from typing import List, Dict
from .station import Station

class Route:
    def __init__(self, route_id: str):
        self.route_id = route_id
        self.stations: List[Station] = []
        self._station_indices: Dict[str, int] = {}
        self._distances: Dict[str, int] = {}  # key: "source_code:dest_code"
        
    def add_station(self, station: Station, distance_from_prev: int = 0) -> None:
        """Add a station to the route with distance from previous station"""
        station_idx = len(self.stations)
        self.stations.append(station)
        self._station_indices[station.code] = station_idx
        
        # Store distance from previous station
        if station_idx > 0:
            prev_station = self.stations[station_idx - 1]
            key = f"{prev_station.code}:{station.code}"
            self._distances[key] = distance_from_prev
        
    def get_distance(self, source: Station, destination: Station) -> int:
        """Calculate total distance between two stations on the route"""
        if source not in self.stations or destination not in self.stations:
            raise ValueError("Stations not on this route")
            
        source_idx = self._station_indices[source.code]
        dest_idx = self._station_indices[destination.code]
        
        if source_idx > dest_idx:
            raise ValueError("Source station comes after destination station")
            
        total_distance = 0
        for i in range(source_idx, dest_idx):
            curr_station = self.stations[i]
            next_station = self.stations[i+1]
            key = f"{curr_station.code}:{next_station.code}"
            total_distance += self._distances.get(key, 0)
            
        return total_distance
        
    def is_station_on_route(self, station: Station) -> bool:
        return station.code in self._station_indices
        
    def get_station_index(self, station: Station) -> int:
        if not self.is_station_on_route(station):
            raise ValueError(f"Station {station.code} not on route {self.route_id}")
        return self._station_indices[station.code] 