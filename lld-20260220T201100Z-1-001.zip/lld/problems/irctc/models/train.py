from typing import List, Dict, Optional, TYPE_CHECKING
from datetime import date
from .schedule import Schedule
from .base_models import CoachType, SeatType
from .station import Station

if TYPE_CHECKING:
    from .booking import Booking

class Seat:
    def __init__(self, seat_id: str, seat_number: str, seat_type: SeatType):
        self.seat_id = seat_id
        self.seat_number = seat_number
        self.seat_type = seat_type
        # Dictionary to track bookings by date
        self.bookings: Dict[str, List['Booking']] = {}
        
    def is_available(self, journey_date: date, source_idx: int, dest_idx: int) -> bool:
        date_str = journey_date.isoformat()
        if date_str not in self.bookings:
            return True
            
        # Check if there's any booking that overlaps with the requested journey
        for booking in self.bookings.get(date_str, []):
            # If existing booking's source is before requested destination AND
            # existing booking's destination is after requested source, there's an overlap
            if (booking.source_station_index < dest_idx and 
                booking.destination_station_index > source_idx):
                return False
                
        return True
        
    def book(self, journey_date: date, booking: 'Booking', 
            source_station_index: int, destination_station_index: int) -> None:
        date_str = journey_date.isoformat()
        if date_str not in self.bookings:
            self.bookings[date_str] = []
            
        booking.source_station_index = source_station_index
        booking.destination_station_index = destination_station_index
        self.bookings[date_str].append(booking)
        
    def cancel_booking(self, journey_date: date, booking_id: str) -> bool:
        date_str = journey_date.isoformat()
        if date_str not in self.bookings:
            return False
            
        initial_count = len(self.bookings[date_str])
        self.bookings[date_str] = [b for b in self.bookings[date_str] if b.booking_id != booking_id]
        
        return len(self.bookings[date_str]) < initial_count

class Coach:
    def __init__(self, coach_id: str, coach_type: CoachType):
        self.coach_id = coach_id
        self.coach_type = coach_type
        self.seats: List[Seat] = []
        
    def add_seat(self, seat: Seat) -> None:
        self.seats.append(seat)
        
    def get_available_seats(self, journey_date: date, source_idx: int, dest_idx: int) -> List[Seat]:
        return [seat for seat in self.seats 
                if seat.is_available(journey_date, source_idx, dest_idx)]

class Train:
    def __init__(self, train_number: str, name: str):
        self.train_number = train_number
        self.name = name
        self.coaches: List[Coach] = []
        self.schedule: Optional[Schedule] = None
        
    def add_coach(self, coach: Coach) -> None:
        self.coaches.append(coach)
        
    def set_schedule(self, schedule: Schedule) -> None:
        self.schedule = schedule
        
    def get_available_seats(self, journey_date: date, source_station: Station, 
                           destination_station: Station) -> Dict[Coach, List[Seat]]:
        if not self.schedule:
            raise ValueError("Train schedule not set")
            
        if not self.schedule.is_operating_on_date(journey_date):
            raise ValueError(f"Train {self.train_number} not operating on {journey_date}")
            
        if not self.schedule.is_station_on_schedule(source_station) or not self.schedule.is_station_on_schedule(destination_station):
            raise ValueError("Source or destination station not on train schedule")
            
        source_idx = self.schedule.get_station_index(source_station)
        dest_idx = self.schedule.get_station_index(destination_station)
        
        if source_idx >= dest_idx:
            raise ValueError("Source station must come before destination station")
            
        result: Dict[Coach, List[Seat]] = {}
        for coach in self.coaches:
            available_seats = coach.get_available_seats(journey_date, source_idx, dest_idx)
            if available_seats:
                result[coach] = available_seats
                
        return result 