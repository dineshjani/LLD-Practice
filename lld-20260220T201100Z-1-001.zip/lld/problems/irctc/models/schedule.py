from datetime import date, time, timedelta
from typing import List, Dict, Optional, Set
from enum import Enum
import calendar
from .station import Station

class DayOfWeek(Enum):
    MONDAY = 0
    TUESDAY = 1
    WEDNESDAY = 2
    THURSDAY = 3
    FRIDAY = 4
    SATURDAY = 5
    SUNDAY = 6

class ScheduledStop:
    def __init__(self, station: Station, arrival_time: Optional[time], 
                 departure_time: Optional[time], day_offset: int = 0,
                 distance_from_prev: int = 0):
        self.station = station
        self.arrival_time = arrival_time
        self.departure_time = departure_time
        self.day_offset = day_offset  # Days from start of journey
        self.distance_from_prev = distance_from_prev  # Distance from previous station in km

class Schedule:
    def __init__(self, schedule_id: str, start_date: date, end_date: date):
        self.schedule_id = schedule_id
        self.start_date = start_date
        self.end_date = end_date
        self.stops: List[ScheduledStop] = []
        self.operating_days: Set[DayOfWeek] = set()
        self._station_indices: Dict[str, int] = {}  # Station code to index mapping
        
    def add_stop(self, stop: ScheduledStop) -> None:
        self.stops.append(stop)
        self._station_indices[stop.station.code] = len(self.stops) - 1
        
    def add_operating_day(self, day: DayOfWeek) -> None:
        self.operating_days.add(day)
        
    def is_operating_on_date(self, journey_date: date) -> bool:
        if journey_date < self.start_date or journey_date > self.end_date:
            return False
            
        day_of_week = DayOfWeek(journey_date.weekday())
        return day_of_week in self.operating_days
        
    def get_stop_for_station(self, station: Station) -> Optional[ScheduledStop]:
        if station.code not in self._station_indices:
            return None
        return self.stops[self._station_indices[station.code]]
        
    def get_station_index(self, station: Station) -> int:
        if station.code not in self._station_indices:
            raise ValueError(f"Station {station.code} not on schedule {self.schedule_id}")
        return self._station_indices[station.code]
        
    def is_station_on_schedule(self, station: Station) -> bool:
        return station.code in self._station_indices
        
    def get_distance(self, source: Station, destination: Station) -> int:
        """Calculate total distance between two stations on the schedule"""
        source_idx = self.get_station_index(source)
        dest_idx = self.get_station_index(destination)
        
        if source_idx > dest_idx:
            raise ValueError("Source station comes after destination station")
            
        total_distance = 0
        for i in range(source_idx + 1, dest_idx + 1):
            total_distance += self.stops[i].distance_from_prev
            
        return total_distance
        
    def get_travel_time(self, source: Station, destination: Station) -> Optional[timedelta]:
        """Calculate travel time between two stations based on schedule"""
        source_stop = self.get_stop_for_station(source)
        dest_stop = self.get_stop_for_station(destination)
        
        if not source_stop or not dest_stop:
            return None
            
        if source_stop.departure_time is None or dest_stop.arrival_time is None:
            return None
            
        # Calculate time difference considering day offset
        day_diff = dest_stop.day_offset - source_stop.day_offset
        hours_diff = 0
        
        if day_diff > 0:
            hours_diff = day_diff * 24
            
        source_minutes = source_stop.departure_time.hour * 60 + source_stop.departure_time.minute
        dest_minutes = dest_stop.arrival_time.hour * 60 + dest_stop.arrival_time.minute
        
        total_minutes = (hours_diff * 60) + dest_minutes - source_minutes
        return timedelta(minutes=total_minutes) 