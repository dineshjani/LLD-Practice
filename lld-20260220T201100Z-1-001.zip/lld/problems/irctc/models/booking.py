from datetime import datetime, date
from typing import List, Optional
from .base_models import Gender, BookingStatus
from .train import Train, Coach, Seat
from .station import Station
import uuid

class Passenger:
    def __init__(self, name: str, age: int, gender: Gender):
        self.name = name
        self.age = age
        self.gender = gender
        self.seat: Optional[Seat] = None
        self.coach: Optional[Coach] = None
        
    def assign_seat(self, seat: Seat, coach: Coach) -> None:
        self.seat = seat
        self.coach = coach

class Booking:
    def __init__(self, pnr: str, train: Train, journey_date: date, 
                source: Station, destination: Station):
        self.booking_id = str(uuid.uuid4())
        self.pnr = pnr
        self.train = train
        self.journey_date = journey_date
        self.source = source
        self.destination = destination
        self.passengers: List[Passenger] = []
        self.status = BookingStatus.CONFIRMED
        self.booking_time = datetime.now()
        self.cancellation_time: Optional[datetime] = None
        self.fare: float = 0.0
        
        # For seat availability tracking
        self.source_station_index: int = -1
        self.destination_station_index: int = -1
        
    def add_passenger(self, passenger: Passenger) -> None:
        self.passengers.append(passenger)
        
    def cancel(self) -> None:
        self.status = BookingStatus.CANCELLED
        self.cancellation_time = datetime.now() 