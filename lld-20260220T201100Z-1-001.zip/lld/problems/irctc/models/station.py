class Station:
    def __init__(self, code: str, name: str, city: str):
        self.code = code
        self.name = name
        self.city = city
        
    def __eq__(self, other):
        if not isinstance(other, Station):
            return False
        return self.code == other.code
        
    def __hash__(self):
        return hash(self.code) 