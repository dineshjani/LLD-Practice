from abc import ABC, abstractmethod
from datetime import datetime, date, time, timedelta
from enum import Enum
from typing import List, Dict, Optional, Set
import uuid

class Gender(Enum):
    MALE = "MALE"
    FEMALE = "FEMALE"
    OTHER = "OTHER"

class CoachType(Enum):
    SLEEPER = "SL"
    AC_3_TIER = "3A"
    AC_2_TIER = "2A"
    AC_1_TIER = "1A"
    SECOND_SITTING = "2S"
    CHAIR_CAR = "CC"

class SeatType(Enum):
    LOWER = "LB"
    MIDDLE = "MB"
    UPPER = "UB"
    SIDE_LOWER = "SLB"
    SIDE_UPPER = "SUB"
    WINDOW = "WS"
    MIDDLE_SEAT = "MS"
    AISLE = "AS"

class BookingStatus(Enum):
    CONFIRMED = "CNF"
    WAITLISTED = "WL"
    RAC = "RAC"
    CANCELLED = "CAN" 