from typing import List, Dict, Optional
from datetime import date
from ..models.train import Train
from ..models.schedule import Schedule
from ..models.station import Station
from ..factories.train_factory import TrainFactory

class TrainService:
    def __init__(self, train_factory: TrainFactory):
        self.train_factory = train_factory
        
    def add_coach_to_train(self, train_number: str, coach_type: str, coach_number: str) -> None:
        """Add a custom coach to a train"""
        train = self.get_train_by_number(train_number)
        # Implementation for adding custom coaches would go here
        
    def update_schedule(self, train_number: str, schedule: Schedule) -> None:
        """Update a train's schedule"""
        train = self.get_train_by_number(train_number)
        train.set_schedule(schedule)
        
    def get_train_by_number(self, train_number: str) -> Train:
        """Get a train by its number"""
        return self.train_factory.get_train(train_number)
        
    def search_trains(self, source: Station, destination: Station, journey_date: date) -> List[Train]:
        """Search for trains between stations on a specific date"""
        result = []
        for train in self.train_factory.get_all_trains().values():
            if not train.schedule:
                continue
                
            try:
                if (train.schedule.is_operating_on_date(journey_date) and
                    train.schedule.is_station_on_schedule(source) and
                    train.schedule.is_station_on_schedule(destination) and
                    train.schedule.get_station_index(source) < train.schedule.get_station_index(destination)):
                    result.append(train)
            except ValueError:
                # Skip trains where stations aren't on schedule or in wrong order
                continue
                
        return result 