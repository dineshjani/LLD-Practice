from typing import List, Dict, Optional, Set, Tuple
from datetime import date, datetime, timedelta
import threading
from ..models.train import Train, Coach, Seat
from ..models.station import Station

class SeatLock:
    def __init__(self, lock_id: str, expiry: datetime):
        self.lock_id = lock_id
        self.expiry = expiry

class SeatAvailabilityService:
    def __init__(self):
        self.locks: Dict[str, SeatLock] = {}
        self.lock = threading.Lock()
        
    def get_available_seats(self, train: Train, source: Station, 
                           destination: Station, journey_date: date) -> Dict[Coach, List[Seat]]:
        return train.get_available_seats(journey_date, source, destination)
        
    def are_seats_available(self, train: Train, source: Station, 
                           destination: Station, journey_date: date, num_seats: int) -> bool:
        available_seats = self.get_available_seats(train, source, destination, journey_date)
        total_available = sum(len(seats) for seats in available_seats.values())
        return total_available >= num_seats
        
    def lock_seats(self, train: Train, seats: List[Seat], source: Station, 
                  destination: Station, journey_date: date, lock_id: str, 
                  lock_duration: timedelta = timedelta(minutes=10)) -> bool:
        """Lock seats for a short duration during booking process"""
        with self.lock:
            # Check if all seats are available
            source_idx = train.route.get_station_index(source)
            dest_idx = train.route.get_station_index(destination)
            
            for seat in seats:
                lock_key = f"{train.train_number}:{seat.seat_id}:{journey_date.isoformat()}"
                
                # Check if seat is already locked
                if lock_key in self.locks and self.locks[lock_key].expiry > datetime.now():
                    return False
                    
                # Check if seat is available
                if not seat.is_available(journey_date, source_idx, dest_idx):
                    return False
                    
            # Lock all seats
            expiry = datetime.now() + lock_duration
            for seat in seats:
                lock_key = f"{train.train_number}:{seat.seat_id}:{journey_date.isoformat()}"
                self.locks[lock_key] = SeatLock(lock_id, expiry)
                
            return True
            
    def unlock_seats(self, lock_id: str) -> None:
        """Unlock seats with the given lock ID"""
        with self.lock:
            keys_to_remove = [key for key, lock in self.locks.items() if lock.lock_id == lock_id]
            for key in keys_to_remove:
                del self.locks[key]
                
    def cleanup_expired_locks(self) -> None:
        """Remove expired locks"""
        with self.lock:
            now = datetime.now()
            keys_to_remove = [key for key, lock in self.locks.items() if lock.expiry <= now]
            for key in keys_to_remove:
                del self.locks[key] 