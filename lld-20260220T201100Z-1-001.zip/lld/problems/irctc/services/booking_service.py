from typing import List, Dict, Optional, Tuple
from datetime import date, datetime, timedelta
import threading
import uuid
import random
from ..models.booking import Booking, Passenger
from ..models.train import Train, Coach, Seat
from ..models.station import Station
from ..models.base_models import BookingStatus, Gender, CoachType
from .seat_availability_service import SeatAvailabilityService
from .fare_service import FareCalculationService

class BookingService:
    def __init__(self, seat_availability_service: SeatAvailabilityService, 
                fare_calculation_service: FareCalculationService):
        self.seat_availability_service = seat_availability_service
        self.fare_calculation_service = fare_calculation_service
        self.bookings: Dict[str, Booking] = {}  # PNR -> Booking
        self.lock = threading.Lock()
        
    def create_booking(self, train: Train, journey_date: date, source: Station, 
                      destination: Station, passengers: List[Passenger], 
                      coach_type: CoachType) -> Booking:
        # Validate journey date (must be within next 90 days)
        today = date.today()
        max_booking_date = today + timedelta(days=90)
        
        if journey_date < today or journey_date > max_booking_date:
            raise ValueError("Journey date must be within next 90 days")
            
        # Check if train operates on the journey date
        if not train.schedule.is_operating_on_date(journey_date):
            raise ValueError(f"Train {train.train_number} does not operate on {journey_date}")
            
        # Check if source and destination are valid
        if not train.route.is_station_on_route(source) or not train.route.is_station_on_route(destination):
            raise ValueError("Source or destination station not on train route")
            
        source_idx = train.route.get_station_index(source)
        dest_idx = train.route.get_station_index(destination)
        
        if source_idx >= dest_idx:
            raise ValueError("Source station must come before destination station")
            
        # Check seat availability
        num_passengers = len(passengers)
        if not self.seat_availability_service.are_seats_available(
            train, source, destination, journey_date, num_passengers):
            raise ValueError("Not enough seats available")
            
        # Get available seats
        available_seats_by_coach = self.seat_availability_service.get_available_seats(
            train, source, destination, journey_date)
        
        # Filter coaches by type
        filtered_coaches = {coach: seats for coach, seats in available_seats_by_coach.items() 
                          if coach.coach_type == coach_type}
        
        if not filtered_coaches:
            raise ValueError(f"No {coach_type.value} coaches available")
            
        # Flatten the seats list
        available_seats = []
        for coach, seats in filtered_coaches.items():
            for seat in seats:
                available_seats.append((coach, seat))
                
        if len(available_seats) < num_passengers:
            raise ValueError(f"Not enough {coach_type.value} seats available")
            
        # Lock seats for booking
        seats_to_book = available_seats[:num_passengers]
        lock_id = str(uuid.uuid4())
        
        seats_only = [seat for _, seat in seats_to_book]
        if not self.seat_availability_service.lock_seats(
            train, seats_only, source, destination, journey_date, lock_id):
            raise ValueError("Failed to lock seats for booking")
            
        try:
            # Generate PNR
            pnr = self._generate_pnr()
            
            # Create booking
            booking = Booking(pnr, train, journey_date, source, destination)
            
            # Calculate fare
            fare_per_passenger = self.fare_calculation_service.calculate_fare(
                train, source, destination, coach_type, journey_date)
            booking.fare = fare_per_passenger * num_passengers
            
            # Assign seats to passengers
            for i, passenger in enumerate(passengers):
                if i < len(seats_to_book):
                    coach, seat = seats_to_book[i]
                    passenger.assign_seat(seat, coach)
                    booking.add_passenger(passenger)
                    
                    # Mark seat as booked
                    seat.book(journey_date, booking, source_idx, dest_idx)
            
            # Store booking
            with self.lock:
                self.bookings[pnr] = booking
                
            return booking
            
        finally:
            # Unlock seats
            self.seat_availability_service.unlock_seats(lock_id)
            
    def get_booking_by_pnr(self, pnr: str) -> Optional[Booking]:
        return self.bookings.get(pnr)
        
    def cancel_booking(self, pnr: str) -> bool:
        booking = self.get_booking_by_pnr(pnr)
        if not booking or booking.status == BookingStatus.CANCELLED:
            return False
            
        # Mark booking as cancelled
        booking.cancel()
        
        # Release seats
        train = booking.train
        journey_date = booking.journey_date
        
        for passenger in booking.passengers:
            if passenger.seat and passenger.coach:
                passenger.seat.cancel_booking(journey_date, booking.booking_id)
                
        return True
        
    def _generate_pnr(self) -> str:
        """Generate a unique 10-digit PNR"""
        while True:
            pnr = ''.join(str(random.randint(0, 9)) for _ in range(10))
            if pnr not in self.bookings:
                return pnr 