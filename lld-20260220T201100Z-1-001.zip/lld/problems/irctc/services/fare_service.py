# Update the fare calculation to use the schedule for travel time if needed
from abc import ABC, abstractmethod
from datetime import date
from ..models.base_models import CoachType
from ..models.train import Train
from ..models.station import Station

class FareStrategy(ABC):
    @abstractmethod
    def calculate_fare(self, train: Train, source: Station, destination: Station, 
                      coach_type: CoachType, journey_date: date) -> float:
        pass

class RegularFareStrategy(FareStrategy):
    def calculate_fare(self, train: Train, source: Station, destination: Station, 
                      coach_type: CoachType, journey_date: date) -> float:
        # Base fare calculation
        distance = train.schedule.get_distance(source, destination)
        
        # Base rate per km based on coach type
        rates = {
            CoachType.SLEEPER: 0.5,
            CoachType.AC_3_TIER: 1.0,
            CoachType.AC_2_TIER: 1.5,
            CoachType.AC_1_TIER: 2.5,
            CoachType.SECOND_SITTING: 0.3,
            CoachType.CHAIR_CAR: 0.8
        }
        
        base_fare = distance * rates[coach_type]
        
        # Add reservation charges
        reservation_charges = {
            CoachType.SLEEPER: 20,
            CoachType.AC_3_TIER: 40,
            CoachType.AC_2_TIER: 50,
            CoachType.AC_1_TIER: 60,
            CoachType.SECOND_SITTING: 15,
            CoachType.CHAIR_CAR: 30
        }
        
        return base_fare + reservation_charges[coach_type]

class DynamicFareStrategy(FareStrategy):
    def calculate_fare(self, train: Train, source: Station, destination: Station, 
                      coach_type: CoachType, journey_date: date) -> float:
        # Get base fare
        base_fare = RegularFareStrategy().calculate_fare(
            train, source, destination, coach_type, journey_date)
        
        # Apply dynamic pricing based on demand and date proximity
        today = date.today()
        days_until_journey = (journey_date - today).days
        
        # Closer to journey date = higher fare
        if days_until_journey < 7:
            multiplier = 1.3  # 30% increase for last week bookings
        elif days_until_journey < 15:
            multiplier = 1.2  # 20% increase for bookings 1-2 weeks before
        elif days_until_journey < 30:
            multiplier = 1.1  # 10% increase for bookings 2-4 weeks before
        else:
            multiplier = 1.0  # No increase for early bookings
            
        return base_fare * multiplier

class FareCalculationService:
    def __init__(self):
        self.strategies = {
            "regular": RegularFareStrategy(),
            "dynamic": DynamicFareStrategy()
        }
        self.default_strategy = "regular"
        
    def calculate_fare(self, train: Train, source: Station, destination: Station, 
                      coach_type: CoachType, journey_date: date, 
                      strategy_name: str = None) -> float:
        """Calculate fare using the specified strategy or default"""
        if not strategy_name:
            strategy_name = self.default_strategy
            
        if strategy_name not in self.strategies:
            raise ValueError(f"Unknown fare strategy: {strategy_name}")
            
        strategy = self.strategies[strategy_name]
        return strategy.calculate_fare(train, source, destination, coach_type, journey_date)
        
    def set_default_strategy(self, strategy_name: str) -> None:
        """Set the default fare calculation strategy"""
        if strategy_name not in self.strategies:
            raise ValueError(f"Unknown fare strategy: {strategy_name}")
        self.default_strategy = strategy_name 