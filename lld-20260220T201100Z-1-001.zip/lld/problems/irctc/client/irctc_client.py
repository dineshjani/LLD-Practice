from datetime import date, time, timedelta
from typing import List, Dict, Optional
import random

from ..models.base_models import Gender, CoachType, BookingStatus
from ..models.station import Station
from ..models.train import Train
from ..models.booking import Booking, Passenger
from ..models.schedule import Schedule, ScheduledStop, DayOfWeek

from ..services.train_service import TrainService
from ..services.booking_service import BookingService
from ..services.seat_availability_service import SeatAvailabilityService
from ..services.fare_service import FareCalculationService

from ..factories.train_factory import TrainFactory

class IRCTCClient:
    """
    Main client class for interacting with the IRCTC train booking system.
    This serves as a facade to the underlying services.
    """
    
    def __init__(self):
        # Initialize services
        self.train_factory = TrainFactory()
        self.seat_availability_service = SeatAvailabilityService()
        self.fare_calculation_service = FareCalculationService()
        self.train_service = TrainService(self.train_factory)
        self.booking_service = BookingService(
            self.seat_availability_service, 
            self.fare_calculation_service
        )
        
        # Initialize data store for stations
        self.stations: Dict[str, Station] = {}
        
    # Station Management
    def add_station(self, code: str, name: str, city: str) -> Station:
        """Add a new station to the system"""
        if code in self.stations:
            raise ValueError(f"Station with code {code} already exists")
            
        station = Station(code, name, city)
        self.stations[code] = station
        return station
        
    def get_station(self, code: str) -> Station:
        """Get a station by its code"""
        if code not in self.stations:
            raise ValueError(f"Station with code {code} not found")
        return self.stations[code]
    
    # Train Management
    def create_express_train(self, train_number: str, name: str) -> Train:
        """Create a new express train"""
        return self.train_factory.create_express_train(train_number, name)
        
    def create_shatabdi_train(self, train_number: str, name: str) -> Train:
        """Create a new Shatabdi train"""
        return self.train_factory.create_shatabdi_train(train_number, name)
    
    def setup_train_schedule(self, train_number: str, schedule_id: str, 
                           start_date: date, end_date: date) -> Schedule:
        """Set up a schedule for a train"""
        train = self.train_service.get_train_by_number(train_number)
        schedule = Schedule(schedule_id, start_date, end_date)
        train.set_schedule(schedule)
        return schedule
        
    def add_scheduled_stop(self, train_number: str, station_code: str, 
                         arrival_time: Optional[time], departure_time: Optional[time],
                         day_offset: int = 0, distance_from_prev: int = 0) -> None:
        """Add a scheduled stop to a train's schedule"""
        train = self.train_service.get_train_by_number(train_number)
        station = self.get_station(station_code)
        
        if not train.schedule:
            raise ValueError(f"Train {train_number} does not have a schedule")
            
        stop = ScheduledStop(station, arrival_time, departure_time, day_offset, distance_from_prev)
        train.schedule.add_stop(stop)
        
    def add_operating_day(self, train_number: str, day: DayOfWeek) -> None:
        """Add an operating day to a train's schedule"""
        train = self.train_service.get_train_by_number(train_number)
        
        if not train.schedule:
            raise ValueError(f"Train {train_number} does not have a schedule")
            
        train.schedule.add_operating_day(day)
    
    # Search and Availability
    def search_trains(self, source_code: str, destination_code: str, 
                    journey_date: date) -> List[Train]:
        """Search for trains between stations on a specific date"""
        source = self.get_station(source_code)
        destination = self.get_station(destination_code)
        
        return self.train_service.search_trains(source, destination, journey_date)
        
    def check_seat_availability(self, train_number: str, source_code: str, 
                              destination_code: str, journey_date: date, 
                              coach_type: CoachType) -> int:
        """Check how many seats are available for a specific journey"""
        train = self.train_service.get_train_by_number(train_number)
        source = self.get_station(source_code)
        destination = self.get_station(destination_code)
        
        available_seats = self.seat_availability_service.get_available_seats(
            train, source, destination, journey_date)
        
        # Filter by coach type
        count = 0
        for coach, seats in available_seats.items():
            if coach.coach_type == coach_type:
                count += len(seats)
                
        return count
        
    def calculate_fare(self, train_number: str, source_code: str, 
                      destination_code: str, coach_type: CoachType, 
                      journey_date: date) -> float:
        """Calculate fare for a journey"""
        train = self.train_service.get_train_by_number(train_number)
        source = self.get_station(source_code)
        destination = self.get_station(destination_code)
        
        return self.fare_calculation_service.calculate_fare(
            train, source, destination, coach_type, journey_date)
    
    # Booking Management
    def book_tickets(self, train_number: str, source_code: str, destination_code: str,
                   journey_date: date, passengers: List[Dict], coach_type: CoachType) -> Booking:
        """Book tickets for multiple passengers"""
        train = self.train_service.get_train_by_number(train_number)
        source = self.get_station(source_code)
        destination = self.get_station(destination_code)
        
        # Convert passenger dictionaries to Passenger objects
        passenger_objects = []
        for p in passengers:
            gender = Gender[p['gender']]
            passenger = Passenger(p['name'], p['age'], gender)
            passenger_objects.append(passenger)
            
        # Create booking
        booking = self.booking_service.create_booking(
            train, journey_date, source, destination, passenger_objects, coach_type)
            
        return booking
        
    def get_booking_details(self, pnr: str) -> Optional[Booking]:
        """Get booking details by PNR"""
        return self.booking_service.get_booking_by_pnr(pnr)
        
    def cancel_booking(self, pnr: str) -> bool:
        """Cancel a booking by PNR"""
        return self.booking_service.cancel_booking(pnr)
        
    # Helper methods
    def get_train_schedule(self, train_number: str) -> List[Dict]:
        """Get the full schedule of a train in a user-friendly format"""
        train = self.train_service.get_train_by_number(train_number)
        
        if not train.schedule:
            return []
            
        result = []
        for stop in train.schedule.stops:
            result.append({
                'station': stop.station.name,
                'station_code': stop.station.code,
                'city': stop.station.city,
                'arrival': stop.arrival_time.strftime('%H:%M') if stop.arrival_time else None,
                'departure': stop.departure_time.strftime('%H:%M') if stop.departure_time else None,
                'day': stop.day_offset + 1  # 1-indexed for user display
            })
            
        return result
        
    def get_operating_days(self, train_number: str) -> List[str]:
        """Get the operating days of a train in a user-friendly format"""
        train = self.train_service.get_train_by_number(train_number)
        
        if not train.schedule:
            return []
            
        day_names = {
            DayOfWeek.MONDAY: "Monday",
            DayOfWeek.TUESDAY: "Tuesday",
            DayOfWeek.WEDNESDAY: "Wednesday",
            DayOfWeek.THURSDAY: "Thursday",
            DayOfWeek.FRIDAY: "Friday",
            DayOfWeek.SATURDAY: "Saturday",
            DayOfWeek.SUNDAY: "Sunday"
        }
        
        return [day_names[day] for day in train.schedule.operating_days] 