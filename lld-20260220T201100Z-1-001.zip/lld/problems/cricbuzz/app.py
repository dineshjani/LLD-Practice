import threading
import time
from typing import Dict, Any, List

from cricbuzz.models import Match, MatchFormat, MatchStatus, UpdateType
from cricbuzz.producers import ICCScoreProducer, ESPNScoreProducer, BCCIScoreProducer
from cricbuzz.consumers import ScoreboardConsumer, CommentaryConsumer, UserNotificationConsumer


class CricbuzzApp:
    """Main application class that coordinates the system"""
    
    def __init__(self):
        # Create producers
        self.icc_producer = ICCScoreProducer()
        self.espn_producer = ESPNScoreProducer()
        self.bcci_producer = BCCIScoreProducer()
        
        # Create consumers
        self.scoreboard_consumer = ScoreboardConsumer()
        self.commentary_consumer = CommentaryConsumer()
        self.notification_consumer = UserNotificationConsumer()
        
        # Register consumers with producers
        self._register_consumers()
        
        # Match storage
        self.matches: Dict[str, Match] = {}
        
        # Start polling thread
        self.polling_thread = threading.Thread(target=self._polling_loop, daemon=True)
        self.polling_active = False
    
    def _register_consumers(self) -> None:
        # Register with all producers
        for producer in [self.icc_producer, self.espn_producer, self.bcci_producer]:
            producer.register_consumer(self.scoreboard_consumer)
            producer.register_consumer(self.commentary_consumer)
            producer.register_consumer(self.notification_consumer)
    
    def _polling_loop(self) -> None:
        """Background thread that polls for updates"""
        while self.polling_active:
            self.poll_for_updates()
            time.sleep(5)  # Poll every 5 seconds
    
    def start_polling(self) -> None:
        """Start the polling thread"""
        if not self.polling_active:
            self.polling_active = True
            self.polling_thread.start()
    
    def stop_polling(self) -> None:
        """Stop the polling thread"""
        self.polling_active = False
        if self.polling_thread.is_alive():
            self.polling_thread.join(timeout=1.0)
    
    def poll_for_updates(self) -> None:
        """Poll all producers for updates"""
        self.icc_producer.fetch_updates()
        self.espn_producer.fetch_updates()
        self.bcci_producer.fetch_updates()
    
    def create_match(self, home_team: str, away_team: str, venue: str, match_format: str) -> str:
        """Create a new match"""
        # Convert string format to enum
        format_enum = MatchFormat(match_format)
        
        # Create match
        match = Match(home_team, away_team, venue, format_enum)
        self.matches[match.id] = match
        
        # Register match with producers
        match_data = match.to_dict()
        for producer in [self.icc_producer, self.espn_producer, self.bcci_producer]:
            producer.add_match(match.id, match_data)
        
        # Register interest in this match with consumers
        self.scoreboard_consumer.add_match_interest(match.id)
        self.commentary_consumer.add_match_interest(match.id)
        
        return match.id
    
    def start_match(self, match_id: str) -> None:
        """Start a match"""
        if match_id not in self.matches:
            raise ValueError(f"Match {match_id} not found")
        
        match = self.matches[match_id]
        match.status = MatchStatus.LIVE
        
        # Update match data in producers
        match_data = match.to_dict()
        for producer in [self.icc_producer, self.espn_producer, self.bcci_producer]:
            if match_id in producer.active_matches:
                producer.active_matches[match_id] = match_data
                
                # Add a status update to latest_updates
                producer.latest_updates[match_id] = {
                    "type": UpdateType.MATCH_STATUS_UPDATE.value,
                    "data": {"status": "LIVE", "message": "Match has started"},
                    "timestamp": match.start_time
                }
                
                # Notify consumers
                producer.notify_consumers(match_id)
    
    def end_match(self, match_id: str) -> None:
        """End a match"""
        if match_id not in self.matches:
            raise ValueError(f"Match {match_id} not found")
        
        match = self.matches[match_id]
        match.status = MatchStatus.COMPLETED
        
        # Update match data in producers
        match_data = match.to_dict()
        for producer in [self.icc_producer, self.espn_producer, self.bcci_producer]:
            if match_id in producer.active_matches:
                producer.active_matches[match_id] = match_data
                
                # Add a status update to latest_updates
                producer.latest_updates[match_id] = {
                    "type": UpdateType.MATCH_STATUS_UPDATE.value,
                    "data": {"status": "COMPLETED", "message": "Match has ended"},
                    "timestamp": match.start_time
                }
                
                # Notify consumers
                producer.notify_consumers(match_id)
    
    def get_match(self, match_id: str) -> Dict[str, Any]:
        """Get match details"""
        if match_id not in self.matches:
            raise ValueError(f"Match {match_id} not found")
        
        return self.matches[match_id].to_dict()
    
    def get_all_matches(self) -> List[Dict[str, Any]]:
        """Get all matches"""
        return [match.to_dict() for match in self.matches.values()]
    
    def get_live_matches(self) -> List[Dict[str, Any]]:
        """Get all live matches"""
        return [
            match.to_dict() for match in self.matches.values()
            if match.status == MatchStatus.LIVE
        ]
    
    def subscribe_user_to_match(self, user_id: str, match_id: str) -> None:
        """Subscribe a user to notifications for a match"""
        self.notification_consumer.subscribe_user_to_match(user_id, match_id)
    
    def unsubscribe_user_from_match(self, user_id: str, match_id: str) -> None:
        """Unsubscribe a user from notifications for a match"""
        self.notification_consumer.unsubscribe_user_from_match(user_id, match_id)
    
    def get_match_score(self, match_id: str) -> Dict[str, Any]:
        """Get the current score for a match"""
        return self.scoreboard_consumer.get_match_score(match_id)
    
    def get_match_commentary(self, match_id: str, limit: int = None) -> Dict[str, List[Dict[str, Any]]]:
        """Get the commentary for a match"""
        return self.commentary_consumer.get_match_commentary(match_id, limit) 