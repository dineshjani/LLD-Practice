from enum import Enum
from typing import Dict, List, Any
import datetime
import uuid


class MatchFormat(Enum):
    T20 = "T20"
    ODI = "ODI"
    TEST = "TEST"


class MatchStatus(Enum):
    SCHEDULED = "scheduled"
    LIVE = "live"
    COMPLETED = "completed"
    ABANDONED = "abandoned"
    DELAYED = "delayed"


class Match:
    """Represents a cricket match"""
    
    def __init__(self, home_team: str, away_team: str, venue: str, match_format: MatchFormat):
        self.id = str(uuid.uuid4())
        self.home_team = home_team
        self.away_team = away_team
        self.venue = venue
        self.format = match_format
        self.status = MatchStatus.SCHEDULED
        self.start_time = datetime.datetime.now()
        self.innings = []
        self.current_inning = 0
        self.current_over = 0
        self.current_ball = 0
        self.score = {"runs": 0, "wickets": 0}
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert match to dictionary for serialization"""
        return {
            "id": self.id,
            "home_team": self.home_team,
            "away_team": self.away_team,
            "venue": self.venue,
            "format": self.format.value,
            "status": self.status.value,
            "start_time": self.start_time.isoformat(),
            "score": self.score,
            "current_inning": self.current_inning,
            "current_over": self.current_over,
            "current_ball": self.current_ball
        } 