from enum import Enum
from typing import Dict, Any
import datetime


class UpdateType(Enum):
    BALL_UPDATE = "ball_update"
    SCORE_UPDATE = "score_update"
    COMMENTARY_UPDATE = "commentary_update"
    MATCH_STATUS_UPDATE = "match_status_update"


class MatchUpdate:
    """Data transfer object for updates"""
    
    def __init__(self, match_id: str, update_type: UpdateType, data: Dict[str, Any], source: str):
        self.match_id = match_id
        self.update_type = update_type
        self.data = data
        self.source = source  # ICC, ESPN, BCCI, etc.
        self.timestamp = datetime.datetime.now()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert update to dictionary for serialization"""
        return {
            "match_id": self.match_id,
            "update_type": self.update_type.value,
            "data": self.data,
            "source": self.source,
            "timestamp": self.timestamp.isoformat()
        } 