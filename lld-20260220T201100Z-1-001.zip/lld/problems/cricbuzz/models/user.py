from typing import Set
import uuid


class User:
    """Represents a user of the Cricbuzz system"""
    
    def __init__(self, username: str, email: str):
        self.id = str(uuid.uuid4())
        self.username = username
        self.email = email
        self.subscribed_matches: Set[str] = set()
    
    def subscribe_to_match(self, match_id: str) -> None:
        """Subscribe user to a match"""
        self.subscribed_matches.add(match_id)
    
    def unsubscribe_from_match(self, match_id: str) -> None:
        """Unsubscribe user from a match"""
        if match_id in self.subscribed_matches:
            self.subscribed_matches.remove(match_id)
    
    def is_subscribed_to_match(self, match_id: str) -> bool:
        """Check if user is subscribed to a match"""
        return match_id in self.subscribed_matches
    
    def to_dict(self) -> dict:
        """Convert user to dictionary for serialization"""
        return {
            "id": self.id,
            "username": self.username,
            "email": self.email,
            "subscribed_matches": list(self.subscribed_matches)
        } 