from cricbuzz.app import CricbuzzApp
import time


def main():
    """Main entry point for the Cricbuzz application"""
    print("Starting Cricbuzz application...")
    
    # Create the Cricbuzz app
    app = CricbuzzApp()
    
    # Create a match
    match_id = app.create_match(
        home_team="India",
        away_team="Australia",
        venue="Melbourne Cricket Ground",
        match_format="ODI"
    )
    print(f"Created match: {match_id}")
    
    # Create some users
    user1_id = "user1"
    user2_id = "user2"
    
    # Subscribe users to the match
    app.subscribe_user_to_match(user1_id, match_id)
    app.subscribe_user_to_match(user2_id, match_id)
    
    # Start the match
    app.start_match(match_id)
    print("Match started")
    
    # Start polling for updates
    app.start_polling()
    
    # Let the match run for a while
    print("Simulating match for 30 seconds...")
    for i in range(6):
        time.sleep(5)
        print(f"Match in progress... ({(i+1)*5} seconds)")
        
        # Manually poll for updates (in addition to background polling)
        app.poll_for_updates()
    
    # End the match
    app.end_match(match_id)
    print("Match ended")
    
    # Stop polling
    app.stop_polling()
    
    # Print final score
    final_score = app.get_match_score(match_id)
    print(f"Final score: {final_score['runs']}/{final_score['wickets']} ({final_score['overs']} overs)")
    
    # Print last few commentaries
    commentaries = app.get_match_commentary(match_id, limit=5)
    print("\nLast 5 commentaries:")
    for commentary in commentaries["commentaries"]:
        print(f"- {commentary.get('text', '')}")


if __name__ == "__main__":
    main()
