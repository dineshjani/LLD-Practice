import random
from typing import Dict, Any
import datetime

from cricbuzz.producers.base_producer import BaseScoreProducer
from cricbuzz.models.update import UpdateType


class ESPNScoreProducer(BaseScoreProducer):
    """ESPN specific score producer"""
    
    def __init__(self):
        super().__init__("ESPN")
    
    def fetch_updates(self) -> None:
        """Fetch updates from ESPN API and notify consumers"""
        # Similar implementation as ICCScoreProducer
        # Would have ESPN-specific API calls
        for match_id, match_data in self.active_matches.items():
            # Only update live matches
            if match_data.get("status") == "live":
                # Simulate a commentary update (ESPN might provide more detailed commentary)
                commentary_data = self._simulate_commentary_update(match_id)
                
                # Store the update in latest_updates
                self.latest_updates[match_id] = {
                    "type": UpdateType.COMMENTARY_UPDATE.value,
                    "data": commentary_data,
                    "timestamp": datetime.datetime.now()
                }
                
                # Notify consumers
                self.notify_consumers(match_id)
    
    def _simulate_commentary_update(self, match_id: str) -> Dict[str, Any]:
        """Simulate a commentary update for demonstration purposes"""
        match_data = self.active_matches[match_id]
        
        # Get current over and ball
        current_over = match_data.get("current_over", 0)
        current_ball = match_data.get("current_ball", 0)
        
        # Generate a random commentary
        commentaries = [
            "The batsman defends solidly.",
            "A beautiful cover drive but straight to the fielder.",
            "The crowd is loving this contest!",
            "That was a close call for LBW, but the umpire shakes his head.",
            "The bowler is getting some good swing here.",
            "The batsman is looking in good touch today."
        ]
        
        return {
            "text": f"{current_over}.{current_ball}: {random.choice(commentaries)}"
        } 