import random
from typing import Dict, Any
import datetime

from cricbuzz.producers.base_producer import BaseScoreProducer
from cricbuzz.models.update import UpdateType


class ICCScoreProducer(BaseScoreProducer):
    """ICC specific score producer"""
    
    def __init__(self):
        super().__init__("ICC")
    
    def fetch_updates(self) -> None:
        """Fetch updates from ICC API and notify consumers"""
        # In a real implementation, this would call the ICC API
        # For demonstration, we'll simulate an update
        for match_id, match_data in self.active_matches.items():
            # Only update live matches
            if match_data.get("status") == "live":
                # Simulate a ball update
                ball_data = self._simulate_ball_update(match_id)
                
                # Store the update in latest_updates
                self.latest_updates[match_id] = {
                    "type": UpdateType.BALL_UPDATE.value,
                    "data": ball_data,
                    "timestamp": datetime.datetime.now()
                }
                
                # Notify consumers
                self.notify_consumers(match_id)
    
    def _simulate_ball_update(self, match_id: str) -> Dict[str, Any]:
        """Simulate a ball update for demonstration purposes"""
        match_data = self.active_matches[match_id]
        
        # Get current over and ball
        current_over = match_data.get("current_over", 0)
        current_ball = match_data.get("current_ball", 0) + 1
        
        # If we've completed an over, increment over and reset ball
        if current_ball > 6:
            current_over += 1
            current_ball = 1
        
        # Update match data
        match_data["current_over"] = current_over
        match_data["current_ball"] = current_ball
        
        # Simulate ball outcome
        runs = random.choice([0, 1, 2, 3, 4, 6])
        is_wicket = random.random() < 0.1  # 10% chance of wicket
        
        # Update match score
        match_data["score"]["runs"] += runs
        if is_wicket:
            match_data["score"]["wickets"] += 1
        
        return {
            "over_number": current_over,
            "ball_number": current_ball,
            "runs": runs,
            "is_wicket": is_wicket,
            "batsman": "Virat Kohli" if random.random() < 0.5 else "Rohit Sharma",
            "bowler": "Pat Cummins" if random.random() < 0.5 else "Jofra Archer",
            "commentary": f"{'WICKET!' if is_wicket else ''} {'FOUR!' if runs == 4 else 'SIX!' if runs == 6 else ''}"
        } 