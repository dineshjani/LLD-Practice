from abc import ABC, abstractmethod
from typing import List, Dict, Any

from cricbuzz.models.update import MatchUpdate
from cricbuzz.consumers.base_consumer import ScoreConsumer


class ScoreProducer(ABC):
    """Subject interface for the Observer pattern"""
    
    @abstractmethod
    def register_consumer(self, consumer: ScoreConsumer) -> None:
        pass
    
    @abstractmethod
    def remove_consumer(self, consumer: ScoreConsumer) -> None:
        pass
    
    @abstractmethod
    def notify_consumers(self, match_id: str) -> None:
        """Notify consumers about updates for a specific match"""
        pass
    
    @property
    @abstractmethod
    def producer_type(self) -> str:
        """Return the type of producer (e.g., 'cricket', 'hockey')"""
        pass
    
    @abstractmethod
    def get_match_data(self, match_id: str) -> Dict[str, Any]:
        """Get the current data for a specific match"""
        pass


class BaseScoreProducer(ScoreProducer):
    """Abstract base class for all score producers"""
    
    def __init__(self, producer_name: str, producer_type: str = "cricket"):
        self.consumers: List[ScoreConsumer] = []
        self.producer_name = producer_name
        self._producer_type = producer_type
        self.active_matches: Dict[str, Dict[str, Any]] = {}
        self.latest_updates: Dict[str, Dict[str, Any]] = {}  # Store latest updates by match_id
    
    @property
    def producer_type(self) -> str:
        return self._producer_type
    
    def register_consumer(self, consumer: ScoreConsumer) -> None:
        if consumer not in self.consumers:
            self.consumers.append(consumer)
    
    def remove_consumer(self, consumer: ScoreConsumer) -> None:
        if consumer in self.consumers:
            self.consumers.remove(consumer)
    
    def notify_consumers(self, match_id: str) -> None:
        for consumer in self.consumers:
            # Only notify consumers interested in this match and this type of producer
            if match_id in consumer.get_interested_matches() and consumer.can_handle_producer_type(self.producer_type):
                consumer.consume(match_id, self)
    
    def add_match(self, match_id: str, match_data: Dict[str, Any]) -> None:
        """Add a match to be tracked by this producer"""
        self.active_matches[match_id] = match_data
        self.latest_updates[match_id] = {}  # Initialize empty updates
    
    def remove_match(self, match_id: str) -> None:
        """Remove a match from being tracked by this producer"""
        if match_id in self.active_matches:
            del self.active_matches[match_id]
        if match_id in self.latest_updates:
            del self.latest_updates[match_id]
    
    def get_match_data(self, match_id: str) -> Dict[str, Any]:
        """Get the current data for a specific match"""
        if match_id not in self.active_matches:
            return {}
        return {
            "match_data": self.active_matches[match_id],
            "latest_update": self.latest_updates.get(match_id, {})
        }
    
    @abstractmethod
    def fetch_updates(self) -> None:
        """Fetch updates from the data source and notify consumers"""
        pass 