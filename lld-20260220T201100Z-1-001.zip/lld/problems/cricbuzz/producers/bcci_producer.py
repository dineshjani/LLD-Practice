import random
from typing import Dict, Any
import datetime

from cricbuzz.producers.base_producer import BaseScoreProducer
from cricbuzz.models.update import UpdateType


class BCCIScoreProducer(BaseScoreProducer):
    """BCCI specific score producer"""
    
    def __init__(self):
        super().__init__("BCCI")
    
    def fetch_updates(self) -> None:
        """Fetch updates from BCCI API and notify consumers"""
        # Similar implementation as other producers
        # Would have BCCI-specific API calls
        for match_id, match_data in self.active_matches.items():
            # Only update live matches
            if match_data.get("status") == "live":
                # BCCI might provide more detailed statistics
                stats_data = self._simulate_stats_update(match_id)
                
                # Store the update in latest_updates
                self.latest_updates[match_id] = {
                    "type": UpdateType.SCORE_UPDATE.value,
                    "data": stats_data,
                    "timestamp": datetime.datetime.now()
                }
                
                # Notify consumers
                self.notify_consumers(match_id)
    
    def _simulate_stats_update(self, match_id: str) -> Dict[str, Any]:
        """Simulate a statistics update for demonstration purposes"""
        match_data = self.active_matches[match_id]
        
        # Generate some random statistics
        return {
            "run_rate": round(random.uniform(4.0, 8.0), 2),
            "required_run_rate": round(random.uniform(6.0, 12.0), 2),
            "partnership": random.randint(10, 150),
            "last_5_overs": random.randint(20, 60),
            "dot_ball_percentage": round(random.uniform(30.0, 60.0), 1)
        } 