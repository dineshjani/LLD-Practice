from typing import Dict, List, Set, Any

from cricbuzz.consumers.base_consumer import MatchSpecificConsumer
from cricbuzz.models.update import UpdateType


class UserNotificationConsumer(MatchSpecificConsumer):
    """Manages user notifications for important events"""
    
    def __init__(self, supported_producer_types=None):
        super().__init__(supported_producer_types or ["cricket"])
        # Map of user_id -> list of match_ids they're subscribed to
        self.user_subscriptions: Dict[str, Set[str]] = {}
        # Map of match_id -> list of user_ids subscribed to it
        self.match_subscribers: Dict[str, Set[str]] = {}
    
    def subscribe_user_to_match(self, user_id: str, match_id: str) -> None:
        """Subscribe a user to notifications for a specific match"""
        # Update user subscriptions
        if user_id not in self.user_subscriptions:
            self.user_subscriptions[user_id] = set()
        self.user_subscriptions[user_id].add(match_id)
        
        # Update match subscribers
        if match_id not in self.match_subscribers:
            self.match_subscribers[match_id] = set()
            self.add_match_interest(match_id)
        self.match_subscribers[match_id].add(user_id)
    
    def unsubscribe_user_from_match(self, user_id: str, match_id: str) -> None:
        """Unsubscribe a user from notifications for a specific match"""
        # Update user subscriptions
        if user_id in self.user_subscriptions and match_id in self.user_subscriptions[user_id]:
            self.user_subscriptions[user_id].remove(match_id)
        
        # Update match subscribers
        if match_id in self.match_subscribers and user_id in self.match_subscribers[match_id]:
            self.match_subscribers[match_id].remove(user_id)
            
            # If no users are subscribed to this match, remove interest
            if not self.match_subscribers[match_id]:
                del self.match_subscribers[match_id]
                self.remove_match_interest(match_id)
    
    def consume(self, match_id: str, producer) -> None:
        # Check if any users are subscribed to this match
        if match_id not in self.match_subscribers or not self.match_subscribers[match_id]:
            return
        
        # Get the match data and latest update from the producer
        producer_data = producer.get_match_data(match_id)
        latest_update = producer_data.get("latest_update", {})
        
        update_type = latest_update.get("type")
        update_data = latest_update.get("data", {})
        
        # Get list of subscribed users
        subscribed_users = list(self.match_subscribers[match_id])
        
        # Send notifications for important events
        if update_type == UpdateType.BALL_UPDATE.value:
            if update_data.get("is_wicket", False):
                self._send_notification_to_users(
                    subscribed_users,
                    match_id,
                    f"WICKET! {update_data.get('batsman', 'Batsman')} is out!"
                )
            elif update_data.get("runs", 0) == 4:
                self._send_notification_to_users(
                    subscribed_users,
                    match_id,
                    f"FOUR! Hit by {update_data.get('batsman', 'Batsman')}"
                )
            elif update_data.get("runs", 0) == 6:
                self._send_notification_to_users(
                    subscribed_users,
                    match_id,
                    f"SIX! Hit by {update_data.get('batsman', 'Batsman')}"
                )
    
    def _send_notification_to_users(self, user_ids: List[str], match_id: str, message: str) -> None:
        # In a real app, this would send push notifications to specific users
        for user_id in user_ids:
            print(f"[NOTIFICATION] User {user_id}, Match {match_id}: {message}") 