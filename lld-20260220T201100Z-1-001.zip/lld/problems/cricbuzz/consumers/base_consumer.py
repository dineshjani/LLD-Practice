from abc import ABC, abstractmethod
from typing import Set, List


class ScoreConsumer(ABC):
    """Observer interface for the Observer pattern"""
    
    @abstractmethod
    def consume(self, match_id: str, producer) -> None:
        """
        Consume an update from a producer
        
        Args:
            match_id: The ID of the match that was updated
            producer: The producer that sent the update
        """
        pass
    
    @abstractmethod
    def get_interested_matches(self) -> Set[str]:
        """Return set of match IDs this consumer is interested in"""
        pass
    
    def can_handle_producer_type(self, producer_type: str) -> bool:
        """
        Check if this consumer can handle updates from a specific producer type
        
        Args:
            producer_type: The type of producer (e.g., 'cricket', 'hockey')
            
        Returns:
            True if this consumer can handle updates from this producer type
        """
        # By default, consumers only handle cricket updates
        return producer_type == "cricket"


class MatchSpecificConsumer(ScoreConsumer):
    """Base class for consumers that track specific matches"""
    
    def __init__(self, supported_producer_types: List[str] = None):
        self.interested_matches: Set[str] = set()
        self.supported_producer_types = supported_producer_types or ["cricket"]
    
    def add_match_interest(self, match_id: str) -> None:
        """Add a match to the set of matches this consumer is interested in"""
        self.interested_matches.add(match_id)
    
    def remove_match_interest(self, match_id: str) -> None:
        """Remove a match from the set of matches this consumer is interested in"""
        if match_id in self.interested_matches:
            self.interested_matches.remove(match_id)
    
    def get_interested_matches(self) -> Set[str]:
        return self.interested_matches
    
    def can_handle_producer_type(self, producer_type: str) -> bool:
        """Check if this consumer can handle updates from a specific producer type"""
        return producer_type in self.supported_producer_types 