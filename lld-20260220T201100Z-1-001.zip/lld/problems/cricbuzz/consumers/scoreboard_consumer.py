from typing import Dict, Any

from cricbuzz.consumers.base_consumer import MatchSpecificConsumer
from cricbuzz.models.update import UpdateType


class ScoreboardConsumer(MatchSpecificConsumer):
    """Manages the scoreboard display"""
    
    def __init__(self, supported_producer_types=None):
        super().__init__(supported_producer_types or ["cricket"])
        self.match_scores: Dict[str, Dict[str, Any]] = {}
    
    def consume(self, match_id: str, producer) -> None:
        # Get the match data and latest update from the producer
        producer_data = producer.get_match_data(match_id)
        match_data = producer_data.get("match_data", {})
        latest_update = producer_data.get("latest_update", {})
        
        # We can now use the producer information to handle different types of updates
        producer_type = producer.producer_type
        update_type = latest_update.get("type")
        
        if producer_type == "cricket" and update_type in [UpdateType.BALL_UPDATE.value, UpdateType.SCORE_UPDATE.value]:
            self._update_cricket_scoreboard(match_id, match_data, latest_update)
        elif producer_type == "hockey":
            # Handle hockey updates differently
            # self._update_hockey_scoreboard(match_id, match_data, latest_update)
            pass
    
    def _update_cricket_scoreboard(self, match_id: str, match_data: Dict[str, Any], latest_update: Dict[str, Any]) -> None:
        if match_id not in self.match_scores:
            self.match_scores[match_id] = {
                "runs": 0,
                "wickets": 0,
                "overs": 0.0,
                "last_update": None
            }
        
        # Update the scoreboard based on the update type
        update_type = latest_update.get("type")
        update_data = latest_update.get("data", {})
        
        if update_type == UpdateType.BALL_UPDATE.value:
            # Get the current score from match_data
            self.match_scores[match_id]["runs"] = match_data.get("score", {}).get("runs", 0)
            self.match_scores[match_id]["wickets"] = match_data.get("score", {}).get("wickets", 0)
            
            # Update overs
            over = match_data.get("current_over", 0)
            ball = match_data.get("current_ball", 0)
            self.match_scores[match_id]["overs"] = over + (ball / 6)
        
        self.match_scores[match_id]["last_update"] = latest_update.get("timestamp")
        
        # Print updated scoreboard (in a real app, this would update UI)
        print(f"[SCOREBOARD] Match {match_id}: "
              f"{self.match_scores[match_id]['runs']}/{self.match_scores[match_id]['wickets']} "
              f"({self.match_scores[match_id]['overs']} overs)")
    
    def get_match_score(self, match_id: str) -> Dict[str, Any]:
        """Get the current score for a match"""
        if match_id not in self.match_scores:
            return {"runs": 0, "wickets": 0, "overs": 0.0}
        return self.match_scores[match_id] 