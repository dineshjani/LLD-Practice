from typing import Dict, List, Any

from cricbuzz.consumers.base_consumer import MatchSpecificConsumer
from cricbuzz.models.update import UpdateType


class CommentaryConsumer(MatchSpecificConsumer):
    """Manages the ball-by-ball commentary"""
    
    def __init__(self, supported_producer_types=None):
        super().__init__(supported_producer_types or ["cricket"])
        self.match_commentaries: Dict[str, List[Dict[str, Any]]] = {}
    
    def consume(self, match_id: str, producer) -> None:
        # Get the match data and latest update from the producer
        producer_data = producer.get_match_data(match_id)
        match_data = producer_data.get("match_data", {})
        latest_update = producer_data.get("latest_update", {})
        
        update_type = latest_update.get("type")
        
        if update_type in [UpdateType.BALL_UPDATE.value, UpdateType.COMMENTARY_UPDATE.value]:
            self._update_commentary(match_id, producer.producer_name, latest_update)
    
    def _update_commentary(self, match_id: str, producer_name: str, latest_update: Dict[str, Any]) -> None:
        if match_id not in self.match_commentaries:
            self.match_commentaries[match_id] = []
        
        update_type = latest_update.get("type")
        update_data = latest_update.get("data", {})
        
        commentary_entry = {
            "timestamp": latest_update.get("timestamp"),
            "source": producer_name,
            "type": update_type
        }
        
        if update_type == UpdateType.BALL_UPDATE.value:
            runs = update_data.get("runs", 0)
            
            commentary_text = ""
            if update_data.get("is_wicket", False):
                commentary_text += "WICKET! "
            
            if runs == 4:
                commentary_text += "FOUR! "
            elif runs == 6:
                commentary_text += "SIX! "
            
            commentary_text += f"{update_data.get('bowler', 'Bowler')} to {update_data.get('batsman', 'Batsman')}, "
            commentary_text += f"{runs} run{'s' if runs != 1 else ''}"
            
            if "commentary" in update_data:
                commentary_text += f". {update_data['commentary']}"
            
            commentary_entry["text"] = commentary_text
        elif update_type == UpdateType.COMMENTARY_UPDATE.value:
            commentary_entry["text"] = update_data.get("text", "")
        
        self.match_commentaries[match_id].append(commentary_entry)
        
        # Print the latest commentary (in a real app, this would update UI)
        print(f"[COMMENTARY] {commentary_entry.get('text', '')}")
    
    def get_match_commentary(self, match_id: str, limit: int = None) -> Dict[str, List[Dict[str, Any]]]:
        """Get commentary for a match, optionally limited to the most recent entries"""
        if match_id not in self.match_commentaries:
            return {"commentaries": []}
        
        commentaries = self.match_commentaries[match_id]
        if limit is not None:
            return {"commentaries": commentaries[-limit:]}
        return {"commentaries": commentaries} 