# Cricbuzz Low-Level Design

This is a low-level design implementation of a Cricbuzz-like system that provides real-time cricket score updates. The system follows the Observer design pattern to handle updates from multiple third-party sources (ICC, ESPN, BCCI) and distribute them to various components.

## Design Overview

### Observer Pattern Implementation
- **Publishers**: ICC, ESPN, and BCCI score providers that fetch cricket updates
- **Observers**: Components like ScoreboardManager, CommentaryManager, and UserNotificationManager
- **Match-specific subscriptions**: Each observer can subscribe to specific matches

### Key Features
- Real-time score updates
- Ball-by-ball commentary
- User notifications for important events (wickets, boundaries)
- Support for multiple data sources
- Match-specific subscriptions

### SOLID Principles
- **Single Responsibility**: Each class has a single, well-defined responsibility
- **Open/Closed**: System can be extended with new publishers or observers without modifying existing code
- **Liskov Substitution**: All publishers and observers follow their respective interfaces
- **Interface Segregation**: Clean interfaces for publishers and observers
- **Dependency Inversion**: High-level modules depend on abstractions, not concrete implementations

## Usage

Run the demo to see the system in action:
