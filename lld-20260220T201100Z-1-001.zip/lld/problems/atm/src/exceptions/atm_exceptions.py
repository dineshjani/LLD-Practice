class ATMException(Exception):
    """Base exception for ATM-related errors"""
    pass

class InvalidStateOperationException(ATMException):
    """Exception raised when an operation is not valid in the current state"""
    def __init__(self, current_state: str, operation: str):
        self.current_state = current_state
        self.operation = operation
        message = f"Operation '{operation}' is not valid in state '{current_state}'"
        super().__init__(message)

class TransactionException(ATMException):
    """Exception raised when a transaction fails"""
    pass

class PINValidationException(ATMException):
    """Exception raised when PIN validation fails"""
    def __init__(self, remaining_attempts: int = None):
        self.remaining_attempts = remaining_attempts
        message = f"PIN validation failed. {remaining_attempts} attempts remaining." if remaining_attempts is not None else "PIN validation failed."
        super().__init__(message)

class CardException(ATMException):
    """Exception raised for card-related errors"""
    pass

class HardwareException(ATMException):
    """Exception raised for hardware-related errors"""
    pass

class InvalidTransactionException(ATMException):
    """Exception raised when a transaction is invalid"""
    pass 