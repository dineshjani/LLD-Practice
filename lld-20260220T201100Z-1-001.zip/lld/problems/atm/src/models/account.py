from typing import List, Optional
from dataclasses import dataclass, field
from datetime import datetime

@dataclass
class Transaction:
    transaction_id: str
    amount: float
    timestamp: datetime
    transaction_type: str
    status: str
    description: Optional[str] = None

@dataclass
class Account:
    account_id: str
    account_number: str
    balance: float = 0.0
    account_type: str = "Checking"
    is_active: bool = True
    created_at: datetime = field(default_factory=datetime.now)
    transactions: List[Transaction] = field(default_factory=list)
    
    def deposit(self, amount: float) -> bool:
        """Add funds to the account"""
        if amount <= 0:
            return False
        
        self.balance += amount
        
        # Record transaction
        transaction = Transaction(
            transaction_id=f"T{datetime.now().strftime('%Y%m%d%H%M%S')}",
            amount=amount,
            timestamp=datetime.now(),
            transaction_type="DEPOSIT",
            status="COMPLETED",
            description=f"Deposit of ${amount:.2f}"
        )
        self.transactions.append(transaction)
        
        return True
    
    def withdraw(self, amount: float) -> bool:
        """Remove funds from the account if sufficient balance exists"""
        if amount <= 0 or amount > self.balance:
            return False
        
        self.balance -= amount
        
        # Record transaction
        transaction = Transaction(
            transaction_id=f"T{datetime.now().strftime('%Y%m%d%H%M%S')}",
            amount=amount,
            timestamp=datetime.now(),
            transaction_type="WITHDRAWAL",
            status="COMPLETED",
            description=f"Withdrawal of ${amount:.2f}"
        )
        self.transactions.append(transaction)
        
        return True
    
    def get_transaction_history(self, limit: int = 10) -> List[Transaction]:
        """Get recent transactions, limited to the specified number"""
        return sorted(
            self.transactions, 
            key=lambda t: t.timestamp, 
            reverse=True
        )[:limit] 