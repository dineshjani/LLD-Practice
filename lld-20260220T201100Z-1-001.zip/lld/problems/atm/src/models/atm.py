from typing import Optional, Dict
import uuid
from ..services.authentication_service import AuthenticationService
from ..services.card_service import CardService
from ..services.transaction_service import TransactionService
from ..services.printer_service import PrinterService
from ..services.hardware_service import HardwareService
from ..models.transaction import TransactionType, TransactionResult
from ..factories.card_manager_factory import CardManagerFactory
from ..factories.state_manager_factory import StateManagerFactory
from ..states.atm_state import ATMState

class ATM:
    # Class variable to track all ATM instances
    _instances: Dict[str, 'ATM'] = {}
    
    def __init__(
        self,
        authentication_service: AuthenticationService,
        transaction_service: TransactionService,
        printer_service: PrinterService,
        hardware_service: HardwareService,
        machine_id: str = None
    ):
        # Generate a unique machine ID if not provided
        self.machine_id = machine_id or str(uuid.uuid4())
        
        # Services
        self.authentication_service = authentication_service
        self.card_service = CardManagerFactory.get_card_manager(self.machine_id)
        self.transaction_service = transaction_service
        self.printer_service = printer_service
        self.hardware_service = hardware_service
        
        # State and transaction data
        self.current_state = StateManagerFactory.get_initial_state(self)
        self.card_number: Optional[str] = None
        self.transaction_type: Optional[TransactionType] = None
        self.transaction_amount: Optional[float] = None
        self.last_transaction_result: Optional[TransactionResult] = None
        
        # Register this ATM instance
        ATM._instances[self.machine_id] = self
    
    @classmethod
    def get_atm(cls, machine_id: str) -> Optional['ATM']:
        """Get an ATM instance by its machine ID"""
        return cls._instances.get(machine_id)
    
    def change_state(self, state_name: str) -> None:
        """
        Change the ATM's state using the state manager factory
        
        Args:
            state_name: The name of the state to change to
        """
        new_state = StateManagerFactory.create_state(state_name, self)
        print(f"ATM {self.machine_id} State changed from {type(self.current_state).__name__} to {type(new_state).__name__}")
        self.current_state = new_state
    
    def change_state_object(self, new_state: ATMState) -> None:
        """
        Change the ATM's state using a state object
        
        Args:
            new_state: The state object to change to
        """
        print(f"ATM {self.machine_id} State changed from {type(self.current_state).__name__} to {type(new_state).__name__}")
        self.current_state = new_state

    def insert_card(self, card_number: str) -> bool:
        return self.current_state.insert_card(card_number)
    
    def enter_pin(self, pin: str) -> bool:
        return self.current_state.enter_pin(pin)
    
    def select_transaction(self, transaction_type: TransactionType, amount: Optional[float] = None) -> bool:
        return self.current_state.select_transaction(transaction_type, amount)
    
    def process_transaction(self) -> bool:
        return self.current_state.process_transaction()
    
    def print_receipt(self) -> bool:
        return self.current_state.print_receipt()
    
    def eject_card(self) -> bool:
        return self.current_state.eject_card()
    
    def cancel(self) -> bool:
        return self.current_state.cancel()