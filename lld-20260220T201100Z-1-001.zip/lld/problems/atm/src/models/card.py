class Card:
    def __init__(self, card_number: str, pin: str):
        self.card_number = card_number
        self._pin = pin
        self.is_blocked = False
        
    def validate_pin(self, entered_pin: str) -> bool:
        """Check if the entered PIN matches the card's PIN"""
        return self._pin == entered_pin 