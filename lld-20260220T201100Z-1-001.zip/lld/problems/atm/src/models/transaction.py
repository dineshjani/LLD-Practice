from enum import Enum
from typing import Optional

class TransactionType(Enum):
    WITHDRAWAL = "withdrawal"
    DEPOSIT = "deposit"
    BALANCE_INQUIRY = "balance_inquiry"
    
class TransactionResult:
    def __init__(self, success: bool, balance: Optional[float] = None, error_message: Optional[str] = None):
        self.success = success
        self.balance = balance
        self.error_message = error_message 