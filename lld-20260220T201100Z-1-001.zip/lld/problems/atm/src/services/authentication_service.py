from dataclasses import dataclass
from typing import Dict, Optional

@dataclass
class AuthResult:
    success: bool
    message: Optional[str] = None
    remaining_attempts: Optional[int] = None

class AuthenticationService:
    def __init__(self):
        # In a real implementation, this would connect to a secure database
        self._valid_cards = {
            "1234-5678-9012-3456": {"pin": "1234", "blocked": False, "attempts": 0}
        }
        self.MAX_PIN_ATTEMPTS = 3
        
    def validate_card(self, card_number: str) -> AuthResult:
        """Check if the card exists and is not blocked"""
        if card_number not in self._valid_cards:
            return AuthResult(False, "Card not recognized")
            
        if self._valid_cards[card_number]["blocked"]:
            return AuthResult(False, "Card is blocked")
            
        return AuthResult(True)
        
    def verify_pin(self, card_number: str, pin: str) -> AuthResult:
        """Verify the PIN for a given card"""
        if card_number not in self._valid_cards:
            return AuthResult(False, "Card not recognized")
            
        card_data = self._valid_cards[card_number]
        
        if card_data["blocked"]:
            return AuthResult(False, "Card is blocked")
            
        if card_data["pin"] != pin:
            # Increment failed attempts
            card_data["attempts"] += 1
            remaining = self.MAX_PIN_ATTEMPTS - card_data["attempts"]
            
            if card_data["attempts"] >= self.MAX_PIN_ATTEMPTS:
                card_data["blocked"] = True
                return AuthResult(False, "Card has been blocked due to too many failed attempts", 0)
                
            return AuthResult(False, f"Invalid PIN. {remaining} attempts remaining", remaining)
            
        # Reset attempts on successful PIN entry
        card_data["attempts"] = 0
        return AuthResult(True) 