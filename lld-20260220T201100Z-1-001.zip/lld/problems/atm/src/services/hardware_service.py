import time
from typing import Optional

class HardwareService:
    def __init__(self):
        self.card_inserted = False
        self.cash_available = 10000.0  # Initial cash in the ATM
    
    def read_card(self, card_number: str) -> bool:
        """Simulate reading a card's magnetic stripe or chip"""
        # In a real implementation, this would interact with hardware
        print(f"Reading card: {card_number}")
        self.card_inserted = True
        return True
    
    def eject_card(self) -> bool:
        """Eject the card from the ATM"""
        # In a real implementation, this would control the card ejection mechanism
        if not self.card_inserted:
            return False
        
        print("Ejecting card...")
        time.sleep(0.5)  # Simulate the time it takes to eject a card
        self.card_inserted = False
        print("Card ejected")
        return True
    
    def dispense_cash(self, amount: float) -> bool:
        """Dispense cash from the ATM"""
        # In a real implementation, this would control the cash dispensing mechanism
        if amount <= 0:
            return False
        
        if amount > self.cash_available:
            print("ATM does not have enough cash")
            return False
        
        print(f"Dispensing ${amount:.2f}...")
        time.sleep(1)  # Simulate the time it takes to count and dispense cash
        self.cash_available -= amount
        print(f"Cash dispensed: ${amount:.2f}")
        return True
    
    def accept_deposit(self, amount: float) -> bool:
        """Accept a cash or check deposit"""
        # In a real implementation, this would control the deposit mechanism
        if amount <= 0:
            return False
        
        print(f"Accepting deposit of ${amount:.2f}...")
        time.sleep(1)  # Simulate the time it takes to process a deposit
        self.cash_available += amount
        print(f"Deposit accepted: ${amount:.2f}")
        return True
    
    def check_hardware_status(self) -> dict:
        """Check the status of ATM hardware components"""
        return {
            "card_reader": "OK",
            "cash_dispenser": "OK" if self.cash_available > 0 else "LOW",
            "deposit_slot": "OK",
            "printer": "OK",
            "network": "CONNECTED",
            "cash_available": self.cash_available
        } 