from typing import Dict, Optional
from ..models.card import Card

class CardService:
    def __init__(self):
        # In a real implementation, this would connect to a secure database
        self._cards: Dict[str, Card] = {
            "1234-5678-9012-3456": Card("1234-5678-9012-3456", "1234")
        }
    
    def get_card(self, card_number: str) -> Optional[Card]:
        """Retrieve a card by its number"""
        return self._cards.get(card_number)
    
    def validate_card(self, card_number: str) -> bool:
        """Check if a card exists and is not blocked"""
        card = self.get_card(card_number)
        if card is None:
            return False
        return not card.is_blocked
    
    def block_card(self, card_number: str) -> bool:
        """Block a card"""
        card = self.get_card(card_number)
        if card is None:
            return False
        
        card.is_blocked = True
        return True
    
    def unblock_card(self, card_number: str) -> bool:
        """Unblock a card"""
        card = self.get_card(card_number)
        if card is None:
            return False
        
        card.is_blocked = False
        return True 