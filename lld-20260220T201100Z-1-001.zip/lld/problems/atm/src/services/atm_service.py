from typing import Optional, Dict
from ..models.transaction import TransactionType, TransactionResult
from ..models.atm import ATM
from .authentication_service import AuthenticationService
from .transaction_service import TransactionService
from .printer_service import PrinterService
from .hardware_service import HardwareService

class ATMService:
    # Class variable to track ATM service instances by machine ID
    _instances: Dict[str, 'ATMService'] = {}
    
    @classmethod
    def get_instance(cls, machine_id: str = None) -> 'ATMService':
        """
        Get or create an ATM service instance for a specific machine ID
        
        Args:
            machine_id: The unique identifier for the ATM
            
        Returns:
            An ATMService instance for the specified machine ID
        """
        if machine_id is None:
            # Create a new instance with a new ATM
            service = ATMService()
            machine_id = service.atm.machine_id
            cls._instances[machine_id] = service
            return service
        
        if machine_id not in cls._instances:
            # Create a new instance for this machine ID
            cls._instances[machine_id] = ATMService(machine_id)
        
        return cls._instances[machine_id]
    
    def __init__(self, machine_id: str = None):
        self.authentication_service = AuthenticationService()
        self.transaction_service = TransactionService()
        self.printer_service = PrinterService()
        self.hardware_service = HardwareService()
        
        # Create or get the ATM instance
        existing_atm = ATM.get_atm(machine_id) if machine_id else None
        
        if existing_atm:
            self.atm = existing_atm
        else:
            self.atm = ATM(
                authentication_service=self.authentication_service,
                transaction_service=self.transaction_service,
                printer_service=self.printer_service,
                hardware_service=self.hardware_service,
                machine_id=machine_id
            )
    
    def get_machine_id(self) -> str:
        """Get the machine ID of the ATM"""
        return self.atm.machine_id
    
    def insert_card(self, card_number: str) -> bool:
        """Attempt to insert a card into the ATM"""
        return self.atm.insert_card(card_number)
    
    def enter_pin(self, pin: str) -> bool:
        """Enter PIN for the inserted card"""
        return self.atm.enter_pin(pin)
    
    def select_transaction(self, transaction_type: TransactionType, amount: Optional[float] = None) -> bool:
        """Select a transaction type and amount if applicable"""
        return self.atm.select_transaction(transaction_type, amount)
    
    def process_transaction(self) -> bool:
        """Process the selected transaction"""
        return self.atm.process_transaction()
    
    def print_receipt(self) -> bool:
        """Print a receipt for the transaction"""
        return self.atm.print_receipt()
    
    def eject_card(self) -> bool:
        """Eject the card from the ATM"""
        return self.atm.eject_card()
    
    def cancel(self) -> bool:
        """Cancel the current operation"""
        return self.atm.cancel() 