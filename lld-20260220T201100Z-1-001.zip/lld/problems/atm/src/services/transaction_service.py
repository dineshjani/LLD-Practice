from typing import Optional
from ..models.transaction import TransactionResult

class TransactionService:
    def __init__(self):
        # In a real implementation, this would connect to a database or banking system
        self._account_balances = {}  # Mock storage for demo purposes
        
    def withdraw(self, card_number: str, amount: float) -> TransactionResult:
        """Process a withdrawal transaction"""
        if card_number not in self._account_balances:
            self._account_balances[card_number] = 1000.0  # Default balance for demo
            
        current_balance = self._account_balances[card_number]
        
        if amount <= 0:
            return TransactionResult(False, current_balance, "Invalid withdrawal amount")
            
        if amount > current_balance:
            return TransactionResult(False, current_balance, "Insufficient funds")
            
        # Process withdrawal
        self._account_balances[card_number] -= amount
        new_balance = self._account_balances[card_number]
        
        return TransactionResult(True, new_balance)
        
    def deposit(self, card_number: str, amount: float) -> TransactionResult:
        """Process a deposit transaction"""
        if card_number not in self._account_balances:
            self._account_balances[card_number] = 0.0
            
        if amount <= 0:
            return TransactionResult(False, self._account_balances[card_number], "Invalid deposit amount")
            
        # Process deposit
        self._account_balances[card_number] += amount
        new_balance = self._account_balances[card_number]
        
        return TransactionResult(True, new_balance)
        
    def get_balance(self, card_number: str) -> TransactionResult:
        """Get account balance"""
        if card_number not in self._account_balances:
            self._account_balances[card_number] = 1000.0  # Default balance for demo
            
        return TransactionResult(True, self._account_balances[card_number]) 