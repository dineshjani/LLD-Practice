from typing import Optional
from datetime import datetime
from ..models.transaction import TransactionType

class PrinterService:
    def __init__(self):
        self.paper_available = True
        self.ink_available = True
    
    def print_receipt(self, transaction_type: TransactionType, amount: Optional[float], card_number: str) -> bool:
        """Print a receipt for a transaction"""
        if not self.paper_available or not self.ink_available:
            print("Printer error: Out of paper or ink")
            return False
        
        # Format the receipt
        receipt = self._format_receipt(transaction_type, amount, card_number)
        
        # In a real implementation, this would send the receipt to a physical printer
        print("\n--- RECEIPT ---")
        print(receipt)
        print("---------------\n")
        
        return True
    
    def _format_receipt(self, transaction_type: TransactionType, amount: Optional[float], card_number: str) -> str:
        """Format a receipt for printing"""
        now = datetime.now()
        date_str = now.strftime("%Y-%m-%d")
        time_str = now.strftime("%H:%M:%S")
        
        # Mask the card number for security
        masked_card = f"XXXX-XXXX-XXXX-{card_number[-4:]}"
        
        receipt_lines = [
            "BANK ATM",
            f"Date: {date_str}",
            f"Time: {time_str}",
            f"Card: {masked_card}",
            f"Transaction: {transaction_type.value.upper()}"
        ]
        
        if amount is not None:
            receipt_lines.append(f"Amount: ${amount:.2f}")
        
        receipt_lines.append("Thank you for using our ATM")
        
        return "\n".join(receipt_lines)
    
    def check_printer_status(self) -> dict:
        """Check the status of the printer"""
        return {
            "paper_available": self.paper_available,
            "ink_available": self.ink_available
        }
    
    def refill_paper(self) -> bool:
        """Refill the printer paper"""
        self.paper_available = True
        return True
    
    def refill_ink(self) -> bool:
        """Refill the printer ink"""
        self.ink_available = True
        return True 