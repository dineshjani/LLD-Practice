from .atm_state import ATMState
from typing import Optional
from ..models.transaction import TransactionType
from ..exceptions.atm_exceptions import PINValidationException
from .transaction_selection_state import TransactionSelectionState
from .idle_state import IdleState

class PinEntryState(ATMState):
    def insert_card(self, card_number: str) -> bool:
        print("Card already inserted")
        return False

    def enter_pin(self, pin: str) -> bool:
        auth_result = self.atm.authentication_service.verify_pin(
            self.atm.card_number, 
            pin
        )
        
        if not auth_result.success:
            print(f"PIN validation failed: {auth_result.message}")
            if auth_result.remaining_attempts == 0:
                # Card has been blocked, eject it
                self.eject_card()
            return False
            
        # Change to TransactionSelectionState
        self.atm.change_state_object(TransactionSelectionState(self.atm))
        return True
    
    def select_transaction(self, transaction_type: TransactionType, amount: Optional[float] = None) -> bool:
        print("Please enter your PIN first")
        return False
    
    def process_transaction(self) -> bool:
        print("Please enter your PIN first")
        return False
    
    def print_receipt(self) -> bool:
        print("Please enter your PIN first")
        return False
    
    def cancel(self) -> bool:
        return self.eject_card()
    
    def eject_card(self) -> bool:
        try:
            success = self.atm.hardware_service.eject_card()
            if success:
                self.atm.card_number = None
                self.atm.change_state_object(IdleState(self.atm))
                return True
            return False
        except Exception as e:
            print(f"Error ejecting card: {str(e)}")
            return False
    
    
    