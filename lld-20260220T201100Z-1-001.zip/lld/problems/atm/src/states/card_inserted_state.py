from .atm_state import ATMState
from .pin_entry_state import PinEntryState
from ..models.transaction import TransactionType
from typing import Optional
from .idle_state import IdleState

class CardInsertedState(ATMState):
    def insert_card(self, card_number: str) -> bool:
        print("Card already inserted")
        return False

    def enter_pin(self, pin: str) -> bool:
        self.atm.change_state(PinEntryState(self.atm))
        return self.atm.current_state.enter_pin(pin)

    def select_transaction(self, transaction_type: TransactionType, amount: Optional[float] = None) -> bool:
        print("Please enter PIN first")
        return False

    def process_transaction(self) -> bool:
        print("Please enter PIN first")
        return False

    def cancel(self) -> None:
        self.atm.card_number = None
        self.atm.change_state(IdleState(self.atm)) 