from .atm_state import ATMState
from typing import Optional
from ..models.transaction import TransactionType
from ..exceptions.atm_exceptions import InvalidTransactionException
from .transaction_state import TransactionState
from .idle_state import IdleState

class TransactionSelectionState(ATMState):
    def insert_card(self, card_number: str) -> bool:
        print("Card already inserted")
        return False
    
    def enter_pin(self, pin: str) -> bool:
        print("PIN already verified")
        return False
    
    def select_transaction(self, transaction_type: TransactionType, amount: Optional[float] = None) -> bool:
        # Validate transaction type and amount
        if not self._validate_transaction(transaction_type, amount):
            print("Invalid transaction parameters")
            return False

        # Store transaction details in ATM
        self.atm.transaction_type = transaction_type
        self.atm.transaction_amount = amount

        # Move to TransactionState for processing
        self.atm.change_state_object(TransactionState(self.atm))
        return True

    def _validate_transaction(self, transaction_type: TransactionType, amount: Optional[float]) -> bool:
        if transaction_type == TransactionType.WITHDRAWAL:
            return amount is not None and amount > 0
        elif transaction_type == TransactionType.DEPOSIT:
            return amount is not None and amount > 0
        elif transaction_type == TransactionType.BALANCE_INQUIRY:
            return True
        return False
    
    def process_transaction(self) -> bool:
        print("Please select a transaction first")
        return False
    
    def print_receipt(self) -> bool:
        print("Please select and process a transaction first")
        return False
    
    def cancel(self) -> bool:
        return self.eject_card()
    
    def eject_card(self) -> bool:
        try:
            success = self.atm.hardware_service.eject_card()
            if success:
                self.atm.card_number = None
                self.atm.transaction_type = None
                self.atm.transaction_amount = None
                self.atm.change_state_object(IdleState(self.atm))
                return True
            return False
        except Exception as e:
            print(f"Error ejecting card: {str(e)}")
            return False
    