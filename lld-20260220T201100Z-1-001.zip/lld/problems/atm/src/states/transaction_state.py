from typing import Optional
from .atm_state import ATMState
from .printing_state import PrintingState
from .idle_state import IdleState
from ..models.transaction import TransactionType, TransactionResult
from ..exceptions.atm_exceptions import (
    InvalidStateOperationException,
    TransactionException
)

class TransactionState(ATMState):
    def insert_card(self, card_number: str) -> bool:
        print("Card already inserted")
        return False

    def enter_pin(self, pin: str) -> bool:
        print("PIN already verified")
        return False

    def select_transaction(self, transaction_type: TransactionType, amount: Optional[float] = None) -> bool:
        print("Transaction already selected")
        return False

    def process_transaction(self) -> bool:
        try:
            # Validate that we have necessary transaction information
            if self.atm.transaction_type is None:
                print("No transaction type selected")
                return False

            # Process the transaction based on type
            if self.atm.transaction_type == TransactionType.WITHDRAWAL:
                success = self._process_withdrawal()
            elif self.atm.transaction_type == TransactionType.DEPOSIT:
                success = self._process_deposit()
            elif self.atm.transaction_type == TransactionType.BALANCE_INQUIRY:
                success = self._process_balance_inquiry()
            else:
                print("Unsupported transaction type")
                return False

            if success:
                # Move to printing state after successful transaction
                self.atm.change_state_object(PrintingState(self.atm))
                return True
            else:
                print("Transaction failed")
                return False

        except Exception as e:
            # Handle any unexpected errors
            print(f"Transaction failed: {str(e)}")
            return False

    def _process_withdrawal(self) -> bool:
        if self.atm.transaction_amount is None:
            print("No amount specified for withdrawal")
            return False

        # First check if the hardware can dispense the cash
        if not self.atm.hardware_service.dispense_cash(self.atm.transaction_amount):
            print("Hardware error: Cannot dispense cash")
            return False

        # Then process the transaction with the banking system
        result = self.atm.transaction_service.withdraw(
            card_number=self.atm.card_number,
            amount=self.atm.transaction_amount
        )

        if not result.success:
            print(f"Transaction failed: {result.error_message}")
            return False

        self.atm.last_transaction_result = result
        return True

    def _process_deposit(self) -> bool:
        if self.atm.transaction_amount is None:
            print("No amount specified for deposit")
            return False

        # First check if the hardware can accept the deposit
        if not self.atm.hardware_service.accept_deposit(self.atm.transaction_amount):
            print("Hardware error: Cannot accept deposit")
            return False

        # Then process the transaction with the banking system
        result = self.atm.transaction_service.deposit(
            card_number=self.atm.card_number,
            amount=self.atm.transaction_amount
        )

        if not result.success:
            print(f"Transaction failed: {result.error_message}")
            return False

        self.atm.last_transaction_result = result
        return True

    def _process_balance_inquiry(self) -> bool:
        result = self.atm.transaction_service.get_balance(
            card_number=self.atm.card_number
        )

        if not result.success:
            print(f"Balance inquiry failed: {result.error_message}")
            return False

        self.atm.last_transaction_result = result
        return True

    def print_receipt(self) -> bool:
        print("Please process the transaction first")
        return False

    def eject_card(self) -> bool:
        try:
            success = self.atm.hardware_service.eject_card()
            if success:
                self.atm.card_number = None
                self.atm.transaction_type = None
                self.atm.transaction_amount = None
                self.atm.change_state_object(IdleState(self.atm))
                return True
            return False
        except Exception as e:
            print(f"Error ejecting card: {str(e)}")
            return False
            
    def cancel(self) -> bool:
        return self.eject_card() 