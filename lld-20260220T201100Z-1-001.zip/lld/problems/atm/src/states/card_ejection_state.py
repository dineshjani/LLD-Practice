from .atm_state import ATMState
from .idle_state import IdleState
from typing import Optional
from ..models.transaction import TransactionType

class CardEjectionState(ATMState):
    def insert_card(self, card_number: str) -> bool:
        print("Please wait, card is being ejected")
        return False

    def enter_pin(self, pin: str) -> bool:
        print("Please wait, card is being ejected")
        return False

    def select_transaction(self, transaction_type: TransactionType, amount: Optional[float] = None) -> bool:
        print("Please wait, card is being ejected")
        return False

    def process_transaction(self) -> bool:
        print("Please wait, card is being ejected")
        return False
        
    def print_receipt(self) -> bool:
        print("Please wait, card is being ejected")
        return False

    def eject_card(self) -> bool:
        try:
            success = self.atm.hardware_service.eject_card()
            if success:
                print("Card ejected successfully")
                self.atm.card_number = None
                self.atm.transaction_type = None
                self.atm.transaction_amount = None
                self.atm.change_state(IdleState(self.atm))
                return True
            else:
                print("Error ejecting card")
                return False
        except Exception as e:
            print(f"Error ejecting card: {str(e)}")
            return False
            
    def cancel(self) -> bool:
        # Already ejecting card, so just continue with that process
        return self.eject_card() 