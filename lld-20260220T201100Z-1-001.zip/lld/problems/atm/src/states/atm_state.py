from abc import ABC, abstractmethod
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..models.atm import ATM
    from ..models.transaction import TransactionType

class ATMState(ABC):
    def __init__(self, atm: 'ATM'):
        self.atm = atm
    
    @abstractmethod
    def insert_card(self, card_number: str) -> bool:
        pass
        
    @abstractmethod
    def enter_pin(self, pin: str) -> bool:
        pass
        
    @abstractmethod
    def select_transaction(self, transaction_type: 'TransactionType', amount: Optional[float] = None) -> bool:
        pass
        
    @abstractmethod
    def process_transaction(self) -> bool:
        pass
        
    @abstractmethod
    def print_receipt(self) -> bool:
        pass
        
    @abstractmethod
    def eject_card(self) -> bool:
        pass
        
    @abstractmethod
    def cancel(self) -> bool:
        pass 