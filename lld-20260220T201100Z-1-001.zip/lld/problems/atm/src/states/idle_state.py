from .atm_state import ATMState
from .card_inserted_state import CardInsertedState
from typing import Optional
from ..models.transaction import TransactionType

class IdleState(ATMState):
    def insert_card(self, card_number: str) -> bool:
        auth_result = self.atm.authentication_service.validate_card(card_number)
        
        if auth_result.success:
            self.atm.card_number = card_number
            self.atm.hardware_service.read_card(card_number)
            self.atm.change_state_object(CardInsertedState(self.atm))
            return True
        else:
            print(f"Card validation failed: {auth_result.message}")
            return False

    def enter_pin(self, pin: str) -> bool:
        print("Please insert a card first")
        return False  # Cannot enter PIN in idle state

    def select_transaction(self, transaction_type: TransactionType, amount: Optional[float] = None) -> bool:
        print("Please insert a card first")
        return False  # Cannot select transaction in idle state
        
    def process_transaction(self) -> bool:
        print("Please insert a card first")
        return False
        
    def print_receipt(self) -> bool:
        print("Please insert a card first")
        return False
        
    def eject_card(self) -> bool:
        print("No card inserted")
        return False

    def cancel(self) -> bool:
        print("Nothing to cancel")
        return False  # Already in idle state