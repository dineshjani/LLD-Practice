from .atm_state import ATMState
from typing import Optional
from ..models.transaction import TransactionType
from .card_ejection_state import CardEjectionState

class PrintingState(ATMState):
    def insert_card(self, card_number: str) -> bool:
        print("Currently printing receipt")
        return False

    def enter_pin(self, pin: str) -> bool:
        print("Currently printing receipt")
        return False

    def select_transaction(self, transaction_type: TransactionType, amount: Optional[float] = None) -> bool:
        print("Currently printing receipt")
        return False

    def process_transaction(self) -> bool:
        print("Currently printing receipt")
        return False

    def print_receipt(self) -> bool:
        try:
            success = self.atm.printer_service.print_receipt(
                transaction_type=self.atm.transaction_type,
                amount=self.atm.transaction_amount,
                card_number=self.atm.card_number
            )
            
            if success:
                # Automatically move to card ejection after printing
                self.atm.change_state_object(CardEjectionState(self.atm))
                return self.atm.current_state.eject_card()
            else:
                print("Error printing receipt")
                self.atm.change_state_object(CardEjectionState(self.atm))
                return self.atm.current_state.eject_card()

        except Exception as e:
            print(f"Error printing receipt: {str(e)}")
            self.atm.change_state_object(CardEjectionState(self.atm))
            return self.atm.current_state.eject_card()
    
    def cancel(self) -> bool:
        print("Skipping receipt printing")
        self.atm.change_state_object(CardEjectionState(self.atm))
        return self.atm.current_state.eject_card()
    
    def eject_card(self) -> bool:
        print("Please wait for receipt printing to complete")
        return False

    
    