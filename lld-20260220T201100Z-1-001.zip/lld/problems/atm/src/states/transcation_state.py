from typing import Optional
from .atm_state import ATMState
from .printing_state import PrintingState
from .idle_state import IdleState
from ..models.transaction import TransactionType
from ..exceptions.atm_exceptions import (
    InvalidStateOperationException,
    TransactionException
)

class TransactionState(ATMState):
    def insert_card(self, card_number: str) -> bool:
        raise InvalidStateOperationException(
            current_state=self.__class__.__name__,
            operation="insert_card"
        )

    def enter_pin(self, pin: str) -> bool:
        raise InvalidStateOperationException(
            current_state=self.__class__.__name__,
            operation="enter_pin"
        )

    def select_transaction(self, transaction_type: TransactionType, amount: Optional[float] = None) -> bool:
        raise InvalidStateOperationException(
            current_state=self.__class__.__name__,
            operation="select_transaction"
        )

    def process_transaction(self) -> bool:
        try:
            # Validate that we have necessary transaction information
            if self.atm.transaction_type is None:
                raise TransactionException("No transaction type selected")

            # Process the transaction based on type
            if self.atm.transaction_type == TransactionType.WITHDRAWAL:
                success = self._process_withdrawal()
            elif self.atm.transaction_type == TransactionType.DEPOSIT:
                success = self._process_deposit()
            elif self.atm.transaction_type == TransactionType.BALANCE_INQUIRY:
                success = self._process_balance_inquiry()
            else:
                raise TransactionException("Unsupported transaction type")

            if success:
                # Move to printing state after successful transaction
                self.atm.change_state(PrintingState(self.atm))
                return True
            else:
                # Move to idle state if transaction fails
                self.atm.change_state(IdleState(self.atm))
                return False

        except Exception as e:
            # Handle any unexpected errors
            self.atm.change_state(IdleState(self.atm))
            raise TransactionException(f"Transaction failed: {str(e)}")

    def _process_withdrawal(self) -> bool:
        if self.atm.transaction_amount is None:
            raise TransactionException("No amount specified for withdrawal")

        result = self.atm.transaction_service.withdraw(
            card_number=self.atm.card_number,
            amount=self.atm.transaction_amount
        )

        if not result.success:
            raise TransactionException(result.error_message)

        self.atm.last_transaction_result = result
        return True

    def _process_deposit(self) -> bool:
        if self.atm.transaction_amount is None:
            raise TransactionException("No amount specified for deposit")

        result = self.atm.transaction_service.deposit(
            card_number=self.atm.card_number,
            amount=self.atm.transaction_amount
        )

        if not result.success:
            raise TransactionException(result.error_message)

        self.atm.last_transaction_result = result
        return True

    def _process_balance_inquiry(self) -> bool:
        result = self.atm.transaction_service.get_balance(
            card_number=self.atm.card_number
        )

        if not result.success:
            raise TransactionException(result.error_message)

        self.atm.last_transaction_result = result
        return True

    def print_receipt(self) -> bool:
        raise InvalidStateOperationException(
            current_state=self.__class__.__name__,
            operation="print_receipt"
        )

    def eject_card(self) -> bool:
        raise InvalidStateOperationException(
            current_state=self.__class__.__name__,
            operation="eject_card"
        )