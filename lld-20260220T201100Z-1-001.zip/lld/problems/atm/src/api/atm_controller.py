from typing import Optional, Dict, Any
from flask import Flask, request, jsonify
from ..services.atm_service import ATMService
from ..models.transaction import TransactionType

app = Flask(__name__)

@app.route('/api/atm/<machine_id>/card/insert', methods=['POST'])
def insert_card(machine_id: str):
    data = request.json
    card_number = data.get('card_number')
    
    if not card_number:
        return jsonify({'success': False, 'message': 'Card number is required'}), 400
    
    atm_service = ATMService.get_instance(machine_id)
    success = atm_service.insert_card(card_number)
    
    if success:
        return jsonify({'success': True, 'message': 'Card inserted successfully'})
    else:
        return jsonify({'success': False, 'message': 'Failed to insert card'})

@app.route('/api/atm/<machine_id>/pin/enter', methods=['POST'])
def enter_pin(machine_id: str):
    data = request.json
    pin = data.get('pin')
    
    if not pin:
        return jsonify({'success': False, 'message': 'PIN is required'}), 400
    
    try:
        atm_service = ATMService.get_instance(machine_id)
        success = atm_service.enter_pin(pin)
        if success:
            return jsonify({'success': True, 'message': 'PIN accepted'})
        else:
            return jsonify({'success': False, 'message': 'Invalid PIN'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/api/atm/<machine_id>/transaction/select', methods=['POST'])
def select_transaction(machine_id: str):
    data = request.json
    transaction_type_str = data.get('transaction_type')
    amount = data.get('amount')
    
    if not transaction_type_str:
        return jsonify({'success': False, 'message': 'Transaction type is required'}), 400
    
    try:
        transaction_type = TransactionType(transaction_type_str)
        
        # Convert amount to float if provided
        if amount is not None:
            amount = float(amount)
        
        atm_service = ATMService.get_instance(machine_id)
        success = atm_service.select_transaction(transaction_type, amount)
        
        if success:
            return jsonify({'success': True, 'message': 'Transaction selected'})
        else:
            return jsonify({'success': False, 'message': 'Failed to select transaction'})
    except ValueError:
        return jsonify({'success': False, 'message': 'Invalid transaction type or amount'}), 400
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/api/atm/<machine_id>/transaction/process', methods=['POST'])
def process_transaction(machine_id: str):
    try:
        atm_service = ATMService.get_instance(machine_id)
        success = atm_service.process_transaction()
        
        if success:
            return jsonify({'success': True, 'message': 'Transaction processed successfully'})
        else:
            return jsonify({'success': False, 'message': 'Transaction processing failed'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/api/atm/<machine_id>/receipt/print', methods=['POST'])
def print_receipt(machine_id: str):
    try:
        atm_service = ATMService.get_instance(machine_id)
        success = atm_service.print_receipt()
        
        if success:
            return jsonify({'success': True, 'message': 'Receipt printed successfully'})
        else:
            return jsonify({'success': False, 'message': 'Failed to print receipt'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/api/atm/<machine_id>/card/eject', methods=['POST'])
def eject_card(machine_id: str):
    try:
        atm_service = ATMService.get_instance(machine_id)
        success = atm_service.eject_card()
        
        if success:
            return jsonify({'success': True, 'message': 'Card ejected successfully'})
        else:
            return jsonify({'success': False, 'message': 'Failed to eject card'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/api/atm/<machine_id>/transaction/cancel', methods=['POST'])
def cancel_transaction(machine_id: str):
    try:
        atm_service = ATMService.get_instance(machine_id)
        success = atm_service.cancel()
        
        if success:
            return jsonify({'success': True, 'message': 'Operation cancelled successfully'})
        else:
            return jsonify({'success': False, 'message': 'Failed to cancel operation'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/api/atm/create', methods=['POST'])
def create_atm():
    """Create a new ATM and return its machine ID"""
    atm_service = ATMService.get_instance()
    machine_id = atm_service.get_machine_id()
    
    return jsonify({
        'success': True, 
        'message': 'ATM created successfully',
        'machine_id': machine_id
    })

@app.route('/api/atm/<machine_id>', methods=['GET'])
def get_atm_status(machine_id: str):
    """Get the status of an ATM"""
    try:
        atm_service = ATMService.get_instance(machine_id)
        atm = atm_service.atm
        
        return jsonify({
            'success': True,
            'machine_id': atm.machine_id,
            'state': type(atm.current_state).__name__,
            'card_inserted': atm.card_number is not None,
            'hardware_status': atm.hardware_service.check_hardware_status()
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True) 