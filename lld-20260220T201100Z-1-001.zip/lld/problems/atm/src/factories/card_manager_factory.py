from typing import Dict
from ..services.card_service import CardService

class CardManagerFactory:
    """Factory for creating and managing card service instances"""
    
    _instances: Dict[str, CardService] = {}
    
    @classmethod
    def get_card_manager(cls, atm_id: str) -> CardService:
        """
        Get or create a card service instance for a specific ATM
        
        Args:
            atm_id: The unique identifier for the ATM
            
        Returns:
            A CardService instance for the specified ATM
        """
        if atm_id not in cls._instances:
            cls._instances[atm_id] = CardService()
        
        return cls._instances[atm_id]
    
    @classmethod
    def reset_card_manager(cls, atm_id: str) -> None:
        """
        Reset the card service for a specific ATM
        
        Args:
            atm_id: The unique identifier for the ATM
        """
        if atm_id in cls._instances:
            del cls._instances[atm_id] 