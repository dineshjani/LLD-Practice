from typing import Dict, Type
from ..states.atm_state import ATMState
from ..states.idle_state import IdleState
from ..states.card_inserted_state import CardInsertedState
from ..states.pin_entry_state import PinEntryState
from ..states.transaction_selection_state import TransactionSelectionState
from ..states.transaction_state import TransactionState
from ..states.printing_state import PrintingState
from ..states.card_ejection_state import CardEjectionState

class StateManagerFactory:
    """Factory for creating and managing ATM state instances"""
    
    # Map of state names to state classes
    _state_classes = {
        'idle': IdleState,
        'card_inserted': CardInsertedState,
        'pin_entry': PinEntryState,
        'transaction_selection': TransactionSelectionState,
        'transaction': TransactionState,
        'printing': PrintingState,
        'card_ejection': CardEjectionState
    }
    
    @classmethod
    def create_state(cls, state_name: str, atm) -> ATMState:
        """
        Create a new state instance for an ATM
        
        Args:
            state_name: The name of the state to create
            atm: The ATM instance to associate with the state
            
        Returns:
            An instance of the requested ATM state
            
        Raises:
            ValueError: If the state name is not recognized
        """
        if state_name not in cls._state_classes:
            raise ValueError(f"Unknown state: {state_name}")
        
        state_class = cls._state_classes[state_name]
        return state_class(atm)
    
    @classmethod
    def get_initial_state(cls, atm) -> ATMState:
        """
        Get the initial state for a new ATM
        
        Args:
            atm: The ATM instance to associate with the state
            
        Returns:
            An instance of the idle state
        """
        return IdleState(atm)
    
    @classmethod
    def register_state_class(cls, state_name: str, state_class: Type[ATMState]) -> None:
        """
        Register a new state class with the factory
        
        Args:
            state_name: The name to associate with the state class
            state_class: The state class to register
        """
        cls._state_classes[state_name] = state_class 