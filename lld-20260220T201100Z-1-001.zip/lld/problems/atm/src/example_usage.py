def create_atm_with_services():
    auth_service = AuthenticationService()
    card_service = CardService()
    transaction_service = TransactionService()
    printer_service = PrinterService()
    hardware_service = HardwareService()
    
    return ATM(
        authentication_service=auth_service,
        card_service=card_service,
        transaction_service=transaction_service,
        printer_service=printer_service,
        hardware_service=hardware_service
    )

def main():
    atm = create_atm_with_services()
    
    # Now with better error handling and feedback
    if not atm.insert_card("1234-5678-9012-3456"):
        # Authentication service will provide specific error message
        return

    # Multiple PIN attempts with feedback
    max_attempts = 3
    for attempt in range(max_attempts):
        if atm.enter_pin("1234"):
            break
        # Authentication service will handle attempt counting and card blocking
    else:
        print("Maximum PIN attempts exceeded")
        return

    # Continue with transaction... 