stateDiagram-v2
    [*] --> IdleState
    IdleState --> CardInsertedState: insert_card()
    CardInsertedState --> PinEntryState: enter_pin()
    PinEntryState --> TransactionSelectionState: verify_pin()
    TransactionSelectionState --> TransactionState: select_transaction()
    TransactionState --> PrintingState: process_transaction()
    PrintingState --> CardEjectionState: print_receipt()
    CardEjectionState --> IdleState: eject_card() 


#### 1. States

- IdleState
- CardInsertedState
- PinEntryState
- TransactionSelectionState
- TransactionState
- PrintingState
- CardEjectionState

#### 2. Events

- insert_card()
- enter_pin()
- select_transaction()
- process_transaction()
- print_receipt()
- eject_card()

#### 3. Transitions

- IdleState -> CardInsertedState
- CardInsertedState -> PinEntryState
- PinEntryState -> TransactionState
- TransactionState -> PrintingState
- PrintingState -> CardEjectionState
- CardEjectionState -> IdleState        
### design pattern

- State Pattern
Atm is the context and the states are the states of the atm.
- Observer Pattern
- Command Pattern
- Chain of Responsibility Pattern
- Strategy Pattern

- SOLID Principles
- Single Responsibility Principle
- Open/Closed Principle
- Liskov Substitution Principle
- Interface Segregation Principle
- Dependency Inversion Principle

- Design Principles
- Separation of Concerns
- High Cohesion
- Low Coupling
- Single Source of Truth
- YAGNI Principle
- DRY Principle
- KISS Principle
- SOLID Principles
- Single Responsibility Principle
- Open/Closed Principle
- Liskov Substitution Principle
- Interface Segregation Principle
- Dependency Inversion Principle





