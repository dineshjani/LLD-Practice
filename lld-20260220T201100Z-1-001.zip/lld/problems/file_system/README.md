# File System Design

Design a file system similar to ext4 or a distributed file system like HDFS.

## Requirements

### Core Features
- Hierarchical directory structure
- File creation, reading, writing, and deletion
- Metadata management (file size, permissions, timestamps)
- Efficient block allocation and management
- Journaling for crash recovery
- Support for various file types

### Advanced Features
- Distributed operation (for HDFS-like systems)
- Replication for fault tolerance
- Caching for performance
- Quota management
- Snapshots and versioning
- Compression and encryption

### Performance Requirements
- Efficient space utilization
- Fast file operations (read/write/seek)
- Scalability for large files and directories
- Durability against system crashes
- Concurrent access support

### System Design Components
1. **Block Management**
   - Block allocation strategies
   - Free space tracking
   - Block caching
   - I/O scheduling

2. **Inode Management**
   - Inode structure and allocation
   - Directory entry management
   - File metadata storage
   - Inode caching

3. **Journaling System**
   - Transaction logging
   - Checkpoint mechanism
   - Recovery process
   - Journal space management

4. **Directory Structure**
   - Directory entry format
   - Path resolution
   - Directory caching
   - Namespace management

5. **File Operations**
   - Read/write implementations
   - Memory mapping support
   - Concurrent access control
   - Buffer management

## Implementation Guidelines
- Focus on crash consistency and data integrity
- Implement efficient block allocation algorithms
- Design for both small and large file performance
- Consider memory usage and caching strategies
- Implement proper error handling and recovery mechanisms

## Evaluation Criteria
- Correctness of file operations
- Performance under various workloads
- Space efficiency
- Crash recovery capabilities
- Code quality and organization 