# BookMyShow System Design

This document outlines the design of a movie ticket booking system similar to BookMyShow, focusing on SOLID principles and design patterns.

## System Overview

BookMyShow is a comprehensive movie ticket booking platform that allows users to:
- Browse movies and shows
- Select seats
- Make payments
- Receive tickets and notifications

The system is designed with scalability, maintainability, and extensibility in mind.

## SOLID Principles Implementation

### 1. Single Responsibility Principle (SRP)

Each class has a single responsibility:
- `BookingService`: Manages the booking process
- `PaymentService`: Handles payment processing
- `NotificationService`: Manages notifications
- `FareService`: Calculates ticket prices

For example, the `NotificationService` is only responsible for sending notifications and doesn't handle booking or payment logic.

### 2. Open/Closed Principle (OCP)

The system is open for extension but closed for modification:
- `FareStrategy` allows adding new pricing strategies without modifying existing code
- `PaymentGateway` interface enables adding new payment methods
- `NotificationObserver` pattern allows adding new notification channels

For example, adding a new payment gateway like PayPal would only require creating a new class that implements the `PaymentGateway` interface.

### 3. Liskov Substitution Principle (LSP)

Subtypes can be substituted for their base types:
- All `FareStrategy` implementations can be used interchangeably
- All `NotificationObserver` implementations follow the same interface
- All `PaymentGateway` implementations can be substituted

For example, `DefaultFareStrategy` and `PremiumFareStrategy` can both be used wherever a `FareStrategy` is expected.

### 4. Interface Segregation Principle (ISP)

Interfaces are specific to client needs:
- `NotificationObserver` has a focused `update()` method
- `PaymentGateway` has specific methods for payment processing
- `FareStrategy` has a single `calculate_price()` method

For example, the `NotificationObserver` interface only requires implementing a single method, making it easy for clients to implement.

### 5. Dependency Inversion Principle (DIP)

#### Current Implementation

While we've made progress with DIP, there are still areas for improvement:

- `BookingService` depends on concrete implementations of `NotificationService`, `FareService`, and `PaymentService` rather than interfaces
- `PaymentService` depends on the concrete `NotificationService` rather than an interface
- Direct dependencies on Redis for distributed locking

#### Improvement Opportunities

To better follow DIP, we should:

1. Create interfaces for all services:

## Design Patterns

### 1. Strategy Pattern

Used for implementing different algorithms:
- `FareStrategy` with implementations like `DefaultFareStrategy` and `PremiumFareStrategy`
- Allows dynamic selection of pricing algorithms 