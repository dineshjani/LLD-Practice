from abc import ABC, abstractmethod
from typing import List, Dict, Any, Set
import smtplib
import requests
import json
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

from ..models.user import User, NotificationType
from ..models.booking import Booking
from ..models.show import Show
from ..models.ticket import Ticket

# Observer Pattern
class NotificationObserver(ABC):
    @abstractmethod
    def update(self, event_type: str, data: Dict[str, Any]) -> None:
        pass

class EmailNotifier(NotificationObserver):
    def __init__(self, smtp_server="smtp.gmail.com", smtp_port=587, 
                 sender_email="notifications@bookmyshow.com", 
                 sender_password="your_app_password"):
        self.smtp_server = smtp_server
        self.smtp_port = smtp_port
        self.sender_email = sender_email
        self.sender_password = sender_password
    
    def update(self, event_type: str, data: Dict[str, Any]) -> None:
        user = data.get('user')
        if not user or NotificationType.EMAIL not in user.notification_preferences:
            return
            
        subject = data.get('subject', 'Notification from BookMyShow')
        message = data.get('message', '')
        
        try:
            self._send_email(user.email, subject, message)
            print(f"Email sent to {user.email}: {subject}")
        except Exception as e:
            print(f"Failed to send email to {user.email}: {str(e)}")
    
    def _send_email(self, recipient_email: str, subject: str, message: str) -> None:
        """Send an email using SMTP"""
        # Create a multipart message
        msg = MIMEMultipart()
        msg['From'] = self.sender_email
        msg['To'] = recipient_email
        msg['Subject'] = subject
        
        # Add message body
        msg.attach(MIMEText(message, 'plain'))
        
        # Connect to SMTP server and send email
        try:
            server = smtplib.SMTP(self.smtp_server, self.smtp_port)
            server.starttls()  # Secure the connection
            server.login(self.sender_email, self.sender_password)
            server.send_message(msg)
            server.quit()
        except Exception as e:
            print(f"SMTP Error: {str(e)}")
            raise

class SMSNotifier(NotificationObserver):
    def __init__(self, api_key="your_sms_api_key", api_secret="your_sms_api_secret"):
        self.api_key = api_key
        self.api_secret = api_secret
        self.sms_api_url = "https://api.sms-provider.com/send"
    
    def update(self, event_type: str, data: Dict[str, Any]) -> None:
        user = data.get('user')
        if not user or NotificationType.SMS not in user.notification_preferences:
            return
            
        message = data.get('message', '')
        
        try:
            self._send_sms(user.phone, message)
            print(f"SMS sent to {user.phone}")
        except Exception as e:
            print(f"Failed to send SMS to {user.phone}: {str(e)}")
    
    def _send_sms(self, phone_number: str, message: str) -> None:
        """Send SMS using a third-party API"""
        payload = {
            'api_key': self.api_key,
            'api_secret': self.api_secret,
            'to': phone_number,
            'text': message
        }
        
        try:
            response = requests.post(self.sms_api_url, json=payload)
            response.raise_for_status()  # Raise exception for HTTP errors
            
            result = response.json()
            if result.get('status') != 'success':
                raise Exception(f"SMS API error: {result.get('error_message')}")
                
        except requests.exceptions.RequestException as e:
            print(f"SMS API Error: {str(e)}")
            raise

class PushNotifier(NotificationObserver):
    def __init__(self, firebase_api_key="your_firebase_api_key"):
        self.firebase_api_key = firebase_api_key
        self.fcm_url = "https://fcm.googleapis.com/fcm/send"
    
    def update(self, event_type: str, data: Dict[str, Any]) -> None:
        user = data.get('user')
        if not user or NotificationType.PUSH not in user.notification_preferences:
            return
            
        title = data.get('subject', 'Notification')
        message = data.get('message', '')
        
        # In a real system, we would retrieve the user's device tokens from a database
        device_tokens = self._get_user_device_tokens(user.user_id)
        
        if not device_tokens:
            print(f"No device tokens found for user {user.user_id}")
            return
            
        try:
            self._send_push_notification(device_tokens, title, message)
            print(f"Push notification sent to user {user.user_id}")
        except Exception as e:
            print(f"Failed to send push notification to user {user.user_id}: {str(e)}")
    
    def _get_user_device_tokens(self, user_id: str) -> List[str]:
        """Get the user's device tokens from database"""
        # In a real system, this would query a database
        # For this example, we'll return a dummy token
        return [f"device_token_{user_id}"]
    
    def _send_push_notification(self, device_tokens: List[str], title: str, message: str) -> None:
        """Send push notification using Firebase Cloud Messaging"""
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'key={self.firebase_api_key}'
        }
        
        payload = {
            'registration_ids': device_tokens,
            'notification': {
                'title': title,
                'body': message,
                'sound': 'default'
            }
        }
        
        try:
            response = requests.post(self.fcm_url, headers=headers, data=json.dumps(payload))
            response.raise_for_status()  # Raise exception for HTTP errors
            
            result = response.json()
            if result.get('failure') > 0:
                print(f"Some push notifications failed: {result}")
                
        except requests.exceptions.RequestException as e:
            print(f"FCM Error: {str(e)}")
            raise

class WhatsAppNotifier(NotificationObserver):
    def __init__(self, twilio_account_sid="your_twilio_sid", 
                 twilio_auth_token="your_twilio_token",
                 twilio_whatsapp_number="your_twilio_whatsapp_number"):
        self.twilio_account_sid = twilio_account_sid
        self.twilio_auth_token = twilio_auth_token
        self.twilio_whatsapp_number = twilio_whatsapp_number
        self.twilio_api_url = f"https://api.twilio.com/2010-04-01/Accounts/{twilio_account_sid}/Messages.json"
    
    def update(self, event_type: str, data: Dict[str, Any]) -> None:
        user = data.get('user')
        if not user or NotificationType.WHATSAPP not in user.notification_preferences:
            return
            
        message = data.get('message', '')
        
        try:
            self._send_whatsapp(user.phone, message)
            print(f"WhatsApp message sent to {user.phone}")
        except Exception as e:
            print(f"Failed to send WhatsApp message to {user.phone}: {str(e)}")
    
    def _send_whatsapp(self, phone_number: str, message: str) -> None:
        """Send WhatsApp message using Twilio"""
        # Format phone number for WhatsApp (add whatsapp: prefix)
        whatsapp_to = f"whatsapp:{phone_number}"
        whatsapp_from = f"whatsapp:{self.twilio_whatsapp_number}"
        
        payload = {
            'From': whatsapp_from,
            'To': whatsapp_to,
            'Body': message
        }
        
        try:
            response = requests.post(
                self.twilio_api_url, 
                data=payload,
                auth=(self.twilio_account_sid, self.twilio_auth_token)
            )
            response.raise_for_status()  # Raise exception for HTTP errors
            
            result = response.json()
            if result.get('error_code'):
                raise Exception(f"Twilio API error: {result.get('error_message')}")
                
        except requests.exceptions.RequestException as e:
            print(f"Twilio API Error: {str(e)}")
            raise

class NotificationService:
    def __init__(self):
        self.observers: Dict[str, Set[NotificationObserver]] = {}
        
        # Register default observers
        self.register_observer("all", EmailNotifier())
        self.register_observer("all", SMSNotifier())
        self.register_observer("all", PushNotifier())
        self.register_observer("all", WhatsAppNotifier())
    
    def register_observer(self, event_type: str, observer: NotificationObserver) -> None:
        """Register an observer for a specific event type"""
        if event_type not in self.observers:
            self.observers[event_type] = set()
        self.observers[event_type].add(observer)
    
    def remove_observer(self, event_type: str, observer: NotificationObserver) -> None:
        """Remove an observer from a specific event type"""
        if event_type in self.observers:
            self.observers[event_type].discard(observer)
    
    def notify(self, event_type: str, data: Dict[str, Any]) -> None:
        """Notify all observers registered for the event type"""
        # Notify specific event observers
        if event_type in self.observers:
            for observer in self.observers[event_type]:
                observer.update(event_type, data)
                
        # Notify "all" event observers
        if "all" in self.observers and event_type != "all":
            for observer in self.observers["all"]:
                observer.update(event_type, data)
    
    def send_booking_confirmation(self, user: User, booking: Booking) -> None:
        """Send booking confirmation notification to the user"""
        message = f"Booking confirmed! Your booking ID is {booking.booking_id}. "
        message += f"Movie: {booking.show.movie.title}, Time: {booking.show.start_time}, "
        message += f"Seats: {', '.join(seat.seat_id for seat in booking.seats)}"
        
        data = {
            "user": user,
            "subject": "Booking Confirmation",
            "message": message,
            "booking": booking
        }
        
        self.notify("booking_confirmation", data)
    
    def send_booking_cancellation(self, user: User, booking: Booking) -> None:
        """Send booking cancellation notification to the user"""
        message = f"Your booking {booking.booking_id} has been cancelled. "
        message += f"Movie: {booking.show.movie.title}, Time: {booking.show.start_time}"
        
        data = {
            "user": user,
            "subject": "Booking Cancelled",
            "message": message,
            "booking": booking
        }
        
        self.notify("booking_cancellation", data)
    
    def send_booking_failure(self, user: User, show: Show, seat_ids: List[str], reason: str) -> None:
        """Send booking failure notification to the user"""
        message = f"Your booking for {show.movie.title} at {show.start_time} could not be completed. "
        message += f"Reason: {reason}"
        
        data = {
            "user": user,
            "subject": "Booking Failed",
            "message": message,
            "show": show,
            "seat_ids": seat_ids,
            "reason": reason
        }
        
        self.notify("booking_failure", data)
    
    def send_show_cancellation(self, show: Show, affected_users: List[User]) -> None:
        """Send show cancellation notification to all affected users"""
        message = f"Show cancelled: {show.movie.title} at {show.screen.cinema.name}, {show.start_time}. "
        message += "You will receive a refund for your booking."
        
        for user in affected_users:
            data = {
                "user": user,
                "subject": "Show Cancelled",
                "message": message,
                "show": show
            }
            
            self.notify("show_cancellation", data)
    
    def send_ticket_generated(self, user: User, ticket: Ticket) -> None:
        """Send ticket generation notification with QR code"""
        message = f"Your ticket for {ticket.show.movie.title} is ready! "
        message += f"Seat: {ticket.seat.seat_id}, Time: {ticket.show.start_time}, "
        message += f"Cinema: {ticket.show.screen.cinema.name}\n"
        message += f"QR Code: {ticket.qr_code}"
        
        data = {
            "user": user,
            "subject": "Your Ticket is Ready",
            "message": message,
            "ticket": ticket
        }
        
        self.notify("ticket_generated", data)
    
    def send_payment_confirmation(self, user: User, booking: Booking, amount: float, 
                                 payment_method: str) -> None:
        """Send payment confirmation notification"""
        message = f"Payment of ${amount:.2f} received for booking {booking.booking_id}. "
        message += f"Payment method: {payment_method}. "
        message += f"Movie: {booking.show.movie.title}, Time: {booking.show.start_time}"
        
        data = {
            "user": user,
            "subject": "Payment Confirmation",
            "message": message,
            "booking": booking,
            "amount": amount,
            "payment_method": payment_method
        }
        
        self.notify("payment_confirmation", data)
    
    def send_refund_notification(self, user: User, booking: Booking, amount: float) -> None:
        """Send refund notification"""
        message = f"Refund of ${amount:.2f} processed for booking {booking.booking_id}. "
        message += f"Movie: {booking.show.movie.title}, Time: {booking.show.start_time}"
        
        data = {
            "user": user,
            "subject": "Refund Processed",
            "message": message,
            "booking": booking,
            "amount": amount
        }
        
        self.notify("refund_processed", data) 