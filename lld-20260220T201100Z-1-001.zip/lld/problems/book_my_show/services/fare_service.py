from abc import ABC, abstractmethod
from typing import Dict

class FareStrategy(ABC):
    @abstractmethod
    def calculate_price(self, base_price: float, seat_type: str) -> float:
        pass

class DefaultFareStrategy(FareStrategy):
    def calculate_price(self, base_price: float, seat_type: str) -> float:
        multipliers = {
            "PREMIUM": 1.5,
            "STANDARD": 1.0,
            "BUDGET": 0.8
        }
        return base_price * multipliers.get(seat_type, 1.0)

class PremiumFareStrategy(FareStrategy):
    def calculate_price(self, base_price: float, seat_type: str) -> float:
        # Premium strategy adds extra features and higher prices
        multipliers = {
            "PREMIUM": 2.0,
            "STANDARD": 1.3,
            "BUDGET": 1.0
        }
        return base_price * multipliers.get(seat_type, 1.3)

class FareService:
    def __init__(self):
        self.strategies: Dict[str, FareStrategy] = {
            "DEFAULT": DefaultFareStrategy(),
            "PREMIUM": PremiumFareStrategy()
        }
        self.current_strategy = "DEFAULT"
    
    def set_strategy(self, strategy_name: str) -> bool:
        """Set the fare calculation strategy"""
        if strategy_name in self.strategies:
            self.current_strategy = strategy_name
            return True
        return False
    
    def add_strategy(self, name: str, strategy: FareStrategy) -> None:
        """Add a new fare calculation strategy"""
        self.strategies[name] = strategy
    
    def calculate_fare(self, base_price: float, seat_type: str) -> float:
        """Calculate fare based on the current strategy"""
        strategy = self.strategies[self.current_strategy]
        return strategy.calculate_price(base_price, seat_type) 