from typing import List, Dict, Optional, Tuple
from datetime import datetime
import uuid
import threading
import redis
from enum import Enum

from ..models.booking import Booking
from ..models.user import User
from ..models.show import Show
from ..models.seat import Seat, SeatStatus
from ..models.ticket import Ticket
from ..models.payment import Payment, PaymentMethod, PaymentStatus
from ..services.notification_service import NotificationService
from ..services.fare_service import FareService
from ..services.payment_service import PaymentService

class BookingStatus(Enum):
    PENDING_PAYMENT = "pending_payment"
    CONFIRMED = "confirmed"
    CANCELLED = "cancelled"
    EXPIRED = "expired"

class BookingService:
    def __init__(self, notification_service: NotificationService, 
                fare_service: FareService, 
                payment_service: PaymentService,
                redis_client=None):
        self.bookings: Dict[str, Booking] = {}
        self.tickets: Dict[str, List[Ticket]] = {}  # booking_id -> list of tickets
        self.lock = threading.Lock()
        self.notification_service = notification_service
        self.fare_service = fare_service
        self.payment_service = payment_service
        
        # Redis client for distributed locking
        self.redis_client = redis_client or redis.Redis(host='localhost', port=6379, db=0)
        
        # Track seat locks: show_id:seat_id -> (booking_id, lock_id, expiry_time)
        self.seat_locks: Dict[str, Tuple[str, str, datetime]] = {}
    
    def create_booking(self, user: User, show: Show, seat_ids: List[str], 
                      fare_strategy: str = "DEFAULT") -> Tuple[Optional[Booking], str]:
        """Create a booking (without payment)"""
        # Set fare strategy
        self.fare_service.set_strategy(fare_strategy)
        
        # Generate a unique lock ID for this booking attempt
        lock_id = str(uuid.uuid4())
        booking_id = f"BOOKING_{str(uuid.uuid4())[:8]}"
        
        # Try to acquire distributed locks for all seats
        locked_seats = []
        try:
            for seat_id in seat_ids:
                # Use Redis SETNX for distributed locking with 10-minute expiry (payment window)
                lock_key = f"lock:show:{show.show_id}:seat:{seat_id}"
                if not self.redis_client.set(lock_key, lock_id, nx=True, ex=600):
                    # If any seat is already locked, release all acquired locks
                    for locked_seat_id in locked_seats:
                        self.redis_client.delete(f"lock:show:{show.show_id}:seat:{locked_seat_id}")
                    return None, "Some seats are not available"
                locked_seats.append(seat_id)
                
                # Track the lock in our application
                with self.lock:
                    self.seat_locks[f"{show.show_id}:{seat_id}"] = (
                        booking_id, 
                        lock_id, 
                        datetime.now() + datetime.timedelta(minutes=10)
                    )
            
            # Now check if seats are available
            seats_to_book = []
            with self.lock:  # Local lock for thread safety within this instance
                for seat_id in seat_ids:
                    seat = show.get_seat(seat_id)
                    if not seat or seat.status != SeatStatus.AVAILABLE:
                        # Don't release Redis locks here - we'll handle that in the exception block
                        return None, "Some seats are not available"
                    seats_to_book.append(seat)
            
            # Calculate prices using the fare service
            total_price = 0
            seat_prices = {}
            for seat in seats_to_book:
                seat_price = self.fare_service.calculate_fare(
                    show.base_price, seat.seat_type.name)
                seat_prices[seat.seat_id] = seat_price
                total_price += seat_price
            
            # Create booking
            booking = Booking(booking_id, user, show, seats_to_book)
            booking.total_amount = total_price
            booking.status = BookingStatus.PENDING_PAYMENT
            
            # Mark seats as locked in the application
            with self.lock:
                for seat in seats_to_book:
                    seat.lock_seat()
                
                self.bookings[booking_id] = booking
            
            # Note: We DO NOT release the Redis locks here because we need to keep the seats
            # locked until payment is completed or the booking expires
            
            return booking, "Booking created, payment required"
            
        except Exception as e:
            # Release Redis locks in case of exception
            for seat_id in locked_seats:
                lock_key = f"lock:show:{show.show_id}:seat:{seat_id}"
                # Only delete if it's our lock
                self.redis_client.eval(
                    """
                    if redis.call('get', KEYS[1]) == ARGV[1] then
                        return redis.call('del', KEYS[1])
                    else
                        return 0
                    end
                    """,
                    1, lock_key, lock_id
                )
                
                # Remove from our tracking
                with self.lock:
                    self.seat_locks.pop(f"{show.show_id}:{seat_id}", None)
            
            # Send failure notification
            self.notification_service.send_booking_failure(user, show, seat_ids, str(e))
            
            return None, str(e)
    
    def confirm_booking(self, booking_id: str, payment_method: PaymentMethod,
                       card_number: str = None, expiry: str = None, cvv: str = None,
                       upi_id: str = None, bank_account: str = None) -> Tuple[bool, str]:
        """Confirm a booking by processing payment"""
        with self.lock:
            booking = self.bookings.get(booking_id)
            if not booking:
                return False, "Booking not found"
            
            if booking.status != BookingStatus.PENDING_PAYMENT:
                return False, f"Booking is in {booking.status.value} state"
            
            # Process payment
            payment = self.payment_service.process_payment(
                booking=booking,
                payment_method=payment_method,
                card_number=card_number,
                expiry=expiry,
                cvv=cvv,
                upi_id=upi_id,
                bank_account=bank_account
            )
            
            if not payment or payment.status != PaymentStatus.COMPLETED:
                # Payment failed, release seats and Redis locks
                for seat in booking.seats:
                    seat.unlock_seat()
                    
                    # Release Redis lock
                    lock_key = f"lock:show:{booking.show.show_id}:seat:{seat.seat_id}"
                    self.redis_client.delete(lock_key)
                    
                    # Remove from our tracking
                    self.seat_locks.pop(f"{booking.show.show_id}:{seat.seat_id}", None)
                
                booking.status = BookingStatus.EXPIRED
                return False, "Payment failed"
            
            # Payment successful, confirm booking
            booking.status = BookingStatus.CONFIRMED
            
            # Confirm seats
            for seat in booking.seats:
                seat.book_seat(booking.user)
                
                # Release Redis lock (no longer needed as seat is now booked)
                lock_key = f"lock:show:{booking.show.show_id}:seat:{seat.seat_id}"
                self.redis_client.delete(lock_key)
                
                # Remove from our tracking
                self.seat_locks.pop(f"{booking.show.show_id}:{seat.seat_id}", None)
            
            # Generate tickets
            tickets = []
            for seat in booking.seats:
                ticket_id = f"TICKET_{str(uuid.uuid4())[:8]}"
                ticket = Ticket(
                    ticket_id=ticket_id,
                    booking_id=booking_id,
                    user=booking.user,
                    show=booking.show,
                    seat=seat,
                    price=seat.price
                )
                ticket.generate_qr_code()
                tickets.append(ticket)
                
                # Send ticket notification for each ticket
                self.notification_service.send_ticket_generated(booking.user, ticket)
            
            self.tickets[booking_id] = tickets
            
            # Send booking confirmation notification
            self.notification_service.send_booking_confirmation(booking.user, booking)
            
            return True, "Booking confirmed"
    
    def cancel_booking(self, booking_id: str) -> Tuple[bool, str]:
        with self.lock:
            booking = self.bookings.get(booking_id)
            if not booking:
                return False, "Booking not found"
            
            if booking.status == BookingStatus.PENDING_PAYMENT:
                # For pending bookings, just release the locks
                for seat in booking.seats:
                    seat.unlock_seat()
                    
                    # Release Redis lock
                    lock_key = f"lock:show:{booking.show.show_id}:seat:{seat.seat_id}"
                    self.redis_client.delete(lock_key)
                    
                    # Remove from our tracking
                    self.seat_locks.pop(f"{booking.show.show_id}:{seat.seat_id}", None)
                
                booking.status = BookingStatus.CANCELLED
                return True, "Booking cancelled"
            
            elif booking.status != BookingStatus.CONFIRMED:
                return False, f"Cannot cancel booking in {booking.status.value} state"
            
            # Release seats
            for seat in booking.seats:
                seat.cancel_booking()
            
            booking.status = BookingStatus.CANCELLED
            
            # Get the payment for this booking
            payments = self.payment_service.get_payments_for_booking(booking_id)
            if payments:
                # Process refund for the first completed payment
                for payment in payments:
                    if payment.status == PaymentStatus.COMPLETED:
                        self.payment_service.process_refund(payment.payment_id)
                        break
            
            # Remove tickets
            if booking_id in self.tickets:
                del self.tickets[booking_id]
            
            # Send cancellation notification
            self.notification_service.send_booking_cancellation(booking.user, booking)
            
            return True, "Booking cancelled"
    
    def get_booking(self, booking_id: str) -> Optional[Booking]:
        with self.lock:
            return self.bookings.get(booking_id)
    
    def get_tickets(self, booking_id: str) -> List[Ticket]:
        with self.lock:
            return self.tickets.get(booking_id, [])
    
    def cleanup_expired_bookings(self) -> None:
        """Clean up expired bookings (pending payment)"""
        current_time = datetime.now()
        
        with self.lock:
            expired_booking_ids = []
            
            # Check for expired seat locks
            expired_locks = []
            for lock_key, (booking_id, lock_id, expiry_time) in self.seat_locks.items():
                if current_time > expiry_time:
                    expired_locks.append((lock_key, booking_id))
            
            # Group by booking_id
            booking_to_locks = {}
            for lock_key, booking_id in expired_locks:
                if booking_id not in booking_to_locks:
                    booking_to_locks[booking_id] = []
                booking_to_locks[booking_id].append(lock_key)
            
            # Process each expired booking
            for booking_id, lock_keys in booking_to_locks.items():
                booking = self.bookings.get(booking_id)
                if booking and booking.status == BookingStatus.PENDING_PAYMENT:
                    # Release seats
                    for seat in booking.seats:
                        seat.unlock_seat()
                        
                        # Release Redis lock
                        redis_key = f"lock:show:{booking.show.show_id}:seat:{seat.seat_id}"
                        self.redis_client.delete(redis_key)
                    
                    # Update booking status
                    booking.status = BookingStatus.EXPIRED
                    
                    # Send expiration notification
                    self.notification_service.send_booking_expired(booking.user, booking)
                
                # Remove from tracking
                for lock_key in lock_keys:
                    self.seat_locks.pop(lock_key, None) 