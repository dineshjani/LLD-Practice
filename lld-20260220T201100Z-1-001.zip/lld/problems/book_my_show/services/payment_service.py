from typing import Dict, Optional
import uuid
import threading
from datetime import datetime
import requests
import json

from ..models.payment import Payment, PaymentStatus, PaymentMethod
from ..models.booking import Booking
from ..models.user import User
from ..services.notification_service import NotificationService

class PaymentGateway:
    """Interface for payment gateway integration"""
    def process_payment(self, amount: float, payment_method: PaymentMethod, 
                       card_number: str = None, expiry: str = None, cvv: str = None,
                       upi_id: str = None, bank_account: str = None) -> Dict:
        """Process a payment through the payment gateway"""
        pass
    
    def process_refund(self, transaction_id: str, amount: float) -> Dict:
        """Process a refund through the payment gateway"""
        pass

class StripePaymentGateway(PaymentGateway):
    """Stripe payment gateway implementation"""
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.api_url = "https://api.stripe.com/v1"
    
    def process_payment(self, amount: float, payment_method: PaymentMethod, 
                       card_number: str = None, expiry: str = None, cvv: str = None,
                       upi_id: str = None, bank_account: str = None) -> Dict:
        """Process a payment through Stripe"""
        # In a real implementation, this would use the Stripe API
        # For this example, we'll simulate a successful payment
        
        # Validate required fields based on payment method
        if payment_method == PaymentMethod.CREDIT_CARD or payment_method == PaymentMethod.DEBIT_CARD:
            if not card_number or not expiry or not cvv:
                return {
                    "success": False,
                    "error": "Card details required for card payment"
                }
        elif payment_method == PaymentMethod.UPI:
            if not upi_id:
                return {
                    "success": False,
                    "error": "UPI ID required for UPI payment"
                }
        elif payment_method == PaymentMethod.NET_BANKING:
            if not bank_account:
                return {
                    "success": False,
                    "error": "Bank account details required for net banking"
                }
        
        # Simulate API call
        print(f"Processing {amount} payment via {payment_method.value} through Stripe")
        
        # Generate a transaction ID
        transaction_id = f"txn_{str(uuid.uuid4())[:8]}"
        
        return {
            "success": True,
            "transaction_id": transaction_id,
            "amount": amount,
            "payment_method": payment_method.value,
            "timestamp": datetime.now().isoformat()
        }
    
    def process_refund(self, transaction_id: str, amount: float) -> Dict:
        """Process a refund through Stripe"""
        # In a real implementation, this would use the Stripe API
        # For this example, we'll simulate a successful refund
        
        print(f"Processing {amount} refund for transaction {transaction_id} through Stripe")
        
        return {
            "success": True,
            "refund_id": f"ref_{str(uuid.uuid4())[:8]}",
            "transaction_id": transaction_id,
            "amount": amount,
            "timestamp": datetime.now().isoformat()
        }

class PaymentService:
    def __init__(self, notification_service: NotificationService, payment_gateway: PaymentGateway = None):
        self.payments: Dict[str, Payment] = {}
        self.notification_service = notification_service
        self.lock = threading.Lock()
        
        # Default to Stripe payment gateway if none provided
        self.payment_gateway = payment_gateway or StripePaymentGateway(api_key="your_stripe_api_key")
    
    def process_payment(self, booking: Booking, payment_method: PaymentMethod, 
                       card_number: str = None, expiry: str = None, cvv: str = None,
                       upi_id: str = None, bank_account: str = None) -> Optional[Payment]:
        """Process payment for a booking"""
        # Create a new payment record
        payment_id = f"PAY_{str(uuid.uuid4())[:8]}"
        payment = Payment(
            payment_id=payment_id,
            booking_id=booking.booking_id,
            amount=booking.total_amount,
            payment_method=payment_method
        )
        
        # Process payment through payment gateway
        result = self.payment_gateway.process_payment(
            amount=booking.total_amount,
            payment_method=payment_method,
            card_number=card_number,
            expiry=expiry,
            cvv=cvv,
            upi_id=upi_id,
            bank_account=bank_account
        )
        
        if result["success"]:
            # Update payment record
            payment.complete(result["transaction_id"])
            
            # Store payment
            with self.lock:
                self.payments[payment_id] = payment
            
            # Send payment confirmation notification
            self.notification_service.send_payment_confirmation(
                booking.user, booking, payment.amount, payment_method.value)
            
            return payment
        else:
            # Payment failed
            payment.fail()
            
            # Store failed payment
            with self.lock:
                self.payments[payment_id] = payment
            
            # Send payment failure notification
            self.notification_service.send_payment_failure(
                booking.user, booking, payment.amount, payment_method.value, result.get("error", "Unknown error"))
            
            return None
    
    def process_refund(self, payment_id: str, amount: float = None) -> bool:
        """Process refund for a payment"""
        with self.lock:
            payment = self.payments.get(payment_id)
            if not payment:
                return False
            
            # If amount not specified, refund full amount
            refund_amount = amount if amount is not None else payment.amount
            
            # Can't refund more than original payment
            if refund_amount > payment.amount:
                return False
            
            # Can only refund completed payments
            if payment.status != PaymentStatus.COMPLETED:
                return False
            
            # Process refund through payment gateway
            result = self.payment_gateway.process_refund(
                transaction_id=payment.transaction_id,
                amount=refund_amount
            )
            
            if result["success"]:
                # Update payment record
                payment.refund(refund_amount)
                
                # Get booking and user for notification
                # In a real system, we would look up the booking from a repository
                # For this example, we'll assume we have access to the booking
                booking = self._get_booking_by_id(payment.booking_id)
                if booking:
                    # Send refund notification
                    self.notification_service.send_refund_notification(
                        booking.user, booking, refund_amount)
                
                return True
            else:
                return False
    
    def get_payment(self, payment_id: str) -> Optional[Payment]:
        """Get payment details"""
        with self.lock:
            return self.payments.get(payment_id)
    
    def get_payments_for_booking(self, booking_id: str) -> List[Payment]:
        """Get all payments for a booking"""
        with self.lock:
            return [p for p in self.payments.values() if p.booking_id == booking_id]
    
    def _get_booking_by_id(self, booking_id: str) -> Optional[Booking]:
        """Get booking by ID - in a real system, this would use a repository"""
        # This is a placeholder - in a real system, we would look up the booking
        # from a booking repository
        return None 