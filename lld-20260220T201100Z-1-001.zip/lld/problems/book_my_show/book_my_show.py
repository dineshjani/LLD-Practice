from typing import List, Dict, Optional, Tuple
from datetime import datetime
import uuid

from .models.user import User, UserRole, NotificationType
from .models.cinema import Cinema, Screen
from .models.movie import Movie
from .models.show import Show
from .models.seat import Seat, SeatStatus, SeatType
from .models.booking import Booking
from .models.ticket import Ticket
from .models.payment import PaymentMethod
from .services.booking_service import BookingService
from .services.notification_service import NotificationService, EmailNotifier, SMSNotifier, PushNotifier
from .services.fare_service import FareService
from .services.notification_service import NotificationObserver
from .services.payment_service import PaymentService, StripePaymentGateway

class BookMyShow:
    def __init__(self):
        self.cinemas: List[Cinema] = []
        self.notification_service = NotificationService()
        self.fare_service = FareService()
        self.payment_service = PaymentService(self.notification_service)
        self.booking_service = BookingService(
            self.notification_service, 
            self.fare_service,
            self.payment_service
        )
    
    def add_cinema(self, cinema: Cinema):
        self.cinemas.append(cinema)
    
    def search_shows(self, movie_name: str = None, location: str = None, date: datetime = None) -> List[Show]:
        available_shows = []
        for cinema in self.cinemas:
            # Filter by location if provided
            if location and cinema.address.city != location:
                continue
                
            for screen in cinema.screens:
                for show in screen.shows:
                    # Filter by movie name if provided
                    if movie_name and show.movie.title != movie_name:
                        continue
                        
                    # Filter by date if provided
                    if date and show.start_time.date() != date.date():
                        continue
                        
                    available_shows.append(show)
        return available_shows
    
    def create_booking(self, user: User, show: Show, seat_ids: List[str], 
                      use_premium: bool = False) -> Tuple[Optional[Booking], str]:
        """Create a booking (without payment)"""
        # Choose fare strategy based on user preference
        fare_strategy = "PREMIUM" if use_premium else "DEFAULT"
            
        # Delegate to booking service
        return self.booking_service.create_booking(user, show, seat_ids, fare_strategy)
    
    def confirm_booking(self, booking_id: str, payment_method: str,
                       payment_details: Dict) -> Tuple[bool, str]:
        """Confirm a booking by processing payment"""
        # Convert string payment method to enum
        try:
            payment_method_enum = PaymentMethod(payment_method)
        except ValueError:
            return False, f"Invalid payment method: {payment_method}"
        
        # Extract payment details based on method
        card_number = payment_details.get('card_number')
        expiry = payment_details.get('expiry')
        cvv = payment_details.get('cvv')
        upi_id = payment_details.get('upi_id')
        bank_account = payment_details.get('bank_account')
        
        # Delegate to booking service
        return self.booking_service.confirm_booking(
            booking_id, 
            payment_method_enum,
            card_number,
            expiry,
            cvv,
            upi_id,
            bank_account
        )
    
    def cancel_booking(self, booking_id: str) -> Tuple[bool, str]:
        """Cancel a booking"""
        return self.booking_service.cancel_booking(booking_id)
    
    def get_booking(self, booking_id: str) -> Optional[Booking]:
        """Get booking details"""
        return self.booking_service.get_booking(booking_id)
    
    def get_tickets(self, booking_id: str) -> List[Ticket]:
        """Get tickets for a booking"""
        return self.booking_service.get_tickets(booking_id)
    
    def register_user(self, name: str, email: str, phone: str, password: str) -> User:
        """Register a new user"""
        user_id = f"USER_{str(uuid.uuid4())[:8]}"
        # In a real system, password would be hashed
        user = User(user_id, name, email, phone, password)
        user.add_role(UserRole.CUSTOMER)
        user.add_notification_preference(NotificationType.EMAIL)
        
        # In a real system, this would save to a database
        return user
    
    def add_notification_observer(self, event_type: str, observer: NotificationObserver) -> None:
        """Add a custom notification observer"""
        self.notification_service.register_observer(event_type, observer) 