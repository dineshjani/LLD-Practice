from typing import List
from datetime import datetime
from .user import User
from .show import Show
from .seat import Seat

class Booking:
    def __init__(self, booking_id: str, user: User, show: Show, seats: List[Seat]):
        self.booking_id = booking_id
        self.user = user
        self.show = show
        self.seats = seats
        self.status = "CONFIRMED"
        self.total_amount = sum(seat.price for seat in seats)
        self.booking_time = datetime.now()
    
    def cancel(self) -> bool:
        if self.status != "CONFIRMED":
            return False
        
        # Release all seats
        for seat in self.seats:
            seat.cancel_booking()
        
        self.status = "CANCELLED"
        return True 