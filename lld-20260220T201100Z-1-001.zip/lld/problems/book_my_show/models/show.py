from typing import List, Dict, Optional
from datetime import datetime
from .seat import Seat, SeatStatus, SeatType
from .user import User
from .cinema import Screen
from .movie import Movie

class Show:
    def __init__(self, show_id: str, movie: Movie, screen: Screen, start_time: datetime):
        self.show_id = show_id
        self.movie = movie
        self.screen = screen
        self.start_time = start_time
        self.seats: Dict[str, Seat] = {}
    
    def add_seat(self, seat: Seat):
        self.seats[seat.seat_id] = seat
    
    def get_available_seats(self) -> List[Seat]:
        return [seat for seat in self.seats.values() 
                if seat.status == SeatStatus.AVAILABLE]
    
    def get_seat(self, seat_id: str) -> Optional[Seat]:
        return self.seats.get(seat_id) 