from enum import Enum
from dataclasses import dataclass
from .user import User

class SeatStatus(Enum):
    AVAILABLE = "available"
    BOOKED = "booked"
    LOCKED = "locked"

class SeatType(Enum):
    PREMIUM = "premium"
    STANDARD = "standard"
    BUDGET = "budget"

@dataclass
class Seat:
    seat_id: str
    seat_type: SeatType
    price: float
    status: SeatStatus = SeatStatus.AVAILABLE
    booked_by: 'User' = None
    
    def book_seat(self, user: 'User') -> bool:
        if self.status != SeatStatus.AVAILABLE:
            return False
        self.status = SeatStatus.BOOKED
        self.booked_by = user
        return True
    
    def cancel_booking(self) -> bool:
        if self.status != SeatStatus.BOOKED:
            return False
        self.status = SeatStatus.AVAILABLE
        self.booked_by = None
        return True
    
    def lock_seat(self) -> bool:
        if self.status != SeatStatus.AVAILABLE:
            return False
        self.status = SeatStatus.LOCKED
        return True
    
    def unlock_seat(self) -> bool:
        if self.status != SeatStatus.LOCKED:
            return False
        self.status = SeatStatus.AVAILABLE
        return True 