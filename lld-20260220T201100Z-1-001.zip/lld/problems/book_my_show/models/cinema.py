from typing import List, Dict
from dataclasses import dataclass

@dataclass
class Address:
    street: str
    city: str
    state: str
    country: str
    postal_code: str

class Screen:
    def __init__(self, screen_id: str, name: str):
        self.screen_id = screen_id
        self.name = name
        self.shows: List['Show'] = []
        
    def add_show(self, show: 'Show'):
        self.shows.append(show)

class Cinema:
    def __init__(self, cinema_id: str, name: str, address: Address):
        self.cinema_id = cinema_id
        self.name = name
        self.address = address
        self.screens: List[Screen] = []
        
    def add_screen(self, screen: Screen) -> None:
        self.screens.append(screen)
        
    def get_screen(self, screen_id: str) -> Screen:
        for screen in self.screens:
            if screen.screen_id == screen_id:
                return screen
        return None 