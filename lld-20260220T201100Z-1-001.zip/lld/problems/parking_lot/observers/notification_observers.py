from typing import Dict, Any, List
from service.notification_service import Observer, NotificationType
import logging
from datetime import datetime

class LoggingObserver(Observer):
    """Observer that logs all notifications to a file or console"""
    
    def __init__(self, log_file: str = None):
        # Configure logging
        if log_file:
            logging.basicConfig(
                filename=log_file,
                level=logging.INFO,
                format='%(asctime)s - %(levelname)s - %(message)s'
            )
        else:
            logging.basicConfig(
                level=logging.INFO,
                format='%(asctime)s - %(levelname)s - %(message)s'
            )
    
    def update(self, notification_type: NotificationType, data: Dict[str, Any]) -> None:
        """Log the notification"""
        logging.info(f"Notification: {notification_type.value}")
        for key, value in data.items():
            logging.info(f"  {key}: {value}")

class DisplayObserver(Observer):
    """Observer that displays notifications on a dashboard or console"""
    
    def update(self, notification_type: NotificationType, data: Dict[str, Any]) -> None:
        """Display the notification"""
        print(f"\n=== {notification_type.value} NOTIFICATION ===")
        print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        for key, value in data.items():
            print(f"{key}: {value}")
        print("=" * 40)

class EmailNotificationObserver(Observer):
    """Observer that sends email notifications"""
    
    def __init__(self, admin_email: str):
        self.admin_email = admin_email
        # In a real system, this would configure an email client
    
    def update(self, notification_type: NotificationType, data: Dict[str, Any]) -> None:
        """Send an email notification"""
        # In a real system, this would send an actual email
        print(f"\n[EMAIL NOTIFICATION to {self.admin_email}]")
        print(f"Subject: Parking Lot Alert - {notification_type.value}")
        print("Body:")
        print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        for key, value in data.items():
            print(f"{key}: {value}")
        print("[END EMAIL]")

class SMSNotificationObserver(Observer):
    """Observer that sends SMS notifications"""
    
    def __init__(self, phone_numbers: List[str]):
        self.phone_numbers = phone_numbers
        # In a real system, this would configure an SMS gateway
    
    def update(self, notification_type: NotificationType, data: Dict[str, Any]) -> None:
        """Send an SMS notification"""
        # In a real system, this would send an actual SMS
        for phone in self.phone_numbers:
            print(f"\n[SMS NOTIFICATION to {phone}]")
            print(f"Parking Alert: {notification_type.value}")
            
            # Create a concise message based on notification type
            if notification_type == NotificationType.PARKING_FULL:
                print("Parking lot is now full!")
            elif notification_type == NotificationType.SYSTEM_ALERT:
                print(f"System Alert: {data.get('message', 'Unknown alert')}")
            elif notification_type == NotificationType.GATE_STATUS_CHANGE:
                print(f"Gate {data.get('gate_name', 'Unknown')} status changed to {data.get('status', 'Unknown')}")
            else:
                # Generic message for other notification types
                print(f"Event occurred at {datetime.now().strftime('%H:%M:%S')}")
            
            print("[END SMS]") 