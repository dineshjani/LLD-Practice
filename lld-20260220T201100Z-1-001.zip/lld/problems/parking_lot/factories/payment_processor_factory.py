from typing import Dict, Type
from models.enum import PaymentMethod
from strategies.payment_processor_strategy import (
    PaymentProcessorStrategy,
    CashPaymentProcessor,
    CreditCardPaymentProcessor,
    MobilePaymentProcessor
)

class PaymentProcessorFactory:
    """Factory for creating payment processor strategies"""
    
    # Registry of payment processors by payment method
    _processors: Dict[PaymentMethod, Type[PaymentProcessorStrategy]] = {
        PaymentMethod.CASH: CashPaymentProcessor,
        PaymentMethod.CREDIT_CARD: CreditCardPaymentProcessor,
        PaymentMethod.DEBIT_CARD: CreditCardPaymentProcessor,  # Reuse credit card processor
        PaymentMethod.MOBILE_PAYMENT: MobilePaymentProcessor,
    }
    
    @classmethod
    def get_processor(cls, payment_method: PaymentMethod) -> PaymentProcessorStrategy:
        """Get a payment processor for the specified payment method"""
        processor_class = cls._processors.get(payment_method)
        
        if not processor_class:
            # Default to credit card processor if no specific processor is found
            processor_class = CreditCardPaymentProcessor
            
        return processor_class()
    
    @classmethod
    def register_processor(cls, payment_method: PaymentMethod, processor_class: Type[PaymentProcessorStrategy]) -> None:
        """Register a new payment processor for a payment method"""
        cls._processors[payment_method] = processor_class 