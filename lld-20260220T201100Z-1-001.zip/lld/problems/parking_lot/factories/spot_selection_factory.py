from typing import Dict, Type
from strategies.spot_selection_strategy import (
    SpotSelectionStrategy,
    NearestSpotSelectionStrategy,
    RandomSpotSelectionStrategy,
    LevelBasedSpotSelectionStrategy,
    ExitProximitySpotSelectionStrategy,
    BalancedEntryExitStrategy
)

class SpotSelectionFactory:
    """Factory for creating spot selection strategies"""
    
    # Registry of available strategies
    _strategies: Dict[str, Type[SpotSelectionStrategy]] = {
        "nearest": NearestSpotSelectionStrategy,
        "random": RandomSpotSelectionStrategy,
        "level_based": LevelBasedSpotSelectionStrategy,
        "exit_proximity": ExitProximitySpotSelectionStrategy,
        "balanced": BalancedEntryExitStrategy
    }
    
    @classmethod
    def get_strategy(cls, strategy_name: str) -> SpotSelectionStrategy:
        """Get a spot selection strategy by name"""
        strategy_class = cls._strategies.get(strategy_name.lower(), NearestSpotSelectionStrategy)
        return strategy_class()
    
    @classmethod
    def register_strategy(cls, name: str, strategy_class: Type[SpotSelectionStrategy]) -> None:
        """Register a new strategy"""
        cls._strategies[name.lower()] = strategy_class 