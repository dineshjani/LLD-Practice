from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from models.enum import PaymentMethod, PaymentStatus
from datetime import datetime

class PaymentProcessorStrategy(ABC):
    """Abstract base class for payment processor strategies"""
    
    @abstractmethod
    def process_payment(self, amount: float, payment_method: PaymentMethod, ticket_id: str) -> Dict[str, Any]:
        """Process a payment and return the result"""
        pass


class CashPaymentProcessor(PaymentProcessorStrategy):
    """Strategy for processing cash payments"""
    
    def process_payment(self, amount: float, payment_method: PaymentMethod, ticket_id: str) -> Dict[str, Any]:
        # In a real system, this might integrate with a cash drawer or POS system
        # For this example, we'll simulate a successful cash payment
        
        transaction_id = f"CASH-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        return {
            "success": True,
            "transaction_id": transaction_id,
            "status": PaymentStatus.COMPLETED,
            "message": "Cash payment accepted",
            "receipt_number": f"R-{transaction_id[-6:]}"
        }


class CreditCardPaymentProcessor(PaymentProcessorStrategy):
    """Strategy for processing credit card payments"""
    
    def process_payment(self, amount: float, payment_method: PaymentMethod, ticket_id: str) -> Dict[str, Any]:
        # In a real system, this would integrate with a credit card payment gateway
        # For this example, we'll simulate a successful credit card payment
        
        # Simulate card validation and processing
        # In reality, this would involve communication with a payment gateway
        
        transaction_id = f"CC-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        return {
            "success": True,
            "transaction_id": transaction_id,
            "status": PaymentStatus.COMPLETED,
            "message": "Credit card payment processed",
            "authorization_code": f"AUTH-{transaction_id[-6:]}"
        }


class MobilePaymentProcessor(PaymentProcessorStrategy):
    """Strategy for processing mobile payments (e.g., Apple Pay, Google Pay)"""
    
    def process_payment(self, amount: float, payment_method: PaymentMethod, ticket_id: str) -> Dict[str, Any]:
        # In a real system, this would integrate with mobile payment APIs
        # For this example, we'll simulate a successful mobile payment
        
        transaction_id = f"MOB-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        return {
            "success": True,
            "transaction_id": transaction_id,
            "status": PaymentStatus.COMPLETED,
            "message": "Mobile payment processed",
            "confirmation_code": f"MP-{transaction_id[-6:]}"
        } 