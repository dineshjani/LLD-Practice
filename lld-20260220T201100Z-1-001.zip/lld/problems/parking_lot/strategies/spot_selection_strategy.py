from abc import ABC, abstractmethod
from typing import Optional, List
import heapq
from models.parking_spot import ParkingSpot
from models.enum import VehicleType

class SpotSelectionStrategy(ABC):
    """Abstract base class for spot selection strategies"""
    
    @abstractmethod
    def select_spot(self, candidate_spots: List[ParkingSpot], vehicle_type: VehicleType, entry_gate_id: str, preferred_exit_gate_id: str = None) -> Optional[ParkingSpot]:
        """Select a parking spot from available candidates"""
        pass


class NearestSpotSelectionStrategy(SpotSelectionStrategy):
    """Strategy that selects the spot nearest to the entry gate using a heap for efficiency"""
    
    def select_spot(self, candidate_spots: List[ParkingSpot], vehicle_type: VehicleType, entry_gate_id: str, preferred_exit_gate_id: str = None) -> Optional[ParkingSpot]:
        if not candidate_spots:
            return None
        
        # Create a min-heap of (distance, spot) tuples
        distance_heap = []
        for spot in candidate_spots:
            distance = spot.distance_to_gates.get(entry_gate_id, float('inf'))
            heapq.heappush(distance_heap, (distance, spot))
        
        # Return the spot with minimum distance (top of heap)
        if distance_heap:
            return heapq.heappop(distance_heap)[1]
        return None


class RandomSpotSelectionStrategy(SpotSelectionStrategy):
    """Strategy that selects a random spot from available candidates"""
    
    def select_spot(self, candidate_spots: List[ParkingSpot], vehicle_type: VehicleType, entry_gate_id: str, preferred_exit_gate_id: str = None) -> Optional[ParkingSpot]:
        import random
        
        if not candidate_spots:
            return None
            
        return random.choice(candidate_spots)


class LevelBasedSpotSelectionStrategy(SpotSelectionStrategy):
    """Strategy that prioritizes spots on lower levels using a heap for efficiency"""
    
    def select_spot(self, candidate_spots: List[ParkingSpot], vehicle_type: VehicleType, entry_gate_id: str, preferred_exit_gate_id: str = None) -> Optional[ParkingSpot]:
        if not candidate_spots:
            return None
        
        # Create a min-heap of (floor, distance, spot) tuples
        level_distance_heap = []
        for spot in candidate_spots:
            distance = spot.distance_to_gates.get(entry_gate_id, float('inf'))
            heapq.heappush(level_distance_heap, (spot.floor, distance, spot))
        
        # Return the spot with minimum (floor, distance) combination
        if level_distance_heap:
            return heapq.heappop(level_distance_heap)[2]
        return None


class ExitProximitySpotSelectionStrategy(SpotSelectionStrategy):
    """Strategy that selects spots based on proximity to a preferred exit gate"""
    
    def select_spot(self, candidate_spots: List[ParkingSpot], vehicle_type: VehicleType, entry_gate_id: str, preferred_exit_gate_id: str = None) -> Optional[ParkingSpot]:
        if not candidate_spots or not preferred_exit_gate_id:
            # Fall back to nearest entry gate if no exit gate is specified
            return NearestSpotSelectionStrategy().select_spot(candidate_spots, vehicle_type, entry_gate_id)
        
        # Create a min-heap of (exit_distance, spot) tuples
        exit_distance_heap = []
        for spot in candidate_spots:
            exit_distance = spot.distance_to_gates.get(preferred_exit_gate_id, float('inf'))
            heapq.heappush(exit_distance_heap, (exit_distance, spot))
        
        # Return the spot with minimum distance to exit gate
        if exit_distance_heap:
            return heapq.heappop(exit_distance_heap)[1]
        return None


class BalancedEntryExitStrategy(SpotSelectionStrategy):
    """Strategy that balances proximity to both entry and exit gates"""
    
    def select_spot(self, candidate_spots: List[ParkingSpot], vehicle_type: VehicleType, entry_gate_id: str, preferred_exit_gate_id: str = None) -> Optional[ParkingSpot]:
        if not candidate_spots:
            return None
            
        if not preferred_exit_gate_id:
            # Fall back to nearest entry gate if no exit gate is specified
            return NearestSpotSelectionStrategy().select_spot(candidate_spots, vehicle_type, entry_gate_id)
        
        # Create a min-heap of (combined_distance, spot) tuples
        # where combined_distance = entry_distance + exit_distance
        balanced_distance_heap = []
        for spot in candidate_spots:
            entry_distance = spot.distance_to_gates.get(entry_gate_id, float('inf'))
            exit_distance = spot.distance_to_gates.get(preferred_exit_gate_id, float('inf'))
            combined_distance = entry_distance + exit_distance
            heapq.heappush(balanced_distance_heap, (combined_distance, spot))
        
        # Return the spot with minimum combined distance
        if balanced_distance_heap:
            return heapq.heappop(balanced_distance_heap)[1]
        return None 