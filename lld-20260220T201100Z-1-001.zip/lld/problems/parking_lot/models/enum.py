from enum import Enum

class VehicleType(Enum):
    MOTORCYCLE = "MOTORCYCLE"
    COMPACT = "COMPACT"
    SEDAN = "SEDAN"
    SUV = "SUV"
    BUS = "BUS"
    TRUCK = "TRUCK"

class SpotType(Enum):
    SMALL = "SMALL"  # For motorcycles
    MEDIUM = "MEDIUM"  # For compact cars and sedans
    LARGE = "LARGE"  # For SUVs
    XL = "XL"  # For buses and trucks
    HANDICAPPED = "HANDICAPPED"
    ELECTRIC = "ELECTRIC"

class GateType(Enum):
    ENTRY = "ENTRY"
    EXIT = "EXIT"
    BOTH = "BOTH"

class GateStatus(Enum):
    OPERATIONAL = "OPERATIONAL"
    CLOSED = "CLOSED"
    CONGESTED = "CONGESTED"
    MAINTENANCE = "MAINTENANCE"

class TicketStatus(Enum):
    ACTIVE = "ACTIVE"
    PAID = "PAID"
    LOST = "LOST"
    EXPIRED = "EXPIRED"

class PaymentMethod(Enum):
    CASH = "CASH"
    CREDIT_CARD = "CREDIT_CARD"
    DEBIT_CARD = "DEBIT_CARD"
    MOBILE_PAYMENT = "MOBILE_PAYMENT"
    PREPAID_CARD = "PREPAID_CARD"

class PaymentStatus(Enum):
    PENDING = "PENDING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    REFUNDED = "REFUNDED"
