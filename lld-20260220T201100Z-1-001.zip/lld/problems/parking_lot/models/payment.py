import uuid
from datetime import datetime
from models.enum import PaymentMethod, PaymentStatus

class Payment:
    def __init__(self, ticket_id: str, amount: float, payment_method: PaymentMethod):
        self.id = str(uuid.uuid4())
        self.ticket_id = ticket_id
        self.amount = amount
        self.payment_method = payment_method
        self.timestamp = datetime.now()
        self.status = PaymentStatus.PENDING
        self.transaction_id = None
        
    def complete_payment(self, transaction_id: str) -> None:
        self.status = PaymentStatus.COMPLETED
        self.transaction_id = transaction_id
        
    def fail_payment(self) -> None:
        self.status = PaymentStatus.FAILED
        
    def refund_payment(self) -> None:
        self.status = PaymentStatus.REFUNDED
        
    def __str__(self):
        return f"Payment({self.id}, amount={self.amount}, status={self.status.value})"
