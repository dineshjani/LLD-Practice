import uuid
from .enums import VehicleType

class Vehicle:
    def __init__(self, license_plate: str, vehicle_type: VehicleType):
        self.id = str(uuid.uuid4())
        self.license_plate = license_plate
        self.vehicle_type = vehicle_type
        
    def __str__(self):
        return f"Vehicle(license_plate={self.license_plate}, type={self.vehicle_type.value})"
