import uuid
from models.enum import GateType, GateStatus
from typing import Set, Dict, Any

class Gate:
    def __init__(self, name: str, gate_type: GateType):
        self.id = str(uuid.uuid4())
        self.name = name
        self.gate_type = gate_type
        self.status = GateStatus.OPERATIONAL
        self.height_restriction = None  # in meters
        self.vehicle_restrictions: Set[str] = set()  # set of VehicleType values
        self.congestion_level = 0  # 0-10 scale
        
    def update_status(self, status: GateStatus) -> None:
        self.status = status
        
    def update_congestion(self, level: int) -> None:
        self.congestion_level = max(0, min(10, level))  # Ensure between 0-10
        
    def can_accommodate_vehicle(self, vehicle_type: str) -> bool:
        return vehicle_type not in self.vehicle_restrictions
        
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "type": self.gate_type.value,
            "status": self.status.value,
            "congestion_level": self.congestion_level
        }
        
    def __str__(self):
        return f"Gate({self.name}, type={self.gate_type.value}, status={self.status.value})"
