import uuid
from models.enum import SpotType
from typing import Dict, Optional, Tuple

class ParkingSpot:
    def __init__(self, floor: int, section: str, number: int, spot_type: SpotType):
        self.id = str(uuid.uuid4())
        self.floor = floor
        self.section = section
        self.number = number
        self.spot_type = spot_type
        self.is_occupied = False
        self.vehicle_id = None
        self.distance_to_gates: Dict[str, int] = {}  # gate_id -> distance
        
    @property
    def location(self) -> str:
        return f"{self.floor}-{self.section}-{self.number}"
    
    def assign_vehicle(self, vehicle_id: str) -> None:
        self.is_occupied = True
        self.vehicle_id = vehicle_id
        
    def free_spot(self) -> None:
        self.is_occupied = False
        self.vehicle_id = None
        
    def set_distance_to_gate(self, gate_id: str, distance: int) -> None:
        self.distance_to_gates[gate_id] = distance
        
    def get_nearest_gate(self) -> Optional[Tuple[str, int]]:
        if not self.distance_to_gates:
            return None
        return min(self.distance_to_gates.items(), key=lambda x: x[1])
    
    def __str__(self):
        status = "Occupied" if self.is_occupied else "Available"
        return f"ParkingSpot({self.location}, type={self.spot_type.value}, status={status})"
