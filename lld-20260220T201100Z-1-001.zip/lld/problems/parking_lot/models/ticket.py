import uuid
from datetime import datetime
from models.enum import TicketStatus

class Ticket:
    def __init__(self, vehicle_id: str, spot_id: str, entry_gate_id: str):
        self.id = str(uuid.uuid4())
        self.vehicle_id = vehicle_id
        self.spot_id = spot_id
        self.entry_gate_id = entry_gate_id
        self.recommended_exit_gate_id = None
        self.entry_time = datetime.now()
        self.exit_time = None
        self.status = TicketStatus.ACTIVE
        self.payment_id = None
        
    def set_recommended_exit_gate(self, gate_id: str) -> None:
        self.recommended_exit_gate_id = gate_id
        
    def mark_as_paid(self, payment_id: str) -> None:
        self.status = TicketStatus.PAID
        self.payment_id = payment_id
        
    def complete_exit(self) -> None:
        self.exit_time = datetime.now()
        
    def calculate_duration(self) -> float:
        """Calculate parking duration in hours"""
        end_time = self.exit_time or datetime.now()
        duration = (end_time - self.entry_time).total_seconds() / 3600  # hours
        return duration
        
    def __str__(self):
        return f"Ticket({self.id}, status={self.status.value})"
