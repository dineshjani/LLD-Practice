from models.enum import VehicleType, SpotType, GateType, PaymentMethod
from models.parking_spot import ParkingSpot
from models.gate import Gate
from service.parking_service import ParkingService
from service.gate_service import GateService
from service.ticket_service import TicketService
from service.payment_service import PaymentService
from service.notification_service import NotificationService, NotificationType
from controllers.entry_controller import EntryController
from controllers.exit_controller import ExitController
from controllers.admin_controller import AdminController
from observers.notification_observers import LoggingObserver, DisplayObserver, EmailNotificationObserver, SMSNotificationObserver
from datetime import datetime

def initialize_parking_lot(spot_selection_strategy: str = "nearest"):
    """Initialize the parking lot with sample data"""
    # Create services
    parking_service = ParkingService(spot_selection_strategy)
    gate_service = GateService()
    ticket_service = TicketService(parking_service, gate_service)
    payment_service = PaymentService(ticket_service)
    notification_service = NotificationService()
    
    # Set up notification observers
    display_observer = DisplayObserver()
    logging_observer = LoggingObserver()
    email_observer = EmailNotificationObserver("admin@parkinglot.com")
    sms_observer = SMSNotificationObserver(["123-456-7890", "098-765-4321"])
    
    # Register observers for different notification types
    notification_service.register_observer(NotificationType.VEHICLE_ENTRY, display_observer)
    notification_service.register_observer(NotificationType.VEHICLE_EXIT, display_observer)
    notification_service.register_observer(NotificationType.PAYMENT_COMPLETED, display_observer)
    
    notification_service.register_observer(NotificationType.SYSTEM_ALERT, logging_observer)
    notification_service.register_observer(NotificationType.GATE_STATUS_CHANGE, logging_observer)
    
    notification_service.register_observer(NotificationType.PARKING_FULL, email_observer)
    notification_service.register_observer(NotificationType.SYSTEM_ALERT, email_observer)
    
    notification_service.register_observer(NotificationType.PARKING_FULL, sms_observer)
    notification_service.register_observer(NotificationType.GATE_STATUS_CHANGE, sms_observer)
    
    # Create controllers with notification service
    entry_controller = EntryController(parking_service, gate_service, ticket_service, notification_service)
    exit_controller = ExitController(parking_service, gate_service, ticket_service, payment_service, notification_service)
    admin_controller = AdminController(parking_service, gate_service, ticket_service, payment_service, notification_service)
    
    # Add gates
    gate1 = Gate("North Entry", GateType.ENTRY)
    gate2 = Gate("South Entry", GateType.ENTRY)
    gate3 = Gate("East Exit", GateType.EXIT)
    gate4 = Gate("West Exit", GateType.EXIT)
    gate5 = Gate("Main Gate", GateType.BOTH)
    
    gate_service.add_gate(gate1)
    gate_service.add_gate(gate2)
    gate_service.add_gate(gate3)
    gate_service.add_gate(gate4)
    gate_service.add_gate(gate5)
    
    # Add parking spots
    # Floor 1, Section A - Small spots (for motorcycles)
    for i in range(1, 21):
        spot = ParkingSpot(1, "A", i, SpotType.SMALL)
        parking_service.add_parking_spot(spot)
    
    # Floor 1, Section B - Medium spots (for cars)
    for i in range(1, 31):
        spot = ParkingSpot(1, "B", i, SpotType.MEDIUM)
        parking_service.add_parking_spot(spot)
    
    # Floor 1, Section C - Large spots (for SUVs)
    for i in range(1, 21):
        spot = ParkingSpot(1, "C", i, SpotType.LARGE)
        parking_service.add_parking_spot(spot)
    
    # Floor 2, Section A - Medium spots
    for i in range(1, 41):
        spot = ParkingSpot(2, "A", i, SpotType.MEDIUM)
        parking_service.add_parking_spot(spot)
    
    # Floor 2, Section B - Large spots
    for i in range(1, 31):
        spot = ParkingSpot(2, "B", i, SpotType.LARGE)
        parking_service.add_parking_spot(spot)
    
    # Floor 3, Section A - XL spots (for buses and trucks)
    for i in range(1, 16):
        spot = ParkingSpot(3, "A", i, SpotType.XLARGE)
        parking_service.add_parking_spot(spot)
    
    # Calculate distances to gates
    parking_service.calculate_distances_to_gates(gate_service.gates)
    
    return {
        "parking_service": parking_service,
        "gate_service": gate_service,
        "ticket_service": ticket_service,
        "payment_service": payment_service,
        "notification_service": notification_service,
        "entry_controller": entry_controller,
        "exit_controller": exit_controller,
        "admin_controller": admin_controller
    }

def demo_parking_lot():
    """Run a demonstration of the parking lot system"""
    services = initialize_parking_lot()
    
    entry_controller = services["entry_controller"]
    exit_controller = services["exit_controller"]
    admin_controller = services["admin_controller"]
    notification_service = services["notification_service"]
    
    print("=== Parking Lot System Demo ===")
    
    # Check initial system status
    status = admin_controller.get_system_status()
    print(f"Initial System Status:")
    print(f"Total spots: {status['total_spots']}")
    print(f"Available spots: {status['available_spots']}")
    print(f"Occupancy: {status['occupancy_percentage']}%")
    
    # Process vehicle entry
    print("\n=== Vehicle Entry ===")
    entry_result = entry_controller.process_entry("ABC123", "SEDAN", services["gate_service"].entry_gates[0])
    
    if entry_result["success"]:
        print(f"Vehicle entered successfully!")
        print(f"Ticket ID: {entry_result['ticket_id']}")
        print(f"Assigned spot: {entry_result['spot_location']}")
        print(f"Entry time: {entry_result['entry_time']}")
        
        ticket_id = entry_result["ticket_id"]
        
        # Process payment
        print("\n=== Payment Processing ===")
        payment_result = exit_controller.process_payment(ticket_id, "CREDIT_CARD")
        
        if payment_result["success"]:
            print(f"Payment successful!")
            print(f"Amount: ${payment_result['amount']}")
            print(f"Payment method: {payment_result['payment_method']}")
            
            # Process exit
            print("\n=== Vehicle Exit ===")
            exit_result = exit_controller.process_exit(ticket_id, services["gate_service"].exit_gates[0])
            
            if exit_result["success"]:
                print(f"Vehicle exited successfully!")
                print(f"Duration: {exit_result['duration_hours']} hours")
                print(f"Amount paid: ${exit_result['amount_paid']}")
            else:
                print(f"Exit failed: {exit_result['message']}")
        else:
            print(f"Payment failed: {payment_result['message']}")
    else:
        print(f"Vehicle entry failed: {entry_result['message']}")
    
    # Demonstrate changing spot selection strategy
    print("\n=== Changing Spot Selection Strategy ===")
    services["parking_service"].set_spot_selection_strategy("random")
    print("Spot selection strategy changed to: Random")
    
    # Try another vehicle entry with random strategy
    entry_result = entry_controller.process_entry("XYZ789", "SUV", services["gate_service"].entry_gates[0])
    
    if entry_result["success"]:
        print(f"Vehicle entered with random spot selection!")
        print(f"Assigned spot: {entry_result['spot_location']}")
    else:
        print(f"Vehicle entry failed: {entry_result['message']}")
    
    # Try level-based strategy
    print("\n=== Changing to Level-Based Spot Selection Strategy ===")
    services["parking_service"].set_spot_selection_strategy("level_based")
    print("Spot selection strategy changed to: Level-Based")
    
    # Try another vehicle entry with level-based strategy
    print("\n=== Vehicle Entry with Level-Based Strategy ===")
    entry_result = entry_controller.process_entry("LMN456", "MOTORCYCLE", services["gate_service"].entry_gates[0])
    
    if entry_result["success"]:
        print(f"Vehicle entered with level-based spot selection!")
        print(f"Ticket ID: {entry_result['ticket_id']}")
        print(f"Assigned spot: {entry_result['spot_location']}")
        print(f"Entry time: {entry_result['entry_time']}")
        
        ticket_id = entry_result["ticket_id"]
        
        # Make payment with mobile payment
        print("\n=== Payment Processing with Mobile Payment ===")
        payment_result = exit_controller.process_payment(ticket_id, "MOBILE_PAYMENT")
        
        if payment_result["success"]:
            print(f"Mobile payment successful!")
            print(f"Amount paid: ${payment_result['amount']}")
            print(f"Transaction ID: {payment_result['transaction_id']}")
            
            # Process exit
            exit_result = exit_controller.process_exit(ticket_id, services["gate_service"].exit_gates[0])
            
            if exit_result["success"]:
                print(f"\nVehicle exited successfully!")
                print(f"Duration: {exit_result['duration_hours']} hours")
                print(f"Amount paid: ${exit_result['amount_paid']}")
            else:
                print(f"Exit failed: {exit_result['message']}")
        else:
            print(f"Payment failed: {payment_result['message']}")
    else:
        print(f"Vehicle entry failed: {entry_result['message']}")
    
    # Demonstrate exit proximity strategy
    print("\n=== Changing to Exit Proximity Spot Selection Strategy ===")
    services["parking_service"].set_spot_selection_strategy("exit_proximity")
    print("Spot selection strategy changed to: Exit Proximity")
    
    # Get an exit gate ID to use as preferred
    preferred_exit_gate_id = services["gate_service"].exit_gates[0]
    preferred_exit_gate = services["gate_service"].get_gate_by_id(preferred_exit_gate_id)
    
    print(f"\n=== Vehicle Entry with Exit Proximity Strategy (Preferred Exit: {preferred_exit_gate.name}) ===")
    entry_result = entry_controller.process_entry(
        "EXP123", 
        "SEDAN", 
        services["gate_service"].entry_gates[0],
        preferred_exit_gate_id
    )
    
    if entry_result["success"]:
        print(f"Vehicle entered with exit proximity spot selection!")
        print(f"Ticket ID: {entry_result['ticket_id']}")
        print(f"Assigned spot: {entry_result['spot_location']}")
        print(f"Entry time: {entry_result['entry_time']}")
        print(f"Recommended exit gate: {entry_result.get('recommended_exit_gate', 'None')}")
    
    # Demonstrate notification for gate status change
    print("\n=== Gate Status Change Notification Demo ===")
    admin_controller.update_gate_status(services["gate_service"].entry_gates[0], "MAINTENANCE")
    
    # Demonstrate notification for parking capacity
    print("\n=== Parking Capacity Check Notification Demo ===")
    admin_controller.check_parking_capacity()
    
    # Demonstrate notification for system alert
    print("\n=== System Alert Notification Demo ===")
    notification_service.send_notification(
        NotificationType.SYSTEM_ALERT,
        {
            "message": "System maintenance scheduled for tonight at 2 AM",
            "severity": "Medium",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
    )
    
    # Check system status again
    status = admin_controller.get_system_status()
    print(f"\n=== Final System Status ===")
    print(f"Total spots: {status['total_spots']}")
    print(f"Available spots: {status['available_spots']}")
    print(f"Occupancy: {status['occupancy_percentage']}%")
    
    # Generate revenue report
    revenue_report = admin_controller.generate_revenue_report()
    print(f"\n=== Revenue Report ===")
    print(f"Total revenue: ${revenue_report['total_revenue']}")
    print(f"Transaction count: {revenue_report['transaction_count']}")
    print("Revenue by vehicle type:")
    for vehicle_type, amount in revenue_report['revenue_by_vehicle_type'].items():
        print(f"  {vehicle_type}: ${amount}")

if __name__ == "__main__":
    demo_parking_lot()
