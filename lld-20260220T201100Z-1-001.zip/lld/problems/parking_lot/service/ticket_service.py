from typing import Dict, List, Optional
from datetime import datetime, timedelta
from models.ticket import Ticket
from models.enum import TicketStatus

class TicketService:
    def __init__(self, parking_service, gate_service):
        # In-memory storage
        self.tickets: Dict[str, Ticket] = {}  # ticket_id -> Ticket
        
        # References to other services
        self.parking_service = parking_service
        self.gate_service = gate_service
        
        # Indexes for efficient lookup
        self.active_tickets: Dict[str, str] = {}  # vehicle_id -> ticket_id
        
    def issue_ticket(self, vehicle_id: str, spot_id: str, entry_gate_id: str) -> Optional[Ticket]:
        # Verify vehicle, spot and gate exist
        vehicle = self.parking_service.get_vehicle_by_id(vehicle_id)
        spot = self.parking_service.get_spot_by_id(spot_id)
        gate = self.gate_service.get_gate_by_id(entry_gate_id)
        
        if not vehicle or not spot or not gate:
            return None
            
        # Assign vehicle to spot
        if not self.parking_service.assign_vehicle_to_spot(vehicle_id, spot_id):
            return None
            
        # Create ticket
        ticket = Ticket(vehicle_id, spot_id, entry_gate_id)
        
        # Recommend exit gate
        recommended_exit_gate_id = self.gate_service.recommend_exit_gate(spot_id, self.parking_service)
        if recommended_exit_gate_id:
            ticket.set_recommended_exit_gate(recommended_exit_gate_id)
            
        # Store ticket
        self.tickets[ticket.id] = ticket
        self.active_tickets[vehicle_id] = ticket.id
        
        return ticket
    
    def get_ticket_by_id(self, ticket_id: str) -> Optional[Ticket]:
        return self.tickets.get(ticket_id)
    
    def get_active_ticket_for_vehicle(self, vehicle_id: str) -> Optional[Ticket]:
        ticket_id = self.active_tickets.get(vehicle_id)
        if ticket_id:
            return self.tickets.get(ticket_id)
        return None
    
    def mark_ticket_as_paid(self, ticket_id: str, payment_id: str) -> bool:
        if ticket_id not in self.tickets:
            return False
            
        ticket = self.tickets[ticket_id]
        ticket.mark_as_paid(payment_id)
        
        return True
    
    def complete_exit(self, ticket_id: str) -> bool:
        if ticket_id not in self.tickets:
            return False
            
        ticket = self.tickets[ticket_id]
        
        # Update ticket
        ticket.complete_exit()
        
        # Free the parking spot
        self.parking_service.free_spot(ticket.spot_id)
        
        # Remove from active tickets
        if ticket.vehicle_id in self.active_tickets:
            del self.active_tickets[ticket.vehicle_id]
            
        return True
    
    def get_expired_tickets(self, hours_threshold: int = 24) -> List[Ticket]:
        """Get tickets that have been active for more than the threshold hours"""
        threshold_time = datetime.now() - timedelta(hours=hours_threshold)
        
        expired_tickets = []
        for ticket in self.tickets.values():
            if (ticket.status == TicketStatus.ACTIVE and 
                ticket.entry_time < threshold_time and 
                not ticket.exit_time):
                expired_tickets.append(ticket)
                
        return expired_tickets
