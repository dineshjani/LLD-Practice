from typing import Dict, List, Optional
from models.gate import Gate
from models.enum import GateType, GateStatus

class GateService:
    def __init__(self):
        # In-memory storage
        self.gates: Dict[str, Gate] = {}  # gate_id -> Gate
        
        # Indexes for efficient lookup
        self.entry_gates: List[str] = []  # List of entry gate IDs
        self.exit_gates: List[str] = []  # List of exit gate IDs
        
    def add_gate(self, gate: Gate) -> None:
        self.gates[gate.id] = gate
        
        if gate.gate_type in [GateType.ENTRY, GateType.BOTH]:
            self.entry_gates.append(gate.id)
            
        if gate.gate_type in [GateType.EXIT, GateType.BOTH]:
            self.exit_gates.append(gate.id)
    
    def get_gate_by_id(self, gate_id: str) -> Optional[Gate]:
        return self.gates.get(gate_id)
    
    def get_all_gates(self) -> List[Gate]:
        return list(self.gates.values())
    
    def get_entry_gates(self) -> List[Gate]:
        return [self.gates[gate_id] for gate_id in self.entry_gates]
    
    def get_exit_gates(self) -> List[Gate]:
        return [self.gates[gate_id] for gate_id in self.exit_gates]
    
    def update_gate_status(self, gate_id: str, status: GateStatus) -> bool:
        if gate_id not in self.gates:
            return False
        self.gates[gate_id].update_status(status)
        return True
    
    def update_gate_congestion(self, gate_id: str, level: int) -> bool:
        if gate_id not in self.gates:
            return False
        self.gates[gate_id].update_congestion(level)
        return True
    
    def find_least_congested_entry_gate(self) -> Optional[Gate]:
        if not self.entry_gates:
            return None
            
        operational_gates = [
            self.gates[gate_id] for gate_id in self.entry_gates 
            if self.gates[gate_id].status == GateStatus.OPERATIONAL
        ]
        
        if not operational_gates:
            return None
            
        return min(operational_gates, key=lambda gate: gate.congestion_level)
    
    def find_least_congested_exit_gate(self) -> Optional[Gate]:
        if not self.exit_gates:
            return None
            
        operational_gates = [
            self.gates[gate_id] for gate_id in self.exit_gates 
            if self.gates[gate_id].status == GateStatus.OPERATIONAL
        ]
        
        if not operational_gates:
            return None
            
        return min(operational_gates, key=lambda gate: gate.congestion_level)
    
    def recommend_exit_gate(self, spot_id: str, parking_service) -> Optional[str]:
        """Recommend the best exit gate based on spot location and congestion"""
        spot = parking_service.get_spot_by_id(spot_id)
        if not spot:
            return None
            
        # Get distances to all exit gates
        exit_gate_distances = {
            gate_id: spot.distance_to_gates.get(gate_id, float('inf'))
            for gate_id in self.exit_gates
            if self.gates[gate_id].status == GateStatus.OPERATIONAL
        }
        
        if not exit_gate_distances:
            return None
            
        # Factor in congestion - each congestion level adds 5 distance units
        for gate_id in exit_gate_distances:
            congestion_factor = self.gates[gate_id].congestion_level * 5
            exit_gate_distances[gate_id] += congestion_factor
            
        # Return the gate with the lowest adjusted distance
        return min(exit_gate_distances.items(), key=lambda x: x[1])[0]
