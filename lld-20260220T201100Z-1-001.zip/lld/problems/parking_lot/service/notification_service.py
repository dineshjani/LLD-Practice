from abc import ABC, abstractmethod
from typing import Dict, List, Any, Set
from enum import Enum

class NotificationType(Enum):
    VEHICLE_ENTRY = "VEHICLE_ENTRY"
    VEHICLE_EXIT = "VEHICLE_EXIT"
    PAYMENT_COMPLETED = "PAYMENT_COMPLETED"
    SPOT_ASSIGNED = "SPOT_ASSIGNED"
    GATE_STATUS_CHANGE = "GATE_STATUS_CHANGE"
    PARKING_FULL = "PARKING_FULL"
    PARKING_AVAILABLE = "PARKING_AVAILABLE"
    TICKET_EXPIRY = "TICKET_EXPIRY"
    SYSTEM_ALERT = "SYSTEM_ALERT"

class Observer(ABC):
    """Abstract base class for observers that will receive notifications"""
    
    @abstractmethod
    def update(self, notification_type: NotificationType, data: Dict[str, Any]) -> None:
        """Receive and process a notification"""
        pass

class Subject(ABC):
    """Abstract base class for subjects that will send notifications"""
    
    @abstractmethod
    def register_observer(self, notification_type: NotificationType, observer: Observer) -> None:
        """Register an observer for a specific notification type"""
        pass
    
    @abstractmethod
    def remove_observer(self, notification_type: NotificationType, observer: Observer) -> None:
        """Remove an observer for a specific notification type"""
        pass
    
    @abstractmethod
    def notify_observers(self, notification_type: NotificationType, data: Dict[str, Any]) -> None:
        """Notify all observers registered for a specific notification type"""
        pass

class NotificationService(Subject):
    """Service for managing notifications in the parking lot system"""
    
    def __init__(self):
        # Dictionary mapping notification types to sets of observers
        self.observers: Dict[NotificationType, Set[Observer]] = {
            notification_type: set() for notification_type in NotificationType
        }
    
    def register_observer(self, notification_type: NotificationType, observer: Observer) -> None:
        """Register an observer for a specific notification type"""
        self.observers[notification_type].add(observer)
    
    def remove_observer(self, notification_type: NotificationType, observer: Observer) -> None:
        """Remove an observer for a specific notification type"""
        if observer in self.observers[notification_type]:
            self.observers[notification_type].remove(observer)
    
    def notify_observers(self, notification_type: NotificationType, data: Dict[str, Any]) -> None:
        """Notify all observers registered for a specific notification type"""
        for observer in self.observers[notification_type]:
            observer.update(notification_type, data)
    
    def send_notification(self, notification_type: NotificationType, data: Dict[str, Any]) -> None:
        """Send a notification to all registered observers for the given type"""
        self.notify_observers(notification_type, data) 