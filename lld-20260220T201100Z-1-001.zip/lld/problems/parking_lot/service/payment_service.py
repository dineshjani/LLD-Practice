from typing import Dict, Optional, Tuple
from models.payment import Payment
from models.enum import PaymentMethod, PaymentStatus, VehicleType
from datetime import datetime
from factories.payment_processor_factory import PaymentProcessorFactory

class PaymentService:
    def __init__(self, ticket_service):
        # In-memory storage
        self.payments: Dict[str, Payment] = {}  # payment_id -> Payment
        
        # Reference to ticket service
        self.ticket_service = ticket_service
        
        # Rate configuration
        self.base_rates: Dict[VehicleType, float] = {
            VehicleType.MOTORCYCLE: 1.0,  # $1 per hour
            VehicleType.COMPACT: 2.0,     # $2 per hour
            VehicleType.SEDAN: 2.0,       # $2 per hour
            VehicleType.SUV: 3.0,         # $3 per hour
            VehicleType.BUS: 5.0,         # $5 per hour
            VehicleType.TRUCK: 5.0        # $5 per hour
        }
        
        # Time-based multipliers
        self.night_multiplier = 0.8  # 20% discount at night (8PM-6AM)
        self.weekend_multiplier = 1.2  # 20% surcharge on weekends
        
    def calculate_fee(self, ticket_id: str) -> Tuple[float, float]:
        """Calculate parking fee for a ticket. Returns (amount, hours)"""
        ticket = self.ticket_service.get_ticket_by_id(ticket_id)
        if not ticket:
            return 0.0, 0.0
            
        # Get vehicle type
        vehicle = self.ticket_service.parking_service.get_vehicle_by_id(ticket.vehicle_id)
        if not vehicle:
            return 0.0, 0.0
            
        # Calculate duration
        hours = ticket.calculate_duration()
        
        # Get base rate
        base_rate = self.base_rates.get(vehicle.vehicle_type, 2.0)  # Default to $2/hour
        
        # Apply time-based multipliers
        current_time = datetime.now()
        
        # Night discount (8PM-6AM)
        if current_time.hour >= 20 or current_time.hour < 6:
            base_rate *= self.night_multiplier
            
        # Weekend surcharge
        if current_time.weekday() >= 5:  # 5=Saturday, 6=Sunday
            base_rate *= self.weekend_multiplier
            
        # Calculate total amount
        amount = base_rate * hours
        
        # Round to 2 decimal places
        amount = round(amount, 2)
        
        return amount, hours
    
    def process_payment(self, ticket_id: str, payment_method: PaymentMethod) -> Optional[Payment]:
        # Calculate fee
        amount, _ = self.calculate_fee(ticket_id)
        
        if amount <= 0:
            return None
            
        # Create payment
        payment = Payment(ticket_id, amount, payment_method)
        
        # Get the appropriate payment processor
        payment_processor = PaymentProcessorFactory.get_processor(payment_method)
        
        # Process the payment
        result = payment_processor.process_payment(amount, payment_method, ticket_id)
        
        if result["success"]:
            # Update payment with transaction details
            payment.complete_payment(result["transaction_id"])
            
            # Store payment
            self.payments[payment.id] = payment
            
            # Update ticket
            self.ticket_service.mark_ticket_as_paid(ticket_id, payment.id)
            
            return payment
        else:
            # Payment failed
            payment.fail_payment()
            return None
    
    def get_payment_by_id(self, payment_id: str) -> Optional[Payment]:
        return self.payments.get(payment_id)
    
    def get_payment_for_ticket(self, ticket_id: str) -> Optional[Payment]:
        for payment in self.payments.values():
            if payment.ticket_id == ticket_id:
                return payment
        return None
