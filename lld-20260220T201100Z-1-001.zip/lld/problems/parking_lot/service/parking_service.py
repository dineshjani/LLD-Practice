from typing import List, Dict, Optional, Tuple
from ..models.parking_spot import ParkingSpot
from models.vehicle import Vehicle
from models.gate import Gate
from models.enum import SpotType, VehicleType
from factories.spot_selection_factory import SpotSelectionFactory

class ParkingService:
    def __init__(self, spot_selection_strategy: str = "nearest"):
        # In-memory storage
        self.spots: Dict[str, ParkingSpot] = {}  # spot_id -> ParkingSpot
        self.vehicles: Dict[str, Vehicle] = {}  # vehicle_id -> Vehicle
        self.vehicle_to_spot: Dict[str, str] = {}  # vehicle_id -> spot_id
        
        # Indexes for efficient lookup
        self.available_spots_by_type: Dict[SpotType, List[str]] = {
            spot_type: [] for spot_type in SpotType
        }
        self.spots_by_floor: Dict[int, List[str]] = {}  # floor -> [spot_ids]
        
        # Set the spot selection strategy
        self.spot_selection_strategy = SpotSelectionFactory.get_strategy(spot_selection_strategy)
        
    def add_parking_spot(self, spot: ParkingSpot) -> None:
        self.spots[spot.id] = spot
        self.available_spots_by_type[spot.spot_type].append(spot.id)
        
        if spot.floor not in self.spots_by_floor:
            self.spots_by_floor[spot.floor] = []
        self.spots_by_floor[spot.floor].append(spot.id)
        
    def register_vehicle(self, vehicle: Vehicle) -> None:
        self.vehicles[vehicle.id] = vehicle
        
    def find_nearest_available_spot(self, vehicle_type: VehicleType, entry_gate_id: str, preferred_exit_gate_id: str = None) -> Optional[ParkingSpot]:
        """Find the nearest available spot using the current spot selection strategy"""
        # Determine compatible spot types for this vehicle
        compatible_spot_types = self._get_compatible_spot_types(vehicle_type)
        
        # Find all available spots of compatible types
        candidate_spots = []
        for spot_type in compatible_spot_types:
            for spot_id in self.available_spots_by_type[spot_type]:
                spot = self.spots[spot_id]
                if not spot.is_occupied and entry_gate_id in spot.distance_to_gates:
                    candidate_spots.append(spot)
        
        # Use the strategy to select a spot
        return self.spot_selection_strategy.select_spot(
            candidate_spots, 
            vehicle_type, 
            entry_gate_id, 
            preferred_exit_gate_id
        )
    
    def assign_vehicle_to_spot(self, vehicle_id: str, spot_id: str) -> bool:
        if spot_id not in self.spots or vehicle_id not in self.vehicles:
            return False
            
        spot = self.spots[spot_id]
        if spot.is_occupied:
            return False
            
        # Update spot status
        spot.assign_vehicle(vehicle_id)
        self.vehicle_to_spot[vehicle_id] = spot_id
        
        # Update available spots index
        if spot_id in self.available_spots_by_type[spot.spot_type]:
            self.available_spots_by_type[spot.spot_type].remove(spot_id)
            
        return True
    
    def free_spot(self, spot_id: str) -> bool:
        if spot_id not in self.spots:
            return False
            
        spot = self.spots[spot_id]
        if not spot.is_occupied:
            return False
            
        # Remove vehicle-spot mapping
        if spot.vehicle_id in self.vehicle_to_spot:
            del self.vehicle_to_spot[spot.vehicle_id]
            
        # Update spot status
        spot.free_spot()
        
        # Update available spots index
        self.available_spots_by_type[spot.spot_type].append(spot_id)
        
        return True
    
    def get_spot_by_id(self, spot_id: str) -> Optional[ParkingSpot]:
        return self.spots.get(spot_id)
    
    def get_vehicle_by_id(self, vehicle_id: str) -> Optional[Vehicle]:
        return self.vehicles.get(vehicle_id)
    
    def get_spot_for_vehicle(self, vehicle_id: str) -> Optional[ParkingSpot]:
        spot_id = self.vehicle_to_spot.get(vehicle_id)
        if spot_id:
            return self.spots.get(spot_id)
        return None
    
    def calculate_distances_to_gates(self, gates: Dict[str, Gate]) -> None:
        """
        Calculate and store distances from each spot to each gate.
        In a real system, this would use actual distances or a pathfinding algorithm.
        Here we'll use a simplified approach based on floor differences.
        """
        for spot_id, spot in self.spots.items():
            for gate_id, gate in gates.items():
                # Simple distance calculation - in a real system this would be more complex
                # For now, we'll use a formula: 10 * floor_difference + section_factor + spot_number/10
                section_factor = ord(spot.section) - ord('A')  # A=0, B=1, etc.
                distance = 10 * abs(spot.floor) + section_factor + spot.number/10
                spot.set_distance_to_gate(gate_id, distance)
    
    def _get_compatible_spot_types(self, vehicle_type: VehicleType) -> List[SpotType]:
        """Determine which spot types can accommodate this vehicle type"""
        if vehicle_type == VehicleType.MOTORCYCLE:
            return [SpotType.SMALL, SpotType.MEDIUM, SpotType.LARGE, SpotType.XL]
        elif vehicle_type in [VehicleType.COMPACT, VehicleType.SEDAN]:
            return [SpotType.MEDIUM, SpotType.LARGE, SpotType.XL]
        elif vehicle_type == VehicleType.SUV:
            return [SpotType.LARGE, SpotType.XL]
        elif vehicle_type in [VehicleType.BUS, VehicleType.TRUCK]:
            return [SpotType.XL]
        return []
    
    def set_spot_selection_strategy(self, strategy_name: str) -> None:
        """Change the spot selection strategy"""
        self.spot_selection_strategy = SpotSelectionFactory.get_strategy(strategy_name)
