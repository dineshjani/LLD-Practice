from typing import Dict, Any, List
from models.enum import GateStatus, SpotType, VehicleType
from models.payment import Payment
from models.ticket import Ticket
from models.gate import Gate
from models.parking_spot import ParkingSpot
from models.vehicle import Vehicle
from models.enum import PaymentStatus
from datetime import datetime, timedelta
from service.parking_service import ParkingService
from service.gate_service import GateService
from service.ticket_service import TicketService
from service.payment_service import PaymentService
from service.notification_service import NotificationService, NotificationType
from models.enum import GateType

class AdminController:
    def __init__(self, parking_service, gate_service, ticket_service, payment_service, notification_service=None):
        self.parking_service = parking_service
        self.gate_service = gate_service
        self.ticket_service = ticket_service
        self.payment_service = payment_service
        self.notification_service = notification_service
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get overall system status"""
        # Count total and available spots
        total_spots = len(self.parking_service.spots)
        available_spots = sum(len(spots) for spots in self.parking_service.available_spots_by_type.values())
        
        # Count active tickets
        active_tickets = len(self.ticket_service.active_tickets)
        
        # Get gate status
        gates = []
        for gate in self.gate_service.get_all_gates():
            gates.append(gate.to_dict())
            
        return {
            "total_spots": total_spots,
            "available_spots": available_spots,
            "occupancy_percentage": round((total_spots - available_spots) / total_spots * 100, 2) if total_spots > 0 else 0,
            "active_tickets": active_tickets,
            "gates": gates
        }
    
    def update_gate_status(self, gate_id: str, status_str: str) -> Dict[str, Any]:
        """Update the status of a gate"""
        try:
            status = GateStatus(status_str)
        except ValueError:
            return {"success": False, "message": f"Invalid gate status: {status_str}"}
            
        if not self.gate_service.update_gate_status(gate_id, status):
            return {"success": False, "message": "Gate not found"}
        
        # Send notification about gate status change
        if self.notification_service:
            gate = self.gate_service.get_gate_by_id(gate_id)
            self.notification_service.send_notification(
                NotificationType.GATE_STATUS_CHANGE,
                {
                    "gate_id": gate_id,
                    "gate_name": gate.name if gate else "Unknown",
                    "status": status.value,
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
            )
            
        return {"success": True, "message": f"Gate status updated to {status.value}"}
    
    def get_expired_tickets(self, hours_threshold: int = 24) -> Dict[str, Any]:
        """Get tickets that have been active for more than the threshold hours"""
        expired_tickets = self.ticket_service.get_expired_tickets(hours_threshold)
        
        result = []
        for ticket in expired_tickets:
            vehicle = self.parking_service.get_vehicle_by_id(ticket.vehicle_id)
            spot = self.parking_service.get_spot_by_id(ticket.spot_id)
            
            result.append({
                "ticket_id": ticket.id,
                "entry_time": ticket.entry_time.strftime("%Y-%m-%d %H:%M:%S"),
                "duration_hours": round(ticket.calculate_duration(), 2),
                "license_plate": vehicle.license_plate if vehicle else "Unknown",
                "spot_location": spot.location if spot else "Unknown"
            })
        
        # Send notification if there are expired tickets
        if self.notification_service and result:
            self.notification_service.send_notification(
                NotificationType.TICKET_EXPIRY,
                {
                    "expired_tickets_count": len(result),
                    "hours_threshold": hours_threshold,
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
            )
            
        return {
            "expired_tickets": result,
            "count": len(result)
        }
    
    def add_parking_spots(self, floor: int, section: str, start_num: int, 
                         end_num: int, spot_type_str: str) -> Dict[str, Any]:
        """Add a range of parking spots"""
        try:
            spot_type = SpotType(spot_type_str)
        except ValueError:
            return {"success": False, "message": f"Invalid spot type: {spot_type_str}"}
            
        added_spots = []
        for num in range(start_num, end_num + 1):
            spot = ParkingSpot(floor, section, num, spot_type)
            self.parking_service.add_parking_spot(spot)
            added_spots.append(spot.location)
            
        # Recalculate distances to gates
        self.parking_service.calculate_distances_to_gates(self.gate_service.gates)
            
        return {
            "success": True,
            "message": f"Added {len(added_spots)} parking spots",
            "spots": added_spots
        }
    
    def add_gate(self, name: str, gate_type_str: str) -> Dict[str, Any]:
        """Add a new gate to the parking lot"""
        try:
            gate_type = GateType(gate_type_str)
        except ValueError:
            return {"success": False, "message": f"Invalid gate type: {gate_type_str}"}
            
        gate = Gate(name, gate_type)
        self.gate_service.add_gate(gate)
        
        # Recalculate distances to gates
        self.parking_service.calculate_distances_to_gates(self.gate_service.gates)
        
        # Send notification about new gate
        if self.notification_service:
            self.notification_service.send_notification(
                NotificationType.SYSTEM_ALERT,
                {
                    "message": f"New gate added: {name}",
                    "gate_id": gate.id,
                    "gate_type": gate_type.value,
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
            )
        
        return {
            "success": True,
            "message": f"Added gate: {name}",
            "gate_id": gate.id
        }
    
    def generate_revenue_report(self, start_date_str: str = None, end_date_str: str = None) -> Dict[str, Any]:
        """Generate revenue report for a date range"""
        from datetime import datetime, timedelta
        
        # Parse date strings or use defaults
        try:
            if start_date_str:
                start_date = datetime.strptime(start_date_str, "%Y-%m-%d")
            else:
                start_date = datetime.now() - timedelta(days=30)  # Last 30 days
                
            if end_date_str:
                end_date = datetime.strptime(end_date_str, "%Y-%m-%d")
            else:
                end_date = datetime.now()
        except ValueError:
            return {"success": False, "message": "Invalid date format. Use YYYY-MM-DD"}
        
        # Filter payments by date range
        filtered_payments = [
            payment for payment in self.payment_service.payments.values()
            if start_date <= payment.timestamp <= end_date and payment.status == PaymentStatus.COMPLETED
        ]
        
        # Calculate total revenue
        total_revenue = sum(payment.amount for payment in filtered_payments)
        
        # Group by vehicle type
        revenue_by_vehicle_type = {}
        for payment in filtered_payments:
            ticket = self.ticket_service.get_ticket_by_id(payment.ticket_id)
            if not ticket:
                continue
                
            vehicle = self.parking_service.get_vehicle_by_id(ticket.vehicle_id)
            if not vehicle:
                continue
                
            vehicle_type = vehicle.vehicle_type.value
            if vehicle_type not in revenue_by_vehicle_type:
                revenue_by_vehicle_type[vehicle_type] = 0
                
            revenue_by_vehicle_type[vehicle_type] += payment.amount
        
        return {
            "success": True,
            "start_date": start_date.strftime("%Y-%m-%d"),
            "end_date": end_date.strftime("%Y-%m-%d"),
            "total_revenue": round(total_revenue, 2),
            "transaction_count": len(filtered_payments),
            "revenue_by_vehicle_type": {k: round(v, 2) for k, v in revenue_by_vehicle_type.items()}
        }
    
    def set_spot_selection_strategy(self, strategy_name: str) -> Dict[str, Any]:
        """Change the spot selection strategy"""
        try:
            self.parking_service.set_spot_selection_strategy(strategy_name)
            
            # Send notification about strategy change
            if self.notification_service:
                self.notification_service.send_notification(
                    NotificationType.SYSTEM_ALERT,
                    {
                        "message": f"Spot selection strategy changed to: {strategy_name}",
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    }
                )
                
            return {
                "success": True,
                "message": f"Spot selection strategy changed to: {strategy_name}"
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to change strategy: {str(e)}"
            }
    
    def check_parking_capacity(self) -> Dict[str, Any]:
        """Check if parking lot is nearing capacity and send alerts if needed"""
        total_spots = len(self.parking_service.spots)
        available_spots = sum(len(spots) for spots in self.parking_service.available_spots_by_type.values())
        
        occupancy_percentage = round((total_spots - available_spots) / total_spots * 100, 2) if total_spots > 0 else 0
        
        result = {
            "total_spots": total_spots,
            "available_spots": available_spots,
            "occupancy_percentage": occupancy_percentage
        }
        
        # Send notifications based on capacity thresholds
        if self.notification_service:
            if available_spots == 0:
                self.notification_service.send_notification(
                    NotificationType.PARKING_FULL,
                    {
                        "message": "Parking lot is now full!",
                        "occupancy_percentage": occupancy_percentage,
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    }
                )
            elif available_spots <= 0.1 * total_spots:  # 10% or less spots available
                self.notification_service.send_notification(
                    NotificationType.SYSTEM_ALERT,
                    {
                        "message": "Parking lot is nearing capacity!",
                        "available_spots": available_spots,
                        "occupancy_percentage": occupancy_percentage,
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    }
                )
            elif available_spots >= 0.5 * total_spots and occupancy_percentage <= 50:  # More than 50% spots available
                self.notification_service.send_notification(
                    NotificationType.PARKING_AVAILABLE,
                    {
                        "message": "Plenty of parking spots available",
                        "available_spots": available_spots,
                        "occupancy_percentage": occupancy_percentage,
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    }
                )
        
        return result