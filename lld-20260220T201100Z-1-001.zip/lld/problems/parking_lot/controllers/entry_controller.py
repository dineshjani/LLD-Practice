from typing import Dict, Any, Optional, Tuple
from models.vehicle import Vehicle
from models.enum import VehicleType, GateType
from service.notification_service import NotificationType
from datetime import datetime

class EntryController:
    def __init__(self, parking_service, gate_service, ticket_service, notification_service=None):
        self.parking_service = parking_service
        self.gate_service = gate_service
        self.ticket_service = ticket_service
        self.notification_service = notification_service
    
    def process_entry(self, license_plate: str, vehicle_type_str: str, gate_id: str, preferred_exit_gate_id: str = None) -> Dict[str, Any]:
        """Process a vehicle entry at a gate"""
        # Validate gate
        gate = self.gate_service.get_gate_by_id(gate_id)
        if not gate or gate.gate_type not in [GateType.ENTRY, GateType.BOTH]:
            return {"success": False, "message": "Invalid entry gate"}
            
        # Validate preferred exit gate if provided
        if preferred_exit_gate_id:
            exit_gate = self.gate_service.get_gate_by_id(preferred_exit_gate_id)
            if not exit_gate or exit_gate.gate_type not in [GateType.EXIT, GateType.BOTH]:
                return {"success": False, "message": "Invalid preferred exit gate"}
            
        # Convert vehicle type string to enum
        try:
            vehicle_type = VehicleType(vehicle_type_str)
        except ValueError:
            return {"success": False, "message": f"Invalid vehicle type: {vehicle_type_str}"}
            
        # Check if gate can accommodate this vehicle type
        if not gate.can_accommodate_vehicle(vehicle_type.value):
            return {"success": False, "message": "This gate cannot accommodate this vehicle type"}
            
        # Register vehicle
        vehicle = Vehicle(license_plate, vehicle_type)
        self.parking_service.register_vehicle(vehicle)
        
        # Find nearest available spot
        spot = self.parking_service.find_nearest_available_spot(
            vehicle_type, 
            gate_id,
            preferred_exit_gate_id
        )
        
        if not spot:
            # Send notification about no available spots
            if self.notification_service:
                self.notification_service.send_notification(
                    NotificationType.SYSTEM_ALERT,
                    {
                        "message": f"No available spots for {vehicle_type.value}",
                        "gate_name": gate.name,
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    }
                )
            return {"success": False, "message": f"No available spots for {vehicle_type.value}"}
        
        # Issue ticket
        ticket = self.ticket_service.issue_ticket(vehicle.id, spot.id, gate_id)
        
        if not ticket:
            return {"success": False, "message": "Failed to issue ticket"}
        
        # If preferred exit gate is provided, set it as recommended exit gate
        if preferred_exit_gate_id:
            ticket.set_recommended_exit_gate(preferred_exit_gate_id)
        else:
            # Otherwise, recommend the best exit gate based on spot location
            recommended_exit_gate_id = self.gate_service.recommend_exit_gate(spot.id, self.parking_service)
            if recommended_exit_gate_id:
                ticket.set_recommended_exit_gate(recommended_exit_gate_id)
        
        # Update gate congestion
        current_congestion = gate.congestion_level
        new_congestion = min(10, current_congestion + 1)  # Ensure it doesn't exceed 10
        self.gate_service.update_gate_congestion(gate_id, new_congestion)
        
        # Send notification about vehicle entry
        if self.notification_service:
            self.notification_service.send_notification(
                NotificationType.VEHICLE_ENTRY,
                {
                    "license_plate": license_plate,
                    "vehicle_type": vehicle_type.value,
                    "gate_name": gate.name,
                    "spot_location": spot.location,
                    "entry_time": ticket.entry_time.strftime("%Y-%m-%d %H:%M:%S")
                }
            )
            
            # Also send notification about spot assignment
            self.notification_service.send_notification(
                NotificationType.SPOT_ASSIGNED,
                {
                    "license_plate": license_plate,
                    "spot_location": spot.location,
                    "spot_type": spot.spot_type.value,
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
            )
        
        # Prepare response
        response = {
            "success": True,
            "message": "Vehicle entry processed successfully",
            "ticket_id": ticket.id,
            "spot_location": spot.location,
            "entry_time": ticket.entry_time.strftime("%Y-%m-%d %H:%M:%S")
        }
        
        if ticket.recommended_exit_gate_id:
            exit_gate = self.gate_service.get_gate_by_id(ticket.recommended_exit_gate_id)
            if exit_gate:
                response["recommended_exit_gate"] = exit_gate.name
                
        return response
    
    def get_parking_availability(self) -> Dict[str, Any]:
        """Get current parking availability information"""
        # Count available spots by type
        availability = {}
        for spot_type, spot_ids in self.parking_service.available_spots_by_type.items():
            availability[spot_type.value] = len(spot_ids)
            
        # Get entry gate status
        gates = []
        for gate in self.gate_service.get_entry_gates():
            gates.append({
                "id": gate.id,
                "name": gate.name,
                "status": gate.status.value,
                "congestion_level": gate.congestion_level
            })
            
        return {
            "availability": availability,
            "entry_gates": gates
        }
