from typing import Dict, Any
from models.enum import GateType, TicketStatus, PaymentMethod
from datetime import datetime
from service.notification_service import NotificationType

class ExitController:
    def __init__(self, parking_service, gate_service, ticket_service, payment_service, notification_service=None):
        self.parking_service = parking_service
        self.gate_service = gate_service
        self.ticket_service = ticket_service
        self.payment_service = payment_service
        self.notification_service = notification_service
    
    def validate_exit(self, ticket_id: str, gate_id: str) -> Dict[str, Any]:
        """Validate if a vehicle can exit through a specific gate"""
        # Validate gate
        gate = self.gate_service.get_gate_by_id(gate_id)
        if not gate or gate.gate_type not in [GateType.EXIT, GateType.BOTH]:
            return {"success": False, "message": "Invalid exit gate"}
            
        # Validate ticket
        ticket = self.ticket_service.get_ticket_by_id(ticket_id)
        if not ticket:
            return {"success": False, "message": "Invalid ticket"}
            
        # Check if ticket is paid
        if ticket.status != TicketStatus.PAID:
            # Calculate amount due
            amount, hours = self.payment_service.calculate_fee(ticket_id)
            
            return {
                "success": False, 
                "message": "Ticket not paid", 
                "amount_due": amount,
                "duration_hours": round(hours, 2)
            }
            
        return {"success": True, "message": "Exit validated"}
    
    def process_payment(self, ticket_id: str, payment_method_str: str) -> Dict[str, Any]:
        """Process payment for a ticket"""
        # Validate ticket
        ticket = self.ticket_service.get_ticket_by_id(ticket_id)
        if not ticket:
            return {"success": False, "message": "Invalid ticket"}
            
        # Check if already paid
        if ticket.status == TicketStatus.PAID:
            return {"success": True, "message": "Ticket already paid"}
            
        # Convert payment method string to enum
        try:
            payment_method = PaymentMethod(payment_method_str)
        except ValueError:
            return {"success": False, "message": f"Invalid payment method: {payment_method_str}"}
            
        # Process payment
        payment = self.payment_service.process_payment(ticket_id, payment_method)
        if not payment:
            return {"success": False, "message": "Payment processing failed"}
            
        # Get vehicle and spot details for receipt
        vehicle = self.parking_service.get_vehicle_by_id(ticket.vehicle_id)
        spot = self.parking_service.get_spot_by_id(ticket.spot_id)
        
        # Send notification about payment
        if self.notification_service:
            self.notification_service.send_notification(
                NotificationType.PAYMENT_COMPLETED,
                {
                    "ticket_id": ticket_id,
                    "payment_id": payment.id,
                    "amount": payment.amount,
                    "payment_method": payment_method.value,
                    "license_plate": vehicle.license_plate if vehicle else "Unknown",
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
            )
        
        return {
            "success": True,
            "message": "Payment successful",
            "payment_id": payment.id,
            "amount": payment.amount,
            "timestamp": payment.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            "payment_method": payment_method.value,
            "transaction_id": payment.transaction_id,
            "vehicle_info": {
                "license_plate": vehicle.license_plate if vehicle else "Unknown",
                "type": vehicle.vehicle_type.value if vehicle else "Unknown"
            },
            "parking_info": {
                "spot": spot.location if spot else "Unknown",
                "entry_time": ticket.entry_time.strftime("%Y-%m-%d %H:%M:%S"),
                "duration_hours": round(ticket.calculate_duration(), 2)
            }
        }
    
    def process_exit(self, ticket_id: str, gate_id: str) -> Dict[str, Any]:
        """Process a vehicle exit"""
        # Validate exit
        validation = self.validate_exit(ticket_id, gate_id)
        if not validation["success"]:
            return validation
            
        # Get ticket and related info
        ticket = self.ticket_service.get_ticket_by_id(ticket_id)
        payment = self.payment_service.get_payment_for_ticket(ticket_id)
        vehicle = self.parking_service.get_vehicle_by_id(ticket.vehicle_id)
        spot = self.parking_service.get_spot_by_id(ticket.spot_id)
        gate = self.gate_service.get_gate_by_id(gate_id)
        
        # Complete exit
        self.ticket_service.complete_exit(ticket_id)
        
        # Update gate congestion
        current_congestion = gate.congestion_level
        new_congestion = max(0, current_congestion - 1)  # Ensure it doesn't go below 0
        self.gate_service.update_gate_congestion(gate_id, new_congestion)
        
        # Send notification about vehicle exit
        if self.notification_service:
            self.notification_service.send_notification(
                NotificationType.VEHICLE_EXIT,
                {
                    "license_plate": vehicle.license_plate if vehicle else "Unknown",
                    "vehicle_type": vehicle.vehicle_type.value if vehicle else "Unknown",
                    "gate_name": gate.name,
                    "exit_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "duration_hours": round(ticket.calculate_duration(), 2)
                }
            )
        
        return {
            "success": True,
            "message": "Exit processed successfully",
            "exit_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "duration_hours": round(ticket.calculate_duration(), 2),
            "amount_paid": payment.amount if payment else 0.0,
            "spot_vacated": spot.location if spot else "Unknown"
        }
            
