from abc import ABC, abstractmethod
from typing import List, Optional

from elevator.models.elevator import Elevator, Direction, ElevatorState
from elevator.models.request import ElevatorRequest


class SchedulingStrategy(ABC):
    """Abstract base class for elevator scheduling strategies"""
    
    @abstractmethod
    def select_elevator(self, request: ElevatorRequest, 
                        elevators: List[Elevator], 
                        total_floors: int) -> Optional[int]:
        """
        Select the best elevator to handle a request
        
        Args:
            request: The elevator request
            elevators: List of all elevators
            total_floors: Total number of floors in the building
            
        Returns:
            The ID of the selected elevator, or None if no elevator is available
        """
        pass


class DefaultSchedulingStrategy(SchedulingStrategy):
    """Default scheduling strategy - nearest elevator first"""
    
    def select_elevator(self, request: ElevatorRequest, 
                        elevators: List[Elevator], 
                        total_floors: int) -> Optional[int]:
        """Select the nearest available elevator"""
        best_elevator_id = None
        min_distance = float('inf')
        
        for elevator in elevators:
            # Skip elevators in maintenance
            if elevator.state == ElevatorState.MAINTENANCE:
                continue
            
            # Calculate distance to the source floor
            distance = abs(elevator.current_floor - request.source_floor)
            
            # If elevator is moving, consider its direction
            if elevator.state == ElevatorState.MOVING:
                # If elevator is moving away from the source floor, add penalty
                if (elevator.direction == Direction.UP and 
                    elevator.current_floor > request.source_floor):
                    distance += total_floors
                elif (elevator.direction == Direction.DOWN and 
                      elevator.current_floor < request.source_floor):
                    distance += total_floors
            
            # Select the elevator with minimum distance
            if distance < min_distance:
                min_distance = distance
                best_elevator_id = elevator.id
        
        return best_elevator_id


class ScanSchedulingStrategy(SchedulingStrategy):
    """SCAN (Elevator) scheduling algorithm"""
    
    def select_elevator(self, request: ElevatorRequest, 
                        elevators: List[Elevator], 
                        total_floors: int) -> Optional[int]:
        """
        Implements the SCAN algorithm (also known as elevator algorithm)
        Prioritizes elevators already moving in the direction of the request
        """
        best_elevator_id = None
        best_score = float('inf')
        
        for elevator in elevators:
            # Skip elevators in maintenance
            if elevator.state == ElevatorState.MAINTENANCE:
                continue
            
            # Calculate base distance
            distance = abs(elevator.current_floor - request.source_floor)
            
            # Calculate score based on direction and distance
            score = distance
            
            # If elevator is idle, it can change direction easily
            if elevator.direction == Direction.IDLE:
                pass  # Just use the distance as score
            # If elevator is moving in the same direction as the request
            elif ((elevator.direction == Direction.UP and 
                  request.source_floor > elevator.current_floor) or
                  (elevator.direction == Direction.DOWN and 
                   request.source_floor < elevator.current_floor)):
                # Prefer this elevator by reducing score
                score -= total_floors
            # If elevator is moving in the opposite direction
            else:
                # Add penalty
                score += total_floors
            
            # Select the elevator with minimum score
            if score < best_score:
                best_score = score
                best_elevator_id = elevator.id
        
        return best_elevator_id 