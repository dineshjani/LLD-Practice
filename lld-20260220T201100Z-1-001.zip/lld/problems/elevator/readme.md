# Elevator System Low-Level Design

This is a low-level design implementation of an elevator control system. The system can manage multiple elevators across multiple floors, handle requests, and implement different scheduling strategies.

## Design Overview

### Key Components

1. **Elevator Model**: Represents a single elevator with its state, direction, and floor requests
2. **Request Model**: Represents a request to use an elevator, with source and destination floors
3. **Elevator Controller**: Manages multiple elevators and assigns requests using a scheduling strategy
4. **Scheduling Strategies**: Different algorithms for assigning elevators to requests

### Features

- Support for multiple elevators and floors
- Internal requests (from inside elevator) and external requests (from floor buttons)
- Different scheduling strategies (nearest elevator, SCAN algorithm)
- Elevator maintenance mode
- Real-time status monitoring

### Design Patterns

- **Strategy Pattern**: For different elevator scheduling algorithms
- **Observer Pattern**: For monitoring elevator status changes
- **Command Pattern**: For handling elevator requests

## Usage

Run the demo to see the system in action: 