from enum import Enum
from typing import Optional
import time


class RequestStatus(Enum):
    PENDING = "pending"
    ASSIGNED = "assigned"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class RequestType(Enum):
    EXTERNAL = "external"  # Request from outside the elevator (floor button)
    INTERNAL = "internal"  # Request from inside the elevator


class ElevatorRequest:
    """Represents a request to use an elevator"""
    
    def __init__(self, request_id: int, source_floor: int, destination_floor: int, 
                 request_type: RequestType, priority: int = 0):
        self.id = request_id
        self.source_floor = source_floor
        self.destination_floor = destination_floor
        self.request_type = request_type
        self.status = RequestStatus.PENDING
        self.created_at = time.time()
        self.assigned_elevator: Optional[int] = None
        self.completed_at: Optional[float] = None
        self.priority = priority  # Higher number = higher priority
    
    def assign_elevator(self, elevator_id: int) -> None:
        """Assign an elevator to this request"""
        self.assigned_elevator = elevator_id
        self.status = RequestStatus.ASSIGNED
    
    def complete(self) -> None:
        """Mark the request as completed"""
        self.status = RequestStatus.COMPLETED
        self.completed_at = time.time()
    
    def cancel(self) -> None:
        """Cancel the request"""
        self.status = RequestStatus.CANCELLED
        self.completed_at = time.time()
    
    def wait_time(self) -> float:
        """Calculate the wait time for this request"""
        end_time = self.completed_at or time.time()
        return end_time - self.created_at 