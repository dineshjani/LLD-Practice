from enum import Enum
from typing import List, Dict, Set, Optional
import time


class Direction(Enum):
    UP = "up"
    DOWN = "down"
    IDLE = "idle"


class ElevatorState(Enum):
    IDLE = "idle"
    MOVING = "moving"
    STOPPED = "stopped"
    MAINTENANCE = "maintenance"


class Elevator:
    """Represents a single elevator in the system"""
    
    def __init__(self, elevator_id: int, total_floors: int):
        self.id = elevator_id
        self.current_floor = 0
        self.destination_floors: Set[int] = set()
        self.direction = Direction.IDLE
        self.state = ElevatorState.IDLE
        self.door_open = False
        self.total_floors = total_floors
        self.max_capacity = 10  # persons
        self.current_capacity = 0
        self.last_maintenance = time.time()
        self.floor_requests: Dict[int, List[int]] = {}  # floor -> [destinations]
    
    def request_floor(self, destination_floor: int) -> bool:
        """Request to go to a specific floor from inside the elevator"""
        if 0 <= destination_floor < self.total_floors and self.state != ElevatorState.MAINTENANCE:
            self.destination_floors.add(destination_floor)
            return True
        return False
    
    def add_floor_request(self, source_floor: int, destination_floor: int) -> bool:
        """Add a request to pick up at source_floor and go to destination_floor"""
        if (0 <= source_floor < self.total_floors and 
            0 <= destination_floor < self.total_floors and 
            self.state != ElevatorState.MAINTENANCE):
            
            if source_floor not in self.floor_requests:
                self.floor_requests[source_floor] = []
            
            self.floor_requests[source_floor].append(destination_floor)
            return True
        return False
    
    def move(self) -> None:
        """Move the elevator one floor in the current direction"""
        if self.state == ElevatorState.MAINTENANCE or self.door_open:
            return
        
        if self.direction == Direction.UP and self.current_floor < self.total_floors - 1:
            self.current_floor += 1
            self.state = ElevatorState.MOVING
        elif self.direction == Direction.DOWN and self.current_floor > 0:
            self.current_floor -= 1
            self.state = ElevatorState.MOVING
    
    def stop(self) -> None:
        """Stop the elevator at the current floor"""
        self.state = ElevatorState.STOPPED
    
    def open_door(self) -> None:
        """Open the elevator door"""
        if self.state != ElevatorState.MOVING:
            self.door_open = True
    
    def close_door(self) -> None:
        """Close the elevator door"""
        self.door_open = False
    
    def set_direction(self) -> None:
        """Set the direction based on current floor and destination floors"""
        if not self.destination_floors:
            self.direction = Direction.IDLE
            return
        
        next_floor = min(self.destination_floors) if self.destination_floors else None
        
        if next_floor is None:
            self.direction = Direction.IDLE
        elif next_floor > self.current_floor:
            self.direction = Direction.UP
        elif next_floor < self.current_floor:
            self.direction = Direction.DOWN
        else:
            # We've arrived at a destination
            self.destination_floors.remove(next_floor)
            self.set_direction()  # Recalculate direction
    
    def process_floor_arrival(self) -> None:
        """Process arrival at a floor - check if we need to stop"""
        # Check if this floor is a destination
        if self.current_floor in self.destination_floors:
            self.stop()
            self.open_door()
            self.destination_floors.remove(self.current_floor)
            
            # Process any requests from this floor
            if self.current_floor in self.floor_requests:
                for dest in self.floor_requests[self.current_floor]:
                    self.destination_floors.add(dest)
                del self.floor_requests[self.current_floor]
            
            # Close door after processing
            self.close_door()
            
            # Set new direction
            self.set_direction()
    
    def start_maintenance(self) -> None:
        """Put elevator in maintenance mode"""
        self.state = ElevatorState.MAINTENANCE
        self.destination_floors.clear()
        self.floor_requests.clear()
    
    def end_maintenance(self) -> None:
        """End maintenance mode"""
        self.state = ElevatorState.IDLE
        self.last_maintenance = time.time() 