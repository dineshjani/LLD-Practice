from typing import List, Dict, Optional
import time
import threading

from elevator.models.elevator import Elevator, Direction, ElevatorState
from elevator.models.request import ElevatorRequest, RequestType, RequestStatus
from elevator.strategies.scheduling_strategy import SchedulingStrategy, DefaultSchedulingStrategy


class ElevatorController:
    """Controls multiple elevators in a building"""
    
    def __init__(self, num_elevators: int, total_floors: int, 
                 scheduling_strategy: Optional[SchedulingStrategy] = None):
        self.elevators: List[Elevator] = [
            Elevator(i, total_floors) for i in range(num_elevators)
        ]
        self.total_floors = total_floors
        self.requests: Dict[int, ElevatorRequest] = {}
        self.next_request_id = 0
        self.scheduling_strategy = scheduling_strategy or DefaultSchedulingStrategy()
        
        # Start the elevator control loop in a separate thread
        self.running = True
        self.control_thread = threading.Thread(target=self._control_loop)
        self.control_thread.daemon = True
        self.control_thread.start()
    
    def request_elevator(self, source_floor: int, destination_floor: int, 
                         request_type: RequestType = RequestType.EXTERNAL,
                         priority: int = 0) -> int:
        """Create a new elevator request"""
        request_id = self.next_request_id
        self.next_request_id += 1
        
        request = ElevatorRequest(
            request_id=request_id,
            source_floor=source_floor,
            destination_floor=destination_floor,
            request_type=request_type,
            priority=priority
        )
        
        self.requests[request_id] = request
        
        # If it's an internal request (from inside elevator), assign it directly
        if request_type == RequestType.INTERNAL and request.assigned_elevator is not None:
            elevator = self.elevators[request.assigned_elevator]
            elevator.request_floor(destination_floor)
        else:
            # Otherwise, use scheduling strategy to assign an elevator
            self._assign_elevator_to_request(request)
        
        return request_id
    
    def _assign_elevator_to_request(self, request: ElevatorRequest) -> None:
        """Assign the most suitable elevator to a request using the scheduling strategy"""
        elevator_id = self.scheduling_strategy.select_elevator(
            request, self.elevators, self.total_floors
        )
        
        if elevator_id is not None:
            request.assign_elevator(elevator_id)
            elevator = self.elevators[elevator_id]
            
            if request.request_type == RequestType.EXTERNAL:
                # For external requests, we need to pick up at source floor first
                elevator.add_floor_request(request.source_floor, request.destination_floor)
            else:
                # For internal requests, just go to destination
                elevator.request_floor(request.destination_floor)
    
    def _control_loop(self) -> None:
        """Main control loop for all elevators"""
        while self.running:
            for elevator in self.elevators:
                if elevator.state != ElevatorState.MAINTENANCE:
                    # Process current floor
                    elevator.process_floor_arrival()
                    
                    # Move elevator if it has destinations
                    if elevator.destination_floors:
                        elevator.set_direction()
                        elevator.move()
            
            # Check for completed requests
            for request_id, request in list(self.requests.items()):
                if (request.status == RequestStatus.ASSIGNED and 
                    request.assigned_elevator is not None):
                    
                    elevator = self.elevators[request.assigned_elevator]
                    
                    # If the elevator is at the destination floor, mark request as completed
                    if (elevator.current_floor == request.destination_floor and
                        request.source_floor not in elevator.floor_requests):
                        request.complete()
            
            # Sleep to avoid consuming too much CPU
            time.sleep(0.1)
    
    def stop(self) -> None:
        """Stop the elevator control thread"""
        self.running = False
        if self.control_thread.is_alive():
            self.control_thread.join(timeout=1.0)
    
    def get_elevator_status(self, elevator_id: int) -> Dict:
        """Get the current status of an elevator"""
        if 0 <= elevator_id < len(self.elevators):
            elevator = self.elevators[elevator_id]
            return {
                "id": elevator.id,
                "current_floor": elevator.current_floor,
                "direction": elevator.direction.value,
                "state": elevator.state.value,
                "door_open": elevator.door_open,
                "destinations": sorted(list(elevator.destination_floors))
            }
        return {}
    
    def get_all_elevator_status(self) -> List[Dict]:
        """Get status of all elevators"""
        return [self.get_elevator_status(i) for i in range(len(self.elevators))]
    
    def start_maintenance(self, elevator_id: int) -> bool:
        """Put an elevator in maintenance mode"""
        if 0 <= elevator_id < len(self.elevators):
            self.elevators[elevator_id].start_maintenance()
            return True
        return False
    
    def end_maintenance(self, elevator_id: int) -> bool:
        """End maintenance mode for an elevator"""
        if 0 <= elevator_id < len(self.elevators):
            self.elevators[elevator_id].end_maintenance()
            return True
        return False 