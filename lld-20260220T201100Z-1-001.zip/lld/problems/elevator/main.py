from elevator.controllers.elevator_controller import ElevatorController
from elevator.models.request import RequestType
from elevator.strategies.scheduling_strategy import ScanSchedulingStrategy
import time


def main():
    """Main entry point for the elevator system"""
    print("Starting Elevator System...")
    
    # Create an elevator controller with 3 elevators and 10 floors
    # Using the SCAN scheduling strategy
    controller = ElevatorController(
        num_elevators=3,
        total_floors=10,
        scheduling_strategy=ScanSchedulingStrategy()
    )
    
    try:
        # Simulate some elevator requests
        print("Simulating elevator requests...")
        
        # External request from floor 0 to floor 5
        request1 = controller.request_elevator(
            source_floor=0,
            destination_floor=5,
            request_type=RequestType.EXTERNAL
        )
        print(f"Created request {request1}: Floor 0 to Floor 5")
        
        # Wait a bit
        time.sleep(1)
        
        # External request from floor 7 to floor 2
        request2 = controller.request_elevator(
            source_floor=7,
            destination_floor=2,
            request_type=RequestType.EXTERNAL
        )
        print(f"Created request {request2}: Floor 7 to Floor 2")
        
        # Simulate the system running for a while
        for _ in range(30):
            # Print status of all elevators
            statuses = controller.get_all_elevator_status()
            for status in statuses:
                print(f"Elevator {status['id']}: Floor {status['current_floor']}, "
                      f"Direction: {status['direction']}, State: {status['state']}")
            
            time.sleep(1)
        
        # Stop the controller
        controller.stop()
        print("Elevator system stopped")
    
    except KeyboardInterrupt:
        print("\nShutting down elevator system...")
        controller.stop()


if __name__ == "__main__":
    main() 