from uuid import UUID
from typing import Optional

class TicketException(Exception):
    """Base exception class for all ticket-related exceptions."""
    
    def __init__(self, message: str):
        self.message = message
        super().__init__(self.message)


class TicketNotFoundException(TicketException):
    """Exception raised when a ticket cannot be found."""
    
    def __init__(self, ticket_id: Optional[UUID] = None, message: Optional[str] = None):
        if message:
            self.message = message
        elif ticket_id:
            self.message = f"Ticket with ID {ticket_id} not found"
        else:
            self.message = "Ticket not found"
        super().__init__(self.message)


class TicketNotAvailableException(TicketException):
    """Exception raised when a ticket is not available for purchase or reservation."""
    
    def __init__(self, ticket_id: Optional[UUID] = None, status: Optional[str] = None):
        if ticket_id and status:
            self.message = f"Ticket with ID {ticket_id} is not available. Current status: {status}"
        elif ticket_id:
            self.message = f"Ticket with ID {ticket_id} is not available"
        else:
            self.message = "Ticket is not available"
        super().__init__(self.message)


class TicketReservationExpiredException(TicketException):
    """Exception raised when attempting to use an expired ticket reservation."""
    
    def __init__(self, ticket_id: Optional[UUID] = None):
        if ticket_id:
            self.message = f"Reservation for ticket with ID {ticket_id} has expired"
        else:
            self.message = "Ticket reservation has expired"
        super().__init__(self.message)


class TicketAlreadyReservedException(TicketException):
    """Exception raised when attempting to reserve a ticket that is already reserved."""
    
    def __init__(self, ticket_id: Optional[UUID] = None, user_id: Optional[UUID] = None):
        if ticket_id and user_id:
            self.message = f"Ticket with ID {ticket_id} is already reserved by user {user_id}"
        elif ticket_id:
            self.message = f"Ticket with ID {ticket_id} is already reserved"
        else:
            self.message = "Ticket is already reserved"
        super().__init__(self.message)


class TicketOwnershipException(TicketException):
    """Exception raised when a user attempts to perform an operation on a ticket they don't own."""
    
    def __init__(self, ticket_id: Optional[UUID] = None, user_id: Optional[UUID] = None):
        if ticket_id and user_id:
            self.message = f"User {user_id} does not own ticket with ID {ticket_id}"
        elif ticket_id:
            self.message = f"User does not own ticket with ID {ticket_id}"
        else:
            self.message = "User does not own this ticket"
        super().__init__(self.message)


class TicketTransferException(TicketException):
    """Exception raised when a ticket transfer fails."""
    
    def __init__(self, ticket_id: Optional[UUID] = None, reason: Optional[str] = None):
        if ticket_id and reason:
            self.message = f"Failed to transfer ticket with ID {ticket_id}: {reason}"
        elif ticket_id:
            self.message = f"Failed to transfer ticket with ID {ticket_id}"
        elif reason:
            self.message = f"Failed to transfer ticket: {reason}"
        else:
            self.message = "Failed to transfer ticket"
        super().__init__(self.message)


class TicketResaleException(TicketException):
    """Exception raised when a ticket resale operation fails."""
    
    def __init__(self, ticket_id: Optional[UUID] = None, reason: Optional[str] = None):
        if ticket_id and reason:
            self.message = f"Failed to resell ticket with ID {ticket_id}: {reason}"
        elif ticket_id:
            self.message = f"Failed to resell ticket with ID {ticket_id}"
        elif reason:
            self.message = f"Failed to resell ticket: {reason}"
        else:
            self.message = "Failed to resell ticket"
        super().__init__(self.message)


class TicketPurchaseException(TicketException):
    """Exception raised when a ticket purchase fails."""
    
    def __init__(self, ticket_id: Optional[UUID] = None, reason: Optional[str] = None):
        if ticket_id and reason:
            self.message = f"Failed to purchase ticket with ID {ticket_id}: {reason}"
        elif ticket_id:
            self.message = f"Failed to purchase ticket with ID {ticket_id}"
        elif reason:
            self.message = f"Failed to purchase ticket: {reason}"
        else:
            self.message = "Failed to purchase ticket"
        super().__init__(self.message)


class TicketLimitExceededException(TicketException):
    """Exception raised when a user attempts to purchase more tickets than allowed."""
    
    def __init__(self, user_id: Optional[UUID] = None, event_id: Optional[UUID] = None, limit: Optional[int] = None):
        if user_id and event_id and limit:
            self.message = f"User {user_id} has exceeded the limit of {limit} tickets for event {event_id}"
        elif limit:
            self.message = f"Exceeded the limit of {limit} tickets per user"
        else:
            self.message = "Exceeded the maximum number of tickets allowed per user"
        super().__init__(self.message) 