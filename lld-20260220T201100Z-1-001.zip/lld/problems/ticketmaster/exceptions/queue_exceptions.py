from uuid import UUID
from typing import Optional

class QueueException(Exception):
    """Base exception class for all queue-related exceptions."""
    
    def __init__(self, message: str):
        self.message = message
        super().__init__(self.message)


class QueueNotFoundException(QueueException):
    """Exception raised when a queue cannot be found."""
    
    def __init__(self, queue_id: Optional[UUID] = None, game_id: Optional[UUID] = None):
        if queue_id:
            self.message = f"Queue with ID {queue_id} not found"
        elif game_id:
            self.message = f"No queue found for game with ID {game_id}"
        else:
            self.message = "Queue not found"
        super().__init__(self.message)


class QueueFullException(QueueException):
    """Exception raised when attempting to add a user to a queue that is at capacity."""
    
    def __init__(self, queue_id: Optional[UUID] = None, game_id: Optional[UUID] = None, capacity: Optional[int] = None):
        if queue_id and capacity:
            self.message = f"Queue with ID {queue_id} is at maximum capacity of {capacity}"
        elif game_id and capacity:
            self.message = f"Queue for game with ID {game_id} is at maximum capacity of {capacity}"
        elif capacity:
            self.message = f"Queue is at maximum capacity of {capacity}"
        else:
            self.message = "Queue is at maximum capacity"
        super().__init__(self.message)


class UserNotInQueueException(QueueException):
    """Exception raised when a user is not in the queue."""
    
    def __init__(self, user_id: Optional[UUID] = None, queue_id: Optional[UUID] = None, game_id: Optional[UUID] = None):
        if user_id and queue_id:
            self.message = f"User {user_id} is not in queue with ID {queue_id}"
        elif user_id and game_id:
            self.message = f"User {user_id} is not in queue for game with ID {game_id}"
        elif user_id:
            self.message = f"User {user_id} is not in the queue"
        else:
            self.message = "User is not in the queue"
        super().__init__(self.message)


class QueueNotActiveException(QueueException):
    """Exception raised when attempting to join a queue that is not active."""
    
    def __init__(self, queue_id: Optional[UUID] = None, game_id: Optional[UUID] = None):
        if queue_id:
            self.message = f"Queue with ID {queue_id} is not active"
        elif game_id:
            self.message = f"Queue for game with ID {game_id} is not active"
        else:
            self.message = "Queue is not active"
        super().__init__(self.message)


class QueueAdmissionExpiredException(QueueException):
    """Exception raised when a user's admission from the queue has expired."""
    
    def __init__(self, user_id: Optional[UUID] = None, queue_id: Optional[UUID] = None):
        if user_id and queue_id:
            self.message = f"Admission for user {user_id} in queue {queue_id} has expired"
        elif user_id:
            self.message = f"Admission for user {user_id} has expired"
        else:
            self.message = "Queue admission has expired"
        super().__init__(self.message)


class QueueProcessingException(QueueException):
    """Exception raised when there is an error processing the queue."""
    
    def __init__(self, queue_id: Optional[UUID] = None, reason: Optional[str] = None):
        if queue_id and reason:
            self.message = f"Error processing queue with ID {queue_id}: {reason}"
        elif queue_id:
            self.message = f"Error processing queue with ID {queue_id}"
        elif reason:
            self.message = f"Error processing queue: {reason}"
        else:
            self.message = "Error processing queue"
        super().__init__(self.message)


class QueueAlreadyExistsException(QueueException):
    """Exception raised when attempting to create a queue that already exists."""
    
    def __init__(self, game_id: Optional[UUID] = None):
        if game_id:
            self.message = f"Queue already exists for game with ID {game_id}"
        else:
            self.message = "Queue already exists"
        super().__init__(self.message)


class UserAlreadyInQueueException(QueueException):
    """Exception raised when a user is already in the queue."""
    
    def __init__(self, user_id: Optional[UUID] = None, queue_id: Optional[UUID] = None, game_id: Optional[UUID] = None):
        if user_id and queue_id:
            self.message = f"User {user_id} is already in queue with ID {queue_id}"
        elif user_id and game_id:
            self.message = f"User {user_id} is already in queue for game with ID {game_id}"
        elif user_id:
            self.message = f"User {user_id} is already in the queue"
        else:
            self.message = "User is already in the queue"
        super().__init__(self.message) 