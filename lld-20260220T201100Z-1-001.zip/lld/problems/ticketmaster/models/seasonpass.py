from uuid import UUID, uuid4
from typing import List
from .user import User
from .game import Game

class SeasonPass:
    def __init__(self, user: User, games: List[Game], discount_percent: float, package_type: str):
        self.packageId = uuid4()
        self.user = user
        self.games = games
        self.discountPercent = discount_percent
        self.type = package_type
