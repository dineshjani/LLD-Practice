from datetime import datetime
from typing import List, Optional, Dict, Any
from uuid import UUID, uuid4

class Event:
    def __init__(self, name: str, description: str, start_date: datetime, 
                 end_date: datetime, venue_id: UUID, id: Optional[UUID] = None):
        self.id = id or uuid4()
        self.name = name
        self.description = description
        self.start_date = start_date
        self.end_date = end_date
        self.venue_id = venue_id
        self.event_type = "GENERIC"  # Base type

class Game(Event):
    def __init__(self, name: str, description: str, start_date: datetime, 
                 end_date: datetime, venue_id: UUID, home_team: str, 
                 away_team: str, is_high_demand: bool = False, id: Optional[UUID] = None):
        super().__init__(name, description, start_date, end_date, venue_id, id)
        self.home_team = home_team
        self.away_team = away_team
        self.is_high_demand = is_high_demand
        self.event_type = "GAME"  # Specialized type
        self.tickets = []  # List to store ticket IDs
        
    def add_ticket(self, ticket_id: UUID) -> None:
        """Add a ticket to this game."""
        self.tickets.append(ticket_id)
    
    def get_available_ticket_count(self) -> int:
        """This would need to be implemented with a ticket service lookup"""
        pass

