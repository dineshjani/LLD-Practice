from .booking import Booking
from .ticket import Ticket

# models/user.py
from uuid import UUID, uuid4
from typing import List
from enum import Enum

class AccountType(Enum):
    CUSTOMER = "CUSTOMER"
    ADMIN = "ADMIN"
    VENUE_MANAGER = "VENUE_MANAGER"

class User:
    def __init__(self, name: str, email: str, phone: str, account_type: AccountType):
        self.userId = uuid4()
        self.name = name
        self.email = email
        self.phone = phone
        self.accountType = account_type
        self.bookings: List[Booking] = []
        self.tickets: List[Ticket] = []