from uuid import UUID, uuid4
from typing import List
from .seat import Seat

class Stadium:
    def __init__(self, name: str, city: str):
        self.stadiumId = uuid4()
        self.name = name
        self.city = city
        self.seatingLayout = SeatingLayout()

class SeatingLayout:
    def __init__(self):
        self.layoutId = uuid4()
        self.seats: List[Seat] = []
