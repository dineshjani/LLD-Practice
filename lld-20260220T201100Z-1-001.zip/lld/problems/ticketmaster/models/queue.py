from uuid import UUID, uuid4
from datetime import datetime
from typing import List
from .game import Game

class Queue:
    def __init__(self, game: Game):
        self.queueId = uuid4()
        self.game = game
        self.userIds: List[UUID] = []
        self.timestamp = datetime.now()
