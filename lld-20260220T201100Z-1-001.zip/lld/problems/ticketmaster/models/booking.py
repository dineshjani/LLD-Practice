from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Any
from uuid import UUID, uuid4

from .ticket import Ticket
from .user import User


class BookingStatus(Enum):
    PENDING = "PENDING"
    CONFIRMED = "CONFIRMED"
    CANCELLED = "CANCELLED"
    REFUNDED = "REFUNDED"

class Booking:
    def __init__(self, user: User, tickets: List[Ticket]):
        self.bookingId = uuid4()
        self.user = user
        self.tickets = tickets
        self.paymentStatus = "PENDING"
        self.timestamp = datetime.now()