from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Any
from uuid import UUID

from .base_models import BaseModel

class PaymentMethod(Enum):
    CREDIT_CARD = "CREDIT_CARD"
    DEBIT_CARD = "DEBIT_CARD"
    PAYPAL = "PAYPAL"
    GOOGLE_PAY = "GOOGLE_PAY"
    APPLE_PAY = "APPLE_PAY"
    STRIPE = "STRIPE"

class PaymentStatus(Enum):
    PENDING = "PENDING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    REFUNDED = "REFUNDED"

class Payment:
    """Model representing a payment in the system."""
    
    def __init__(self,
                 id: Optional[UUID] = None,
                 booking_id: Optional[UUID] = None,
                 user_id: Optional[UUID] = None,
                 amount: float = 0.0,
                 method: PaymentMethod = PaymentMethod.CREDIT_CARD,
                 status: PaymentStatus = PaymentStatus.PENDING,
                 transaction_id: str = "",
                 payment_time: Optional[datetime] = None):
        super().__init__(id)
        self.booking_id = booking_id
        self.user_id = user_id
        self.amount = amount
        self.method = method
        self.status = status
        self.transaction_id = transaction_id
        self.payment_time = payment_time or datetime.now()
    
    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data.update({
            "booking_id": str(self.booking_id) if self.booking_id else None,
            "user_id": str(self.user_id) if self.user_id else None,
            "amount": self.amount,
            "method": self.method.value,
            "status": self.status.value,
            "transaction_id": self.transaction_id,
            "payment_time": self.payment_time.isoformat()
        })
        return data 