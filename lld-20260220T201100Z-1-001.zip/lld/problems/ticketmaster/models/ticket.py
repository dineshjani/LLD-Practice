from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Any
from uuid import UUID, uuid4
from .game import Game
from .seat import Seat


class TicketStatus(Enum):
    AVAILABLE = "AVAILABLE"
    RESERVED = "RESERVED"
    SOLD = "SOLD"
    RESALE = "RESALE"
    USED = "USED"
    CANCELLED = "CANCELLED"

class Ticket:
    """Model representing a ticket in the system."""
    
    def __init__(self, game: Game, seat: Seat, price: float, owner_id: UUID, is_resellable: bool):
        self.ticketId = uuid4()
        self.game = game
        self.seat = seat
        self.price = price
        self.status = "AVAILABLE"
        self.ownerId = owner_id
        self.isResellable = is_resellable
        self.qrCode = ""
        self.reserved_until = None
    
    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data.update({
            "ticketId": str(self.ticketId),
            "game": str(self.game.gameId) if self.game else None,
            "seat": str(self.seat.seatId) if self.seat else None,
            "price": self.price,
            "status": self.status.value,
            "ownerId": str(self.ownerId) if self.ownerId else None,
            "qrCode": self.qrCode,
            "reserved_until": self.reserved_until.isoformat() if self.reserved_until else None
        })
        return data 