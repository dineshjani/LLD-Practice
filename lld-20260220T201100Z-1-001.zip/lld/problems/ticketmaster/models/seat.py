from enum import Enum
from typing import Dict, List, Optional, Any
from uuid import UUID, uuid4

class SeatCategory(Enum):
    GENERAL = "GENERAL"
    PREMIUM = "PREMIUM"
    VIP = "VIP"
    BOX = "BOX"
    SUITE = "SUITE"

class Seat:
    """Model representing a seat in a venue."""
    
    def __init__(self, section: str, row: str, number: str, seat_type: str, status: str):
        self.seatId = uuid4()
        self.section = section
        self.row = row
        self.number = number
        self.seatType = seat_type
        self.status = status
    
    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data.update({
            "seatId": str(self.seatId),
            "section": self.section,
            "row": self.row,
            "number": self.number,
            "seatType": self.seatType,
            "status": self.status
        })
        return data 