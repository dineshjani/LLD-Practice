
from uuid import UUID, uuid4
from .ticket import Ticket
from .user import User

class ResellListing:
    def __init__(self, ticket: Ticket, seller: User, price: float):
        self.listingId = uuid4()
        self.originalTicketId = ticket.ticketId
        self.sellerId = seller.userId
        self.price = price
        self.status = "ACTIVE"
