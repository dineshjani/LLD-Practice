from typing import Dict, List, Optional, Any
from uuid import UUID


class Venue:
    """Model representing a venue where events take place."""
    
    def __init__(self,
                 id: Optional[UUID] = None,
                 name: str = "",
                 address: str = "",
                 city: str = "",
                 state: str = "",
                 country: str = "",
                 capacity: int = 0,
                 seating_layout: Dict[str, Any] = None):
        super().__init__(id)
        self.name = name
        self.address = address
        self.city = city
        self.state = state
        self.country = country
        self.capacity = capacity
        self.seating_layout = seating_layout or {}
    
    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data.update({
            "name": self.name,
            "address": self.address,
            "city": self.city,
            "state": self.state,
            "country": self.country,
            "capacity": self.capacity,
            "seating_layout": self.seating_layout
        })
        return data
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Venue':
        instance = super().from_dict(cls, data)
        instance.name = data.get("name", "")
        instance.address = data.get("address", "")
        instance.city = data.get("city", "")
        instance.state = data.get("state", "")
        instance.country = data.get("country", "")
        instance.capacity = data.get("capacity", 0)
        instance.seating_layout = data.get("seating_layout", {})
        return instance 