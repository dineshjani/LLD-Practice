import requests
from typing import Dict, List, Optional, Any
import logging

class TicketmasterClient:
    """
    A client for interacting with the Ticketmaster API.
    """
    
    BASE_URL = "https://app.ticketmaster.com/discovery/v2"
    
    def __init__(self, api_key: str):
        """
        Initialize the Ticketmaster client.
        
        Args:
            api_key: The API key for authenticating with Ticketmaster
        """
        self.api_key = api_key
        self.logger = logging.getLogger(__name__)
    
    def _make_request(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Make a request to the Ticketmaster API.
        
        Args:
            endpoint: The API endpoint to call
            params: Optional query parameters
            
        Returns:
            The JSON response from the API
            
        Raises:
            Exception: If the request fails
        """
        if params is None:
            params = {}
        
        # Add API key to parameters
        params['apikey'] = self.api_key
        
        url = f"{self.BASE_URL}/{endpoint}"
        
        try:
            response = requests.get(url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error making request to Ticketmaster API: {e}")
            raise Exception(f"Ticketmaster API request failed: {e}")
    
    def search_events(self, keyword: Optional[str] = None, 
                     city: Optional[str] = None,
                     start_date: Optional[str] = None,
                     end_date: Optional[str] = None,
                     size: int = 20,
                     page: int = 0) -> Dict[str, Any]:
        """
        Search for events based on various criteria.
        
        Args:
            keyword: Keyword to search for in event names
            city: City where the event is taking place
            start_date: Start date for events (ISO format: yyyy-MM-dd'T'HH:mm:ss'Z')
            end_date: End date for events (ISO format: yyyy-MM-dd'T'HH:mm:ss'Z')
            size: Number of results per page
            page: Page number
            
        Returns:
            Dictionary containing event search results
        """
        params = {
            'size': size,
            'page': page
        }
        
        if keyword:
            params['keyword'] = keyword
        
        if city:
            params['city'] = city
            
        if start_date:
            params['startDateTime'] = start_date
            
        if end_date:
            params['endDateTime'] = end_date
        
        return self._make_request('events.json', params)
    
    def get_event_details(self, event_id: str) -> Dict[str, Any]:
        """
        Get detailed information about a specific event.
        
        Args:
            event_id: The ID of the event
            
        Returns:
            Dictionary containing event details
        """
        return self._make_request(f'events/{event_id}.json')
    
    def get_venues(self, keyword: Optional[str] = None, 
                  city: Optional[str] = None,
                  size: int = 20,
                  page: int = 0) -> Dict[str, Any]:
        """
        Search for venues based on various criteria.
        
        Args:
            keyword: Keyword to search for in venue names
            city: City where the venue is located
            size: Number of results per page
            page: Page number
            
        Returns:
            Dictionary containing venue search results
        """
        params = {
            'size': size,
            'page': page
        }
        
        if keyword:
            params['keyword'] = keyword
        
        if city:
            params['city'] = city
        
        return self._make_request('venues.json', params)
    
    def get_venue_details(self, venue_id: str) -> Dict[str, Any]:
        """
        Get detailed information about a specific venue.
        
        Args:
            venue_id: The ID of the venue
            
        Returns:
            Dictionary containing venue details
        """
        return self._make_request(f'venues/{venue_id}.json')
    
    def get_attractions(self, keyword: Optional[str] = None,
                       size: int = 20,
                       page: int = 0) -> Dict[str, Any]:
        """
        Search for attractions (artists, teams, etc.) based on various criteria.
        
        Args:
            keyword: Keyword to search for in attraction names
            size: Number of results per page
            page: Page number
            
        Returns:
            Dictionary containing attraction search results
        """
        params = {
            'size': size,
            'page': page
        }
        
        if keyword:
            params['keyword'] = keyword
        
        return self._make_request('attractions.json', params)
    
    def get_attraction_details(self, attraction_id: str) -> Dict[str, Any]:
        """
        Get detailed information about a specific attraction.
        
        Args:
            attraction_id: The ID of the attraction
            
        Returns:
            Dictionary containing attraction details
        """
        return self._make_request(f'attractions/{attraction_id}.json')
