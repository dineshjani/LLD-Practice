from abc import ABC, abstractmethod
from typing import Dict, Any

class PaymentGateway(ABC):
    @abstractmethod
    def process_payment(self, amount: float, payment_details: Dict[str, Any]) -> bool:
        """Process a payment."""
        pass

    @abstractmethod
    def process_refund(self, payment_id: str) -> bool:
        """Process a refund."""
        pass

class StripeGateway(PaymentGateway):
    def process_payment(self, amount: float, payment_details: Dict[str, Any]) -> bool:
        # Implement Stripe payment processing logic
        print(f"Processing payment of {amount} with Stripe")
        return True

    def process_refund(self, payment_id: str) -> bool:
        # Implement Stripe refund processing logic
        print(f"Processing refund for payment ID {payment_id} with Stripe")
        return True

class PayPalGateway(PaymentGateway):
    def process_payment(self, amount: float, payment_details: Dict[str, Any]) -> bool:
        # Implement PayPal payment processing logic
        print(f"Processing payment of {amount} with PayPal")
        return True

    def process_refund(self, payment_id: str) -> bool:
        # Implement PayPal refund processing logic
        print(f"Processing refund for payment ID {payment_id} with PayPal")
        return True 