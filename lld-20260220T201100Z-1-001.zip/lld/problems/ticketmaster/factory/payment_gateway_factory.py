from .payment_gateway import PaymentGateway
from factory.payment_gateway import StripeGateway
from factory.payment_gateway import PayPalGateway

class PaymentGatewayFactory:
    @staticmethod
    def get_gateway(gateway_type: str) -> PaymentGateway:
        if gateway_type == "stripe":
            return StripeGateway()
        elif gateway_type == "paypal":
            return PayPalGateway()
        else:
            raise ValueError(f"Unsupported payment gateway type: {gateway_type}") 