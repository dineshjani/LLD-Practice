from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from uuid import UUID, uuid4

from ..models.game import Game
from ..models.stadium import Stadium
from ..models.ticket import Ticket, TicketStatus
from ..models.seat import Seat
from ..services.ticket_service import TicketService
from ..services.pricing_service import PricingService

class GameService:
    """
    Service for managing games (sporting events).
    
    This service handles:
    - Creating and managing games
    - Identifying high-demand games
    - Making tickets available at the appropriate time
    - Retrieving games by various criteria
    """
    
    def __init__(
        self,
        ticket_service: TicketService,
        pricing_service: Optional[PricingService] = None,
        config: Dict[str, Any] = None
    ):
        self.games = {}  # Dictionary to store games by ID
        self.ticket_service = ticket_service
        self.pricing_service = pricing_service
        
        # Default configuration
        self.config = {
            'tickets_available_days_before': 2,  # Make tickets available 2 days before game
            'high_demand_teams': [
                "LA Lakers", "Golden State Warriors", "Chicago Bulls", 
                "New York Yankees", "Boston Red Sox", "Dallas Cowboys",
                "New England Patriots", "Real Madrid", "Barcelona", 
                "Manchester United", "Liverpool"
            ],
            'dynamic_pricing_enabled': True
        }
        
        # Override defaults with provided config
        if config:
            self.config.update(config)
    
    # CRUD Operations
    
    def save(self, game: Game) -> Game:
        """
        Save a game to the repository.
        
        Args:
            game: The game to save
            
        Returns:
            The saved game with updated fields
        """
        # Ensure the game has an ID
        if not hasattr(game, 'gameId') or game.gameId is None:
            game.gameId = uuid4()
        
        # Store the game in our dictionary
        self.games[game.gameId] = game
        return game
    
    def delete(self, game_id: UUID) -> bool:
        """
        Delete a game from the repository.
        
        Args:
            game_id: ID of the game to delete
            
        Returns:
            True if the game was deleted, False otherwise
        """
        if game_id in self.games:
            del self.games[game_id]
            return True
        return False
    
    # Query Operations
    
    def find_by_id(self, game_id: UUID) -> Optional[Game]:
        """
        Find a game by ID.
        
        Args:
            game_id: ID of the game to find
            
        Returns:
            The game if found, None otherwise
        """
        return self.games.get(game_id)
    
    def find_by_teams(self, home_team: Optional[str] = None, away_team: Optional[str] = None) -> List[Game]:
        """
        Find games by teams.
        
        Args:
            home_team: Optional home team name to filter by
            away_team: Optional away team name to filter by
            
        Returns:
            List of games matching the criteria
        """
        results = []
        for game in self.games.values():
            if (home_team is None or game.homeTeam == home_team) and \
               (away_team is None or game.awayTeam == away_team):
                results.append(game)
        return results
    
    def find_by_date_range(self, start_date: datetime, end_date: datetime) -> List[Game]:
        """
        Find games within a date range.
        
        Args:
            start_date: Start of the date range
            end_date: End of the date range
            
        Returns:
            List of games within the date range
        """
        results = []
        for game in self.games.values():
            if start_date <= game.startTime <= end_date:
                results.append(game)
        return results
    
    def find_by_stadium(self, stadium_id: UUID) -> List[Game]:
        """
        Find games at a specific stadium.
        
        Args:
            stadium_id: ID of the stadium
            
        Returns:
            List of games at the stadium
        """
        results = []
        for game in self.games.values():
            if game.stadium.stadiumId == stadium_id:
                results.append(game)
        return results
    
    def find_by_high_demand(self, is_high_demand: bool) -> List[Game]:
        """
        Find games by high demand status.
        
        Args:
            is_high_demand: Whether to find high demand games (True) or not (False)
            
        Returns:
            List of games matching the high demand criteria
        """
        results = []
        for game in self.games.values():
            if game.isHighDemand == is_high_demand:
                results.append(game)
        return results
    
    def find_by_status(self, status: str) -> List[Game]:
        """
        Find games by status.
        
        Args:
            status: Status to filter by (e.g., "SCHEDULED", "CANCELLED")
            
        Returns:
            List of games with the specified status
        """
        results = []
        for game in self.games.values():
            if game.status == status:
                results.append(game)
        return results
    
    def find_by_game_and_status(self, game_id: UUID, status: str) -> List[Ticket]:
        """
        Find tickets for a game with a specific status.
        
        Args:
            game_id: ID of the game
            status: Status to filter by
            
        Returns:
            List of tickets matching the criteria
        """
        return self.ticket_service.find_by_game_and_status(game_id, status)
    
    def find_all(self) -> List[Game]:
        """
        Find all games.
        
        Returns:
            List of all games
        """
        return list(self.games.values())
    
    # Business Logic
    
    def create_game(
        self, 
        home_team: str, 
        away_team: str, 
        start_time: datetime, 
        stadium: Stadium,
        is_high_demand: Optional[bool] = None
    ) -> Game:
        """
        Create a new game.
        
        Args:
            home_team: Name of the home team
            away_team: Name of the away team
            start_time: Start time of the game
            stadium: Stadium where the game will be played
            is_high_demand: Override automatic high demand detection
            
        Returns:
            The created Game object
        """
        # Auto-detect high demand games based on teams
        if is_high_demand is None:
            is_high_demand = self._is_high_demand_game(home_team, away_team)
        
        # Create the game
        game = Game(
            gameId=uuid4(),
            homeTeam=home_team,
            awayTeam=away_team,
            startTime=start_time,
            stadium=stadium,
            isHighDemand=is_high_demand,
            status="SCHEDULED",
            tickets=[]
        )
        
        # Save the game
        return self.save(game)
    
    def _is_high_demand_game(self, home_team: str, away_team: str) -> bool:
        """
        Determine if a game is high-demand based on the teams playing.
        
        Args:
            home_team: Name of the home team
            away_team: Name of the away team
            
        Returns:
            True if the game is high-demand, False otherwise
        """
        high_demand_teams = self.config['high_demand_teams']
        return home_team in high_demand_teams or away_team in high_demand_teams
    
    def generate_tickets_for_game(
        self, 
        game_id: UUID, 
        base_prices: Dict[str, float]
    ) -> List[Ticket]:
        """
        Generate tickets for all seats in a game's stadium.
        
        Args:
            game_id: ID of the game to generate tickets for
            base_prices: Dictionary mapping seat types to base prices
            
        Returns:
            List of generated tickets
            
        Raises:
            ValueError: If the game doesn't exist
        """
        game = self.find_by_id(game_id)
        if not game:
            raise ValueError(f"Game with ID {game_id} not found")
        
        tickets = []
        
        # Get all seats from the stadium
        seats = game.stadium.seatingLayout.seats
        
        # Create a ticket for each seat
        for seat in seats:
            # Determine base price based on seat type
            base_price = base_prices.get(seat.seatType, 50.0)  # Default price if type not specified
            
            # Apply high-demand pricing if applicable
            if game.isHighDemand and self.pricing_service:
                price = self.pricing_service.calculate_high_demand_price(base_price)
            else:
                price = base_price
            
            # Create the ticket (initially unavailable)
            ticket = Ticket(
                ticketId=uuid4(),
                event_id=game.gameId,
                seat_id=seat.seatId,
                price=price,
                original_price=base_price,
                owner_id=None,  # No owner initially
                is_resellable=True,  # Default to allowing resale
                status=TicketStatus.AVAILABLE.value if self._should_be_available(game) else "UNAVAILABLE",
                reserved_until=None
            )
            
            # Save the ticket using the ticket service
            saved_ticket = self.ticket_service.save(ticket)
            tickets.append(saved_ticket)
            
            # Add ticket to game's tickets list
            game.tickets.append(saved_ticket.ticketId)
        
        # Update the game with the tickets
        self.save(game)
        
        return tickets
    
    def _should_be_available(self, game: Game) -> bool:
        """
        Determine if tickets for a game should be available based on the game date.
        
        Args:
            game: The game to check
            
        Returns:
            True if tickets should be available, False otherwise
        """
        days_before = self.config['tickets_available_days_before']
        availability_date = game.startTime - timedelta(days=days_before)
        return datetime.now() >= availability_date
    
    def make_tickets_available_for_upcoming_games(self) -> int:
        """
        Make tickets available for games happening in the configured number of days.
        
        Returns:
            Number of games for which tickets were made available
        """
        days_before = self.config['tickets_available_days_before']
        target_date = datetime.now() + timedelta(days=days_before)
        
        # Find games happening on the target date
        upcoming_games = self.find_by_date_range(
            target_date.replace(hour=0, minute=0, second=0),
            target_date.replace(hour=23, minute=59, second=59)
        )
        
        count = 0
        for game in upcoming_games:
            # Find all tickets for this game that are not yet available
            unavailable_tickets = self.ticket_service.find_by_game_and_status(
                game.gameId, 
                "UNAVAILABLE"
            )
            
            # Make tickets available
            for ticket in unavailable_tickets:
                ticket.status = TicketStatus.AVAILABLE.value
                self.ticket_service.save(ticket)
            
            if unavailable_tickets:
                count += 1
                print(f"Made {len(unavailable_tickets)} tickets available for game: {game.homeTeam} vs {game.awayTeam}")
        
        return count
    
    def update_game_details(
        self, 
        game_id: UUID, 
        updates: Dict[str, Any]
    ) -> Optional[Game]:
        """
        Update details of a game.
        
        Args:
            game_id: ID of the game to update
            updates: Dictionary of fields to update
            
        Returns:
            Updated game or None if game not found
        """
        game = self.find_by_id(game_id)
        if not game:
            return None
        
        # Apply updates
        for key, value in updates.items():
            if hasattr(game, key):
                setattr(game, key, value)
        
        # If high demand status changed, update ticket prices
        if 'isHighDemand' in updates and self.pricing_service:
            self._update_ticket_prices_for_game(game)
        
        # Save the updated game
        return self.save(game)
    
    def _update_ticket_prices_for_game(self, game: Game) -> None:
        """
        Update ticket prices for a game based on high demand status.
        
        Args:
            game: The game to update prices for
        """
        if not self.pricing_service or not self.config['dynamic_pricing_enabled']:
            return
        
        tickets = self.ticket_service.find_by_game(game.gameId)
        for ticket in tickets:
            if ticket.status == TicketStatus.AVAILABLE.value:
                new_price = self.pricing_service.calculate_dynamic_price(ticket)
                if new_price != ticket.price:
                    ticket.price = new_price
                    self.ticket_service.save(ticket)
    
    def cancel_game(self, game_id: UUID) -> bool:
        """
        Cancel a game and handle related tickets.
        
        Args:
            game_id: ID of the game to cancel
            
        Returns:
            True if game was cancelled, False otherwise
        """
        game = self.find_by_id(game_id)
        if not game:
            return False
        
        # Update game status
        game.status = "CANCELLED"
        self.save(game)
        
        # Handle tickets (mark as cancelled)
        tickets = self.ticket_service.find_by_game(game_id)
        for ticket in tickets:
            ticket.status = TicketStatus.CANCELLED.value
            self.ticket_service.save(ticket)
        
        return True
    
    def get_game_statistics(self, game_id: UUID) -> Dict[str, Any]:
        """
        Get statistics about ticket sales for a game.
        
        Args:
            game_id: ID of the game
            
        Returns:
            Dictionary with statistics
        """
        game = self.find_by_id(game_id)
        if not game:
            return {}
        
        tickets = self.ticket_service.find_by_game(game_id)
        
        # Count tickets by status
        status_counts = {}
        for ticket in tickets:
            status = ticket.status
            status_counts[status] = status_counts.get(status, 0) + 1
        
        # Calculate total revenue
        sold_tickets = [t for t in tickets if t.status == TicketStatus.SOLD.value]
        total_revenue = sum(t.price for t in sold_tickets)
        
        # Calculate sell-through rate
        total_tickets = len(tickets)
        sell_through_rate = len(sold_tickets) / total_tickets if total_tickets > 0 else 0
        
        return {
            "game_id": str(game_id),
            "home_team": game.homeTeam,
            "away_team": game.awayTeam,
            "start_time": game.startTime.isoformat(),
            "is_high_demand": game.isHighDemand,
            "total_tickets": total_tickets,
            "tickets_by_status": status_counts,
            "total_revenue": total_revenue,
            "sell_through_rate": sell_through_rate
        }
    
    def search_games(self, criteria: Dict[str, Any]) -> List[Game]:
        """
        Search for games based on multiple criteria.
        
        Args:
            criteria: Dictionary of search criteria
                Possible keys:
                - home_team: String
                - away_team: String
                - start_date: datetime
                - end_date: datetime
                - stadium_id: UUID
                - is_high_demand: bool
                - status: String
                - city: String
                
        Returns:
            List of games matching the criteria
        """
        results = self.find_all()
        
        # Filter by home team
        if 'home_team' in criteria and criteria['home_team']:
            results = [g for g in results if g.homeTeam == criteria['home_team']]
        
        # Filter by away team
        if 'away_team' in criteria and criteria['away_team']:
            results = [g for g in results if g.awayTeam == criteria['away_team']]
        
        # Filter by date range
        if 'start_date' in criteria and criteria['start_date']:
            results = [g for g in results if g.startTime >= criteria['start_date']]
        
        if 'end_date' in criteria and criteria['end_date']:
            results = [g for g in results if g.startTime <= criteria['end_date']]
        
        # Filter by stadium
        if 'stadium_id' in criteria and criteria['stadium_id']:
            results = [g for g in results if g.stadium.stadiumId == criteria['stadium_id']]
        
        # Filter by high demand
        if 'is_high_demand' in criteria:
            results = [g for g in results if g.isHighDemand == criteria['is_high_demand']]
        
        # Filter by status
        if 'status' in criteria and criteria['status']:
            results = [g for g in results if g.status == criteria['status']]
        
        # Filter by city
        if 'city' in criteria and criteria['city']:
            results = [g for g in results if g.stadium.city == criteria['city']]
        
        return results
    
    def get_available_seats_for_game(self, game_id: UUID) -> List[Dict[str, Any]]:
        """
        Get all available seats for a game with their details.
        
        Args:
            game_id: ID of the game
            
        Returns:
            List of dictionaries with seat details
        """
        # Get all available tickets for the game
        available_tickets = self.ticket_service.find_by_game_and_status(
            game_id, 
            TicketStatus.AVAILABLE.value
        )
        
        # Get the game
        game = self.find_by_id(game_id)
        if not game:
            return []
        
        # Get seat details for each ticket
        result = []
        for ticket in available_tickets:
            # Find the seat in the stadium
            seat = None
            for s in game.stadium.seatingLayout.seats:
                if s.seatId == ticket.seat_id:
                    seat = s
                    break
            
            if seat:
                result.append({
                    "ticket_id": str(ticket.ticketId),
                    "seat_id": str(seat.seatId),
                    "section": seat.section,
                    "row": seat.row,
                    "number": seat.number,
                    "type": seat.seatType,
                    "price": ticket.price
                })
        
        return result
