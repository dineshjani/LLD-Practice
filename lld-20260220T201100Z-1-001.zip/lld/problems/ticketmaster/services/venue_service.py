from typing import Dict, List, Optional, Any
from uuid import UUID

from ..models.venue import Venue
from ..models.seat import Seat
from ..services.seat_availability_service import SeatAvailabilityService

class VenueService:
    """Service for managing venues."""
    
    def __init__(self, seat_service: SeatAvailabilityService):
        self.venue:List[Venue] = []
        self.seat_service = seat_service
    
    def create_venue(self, venue_data: Dict[str, Any]) -> Venue:
        """Create a new venue."""
        venue = Venue(
            name=venue_data.get("name", ""),
            address=venue_data.get("address", ""),
            city=venue_data.get("city", ""),
            state=venue_data.get("state", ""),
            country=venue_data.get("country", ""),
            capacity=venue_data.get("capacity", 0),
            seating_layout=venue_data.get("seating_layout", {})
        )
        
        return self.save(venue)
    
    def get_venue(self, venue_id: UUID) -> Optional[Venue]:
        """Get a venue by ID."""
        return self.venue_repository.find_by_id(venue_id)
    
    def update_venue(self, venue_id: UUID, venue_data: Dict[str, Any]) -> Optional[Venue]:
        """Update an existing venue."""
        venue = self.venue_repository.find_by_id(venue_id)
        if not venue:
            return None
        
        # Update venue fields
        for key, value in venue_data.items():
            if hasattr(venue, key):
                setattr(venue, key, value)
        
        return self.save(venue)
    
    def delete_venue(self, venue_id: UUID) -> bool:
        """Delete a venue."""
        return self.venue_repository.delete(venue_id)
    
    def search_venues(self, 
                     name: Optional[str] = None,
                     city: Optional[str] = None,
                     state: Optional[str] = None,
                     country: Optional[str] = None) -> List[Venue]:
        """Search for venues based on criteria."""
        filters = {}
        
        if name:
            filters["name"] = name
        
        if city:
            filters["city"] = city
        
        if state:
            filters["state"] = state
        
        if country:
            filters["country"] = country
        
        return self.find_by_filters(filters)
    
    def get_seating_layout(self, venue_id: UUID) -> Dict[str, Any]:
        """Get the seating layout for a venue."""
        venue = self.venue_repository.find_by_id(venue_id)
        if not venue:
            return {}
        
        return venue.seating_layout
    
    def create_seats_for_venue(self, venue_id: UUID, seats_data: List[Dict[str, Any]]) -> List[Seat]:
        """Create seats for a venue based on the provided data."""
        venue = self.venue_repository.find_by_id(venue_id)
        if not venue:
            raise ValueError(f"Venue {venue_id} not found")
        
        seats = []
        for seat_data in seats_data:
            seat = Seat(
                venue_id=venue_id,
                section=seat_data.get("section", ""),
                row=seat_data.get("row", ""),
                number=seat_data.get("number", ""),
                category=seat_data.get("category", "GENERAL"),
                is_accessible=seat_data.get("is_accessible", False),
                base_price=seat_data.get("base_price", 0.0)
            )
            
            seats.append(self.seat_service.save(seat))
        
        return seats 