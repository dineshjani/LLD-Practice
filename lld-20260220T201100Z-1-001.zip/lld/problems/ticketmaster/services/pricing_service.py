from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
from uuid import UUID

from ..models.ticket import Ticket
from ..models.game import Game
from ..models.queue import Queue
from ..services.ticket_service import TicketService
from ..services.game_service import GameService
from ..repositories.ticket_repository import TicketRepository
from ..repositories.queue_repository import QueueRepository

class PricingService:
    """
    Service for managing dynamic pricing and related pricing strategies.
    
    This service handles:
    - Dynamic pricing based on demand
    - Season pass discounts
    - Special event pricing
    """
    
    def __init__(
        self, 
        ticket_service: TicketService,
        ticket_repository: TicketRepository,
        game_service: GameService,
        queue_repository: QueueRepository,
        config: Dict[str, Any] = None
    ):
        self.ticket_service = ticket_service
        self.ticket_repository = ticket_repository
        self.game_service = game_service
        self.queue_repository = queue_repository
        
        # Default configuration
        self.config = {
            'demand_threshold': 0.7,  # 70% of tickets sold triggers price increase
            'max_price_increase': 0.5,  # Maximum 50% price increase
            'season_pass_discounts': {
                10: 0.3,  # 30% discount for 10+ events
                5: 0.2,   # 20% discount for 5-9 events
                3: 0.1    # 10% discount for 3-4 events
            },
            'high_demand_price_multiplier': 1.2  # 20% increase for high-demand games
        }
        
        # Override defaults with provided config
        if config:
            self.config.update(config)
    
    def calculate_dynamic_price(self, ticket: Ticket) -> float:
        """
        Calculate the dynamic price for a ticket based on demand.
        
        Args:
            ticket: The ticket to calculate price for
            
        Returns:
            The calculated price based on current demand
            
        Raises:
            ValueError: If ticket or event_id is invalid
        """
        if not ticket:
            raise ValueError("Ticket cannot be None")
            
        event_id = ticket.event_id
        if not event_id:
            raise ValueError("Ticket must have a valid event_id")
            
        base_price = ticket.original_price
        
        try:
            # Get demand metrics for the event
            demand_ratio = self._calculate_demand_ratio(event_id)
            
            # Apply dynamic pricing based on demand
            if demand_ratio >= self.config['demand_threshold']:
                # Calculate price increase factor (ranges from 0% to max_price_increase%)
                available_range = 1 - self.config['demand_threshold']
                current_position = demand_ratio - self.config['demand_threshold']
                ratio = current_position / available_range if available_range > 0 else 0
                
                price_increase_factor = 1 + (ratio * self.config['max_price_increase'])
                return round(base_price * price_increase_factor, 2)
            
            # Check if this is a high-demand game
            game = self.game_service.find_by_id(ticket.event_id)
            if game and game.is_high_demand:
                return round(base_price * self.config['high_demand_price_multiplier'], 2)
                
            return base_price
            
        except Exception as e:
            # Log the error
            print(f"Error calculating dynamic price: {str(e)}")
            # Return base price as fallback
            return base_price
    
    def _calculate_demand_ratio(self, event_id: UUID) -> float:
        """
        Calculate the ratio of sold tickets to total tickets for an event.
        
        Args:
            event_id: The ID of the event
            
        Returns:
            Ratio of sold tickets (0.0 to 1.0)
        """
        # Get total and sold tickets for the event
        all_tickets = self.ticket_repository.find_by_event(event_id)
        if not all_tickets:
            return 0.0
            
        sold_tickets = [t for t in all_tickets if t.status in ["SOLD", "RESALE"]]
        
        # Calculate demand ratio
        total_tickets = len(all_tickets)
        sold_count = len(sold_tickets)
        
        return sold_count / total_tickets if total_tickets > 0 else 0.0
    
    def update_prices_for_event(self, event_id: UUID) -> Tuple[int, float]:
        """
        Update prices for all available tickets for an event based on demand.
        
        Args:
            event_id: The ID of the event to update prices for
            
        Returns:
            Tuple containing (number of tickets updated, average price increase)
        """
        available_tickets = self.ticket_repository.find_by_event_and_status(event_id, "AVAILABLE")
        
        count = 0
        total_price_change = 0.0
        
        for ticket in available_tickets:
            old_price = ticket.price
            new_price = self.calculate_dynamic_price(ticket)
            
            if abs(new_price - old_price) > 0.01:  # Avoid floating point comparison issues
                ticket.price = new_price
                self.ticket_repository.save(ticket)
                count += 1
                total_price_change += (new_price - old_price)
        
        avg_price_change = total_price_change / count if count > 0 else 0.0
        return count, avg_price_change
    
    def apply_season_pass_discount(self, base_price: float, num_events: int) -> float:
        """
        Calculate discounted price for season pass.
        
        Args:
            base_price: The base price per event
            num_events: Number of events in the season pass
            
        Returns:
            Discounted price per event
        """
        # Apply discount based on number of events
        for threshold, discount in sorted(self.config['season_pass_discounts'].items(), reverse=True):
            if num_events >= threshold:
                return round(base_price * (1 - discount), 2)
        
        return base_price
    
    def calculate_bulk_purchase_discount(self, base_price: float, quantity: int) -> float:
        """
        Calculate discount for bulk ticket purchases.
        
        Args:
            base_price: The base price per ticket
            quantity: Number of tickets being purchased
            
        Returns:
            Discounted price per ticket
        """
        if quantity >= 20:
            return round(base_price * 0.85, 2)  # 15% discount
        elif quantity >= 10:
            return round(base_price * 0.9, 2)   # 10% discount
        elif quantity >= 5:
            return round(base_price * 0.95, 2)  # 5% discount
        else:
            return base_price

    # This would be part of the ticket purchasing flow
    def enter_queue_for_high_demand_game(self, user_id: UUID, game_id: UUID):
        game = self.game_service.find_by_id(game_id)
        if game and game.isHighDemand:
            # Find or create queue for this game
            queue = self.find_queue_by_game(game_id)
            if not queue:
                queue = Queue(game)
                self.save_queue(queue)
            
            # Add user to queue if not already in it
            if user_id not in queue.userIds:
                queue.userIds.append(user_id)
                self.save_queue(queue)
            
            # Return queue position
            return queue.userIds.index(user_id) + 1
        
        # No queue needed for regular games
        return 0