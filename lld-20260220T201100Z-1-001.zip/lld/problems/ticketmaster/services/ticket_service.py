from typing import List, Dict, Optional, Any, Tuple
from uuid import UUID, uuid4
from datetime import datetime, timedelta
from enum import Enum

from ..models.ticket import Ticket, TicketStatus
from ..models.event import Event
from ..models.seat import Seat
from ..exceptions.ticket_exceptions import TicketNotFoundException, TicketNotAvailableException

class TicketService:
    """
    Service for managing tickets throughout their lifecycle.
    
    This service handles:
    - Creating and retrieving tickets
    - Managing ticket status (available, reserved, sold, etc.)
    - Handling ticket reservations and expiration
    - Ticket transfers and refunds
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        self.tickets: Dict[UUID, Ticket] = {}  # Store tickets by ID for O(1) lookup
        self.event_tickets: Dict[UUID, List[UUID]] = {}  # Map event IDs to ticket IDs
        self.user_tickets: Dict[UUID, List[UUID]] = {}  # Map user IDs to ticket IDs
        self.seat_tickets: Dict[Tuple[UUID, UUID], UUID] = {}  # Map (event_id, seat_id) to ticket_id
        
        # Default configuration
        self.config = {
            'reservation_timeout_minutes': 15,  # Default reservation timeout
            'max_tickets_per_user': 8,  # Maximum tickets a user can purchase per event
            'enable_waiting_list': True,  # Enable waiting list for sold-out events
            'enable_resale': True  # Allow ticket resale
        }
        
        # Override defaults with provided config
        if config:
            self.config.update(config)
    
    # CRUD Operations
    
    def create_ticket(
        self, 
        event_id: UUID, 
        seat_id: UUID, 
        price: float, 
        ticket_type: str = "STANDARD"
    ) -> Ticket:
        """
        Create a new ticket for an event and seat.
        
        Args:
            event_id: ID of the event
            seat_id: ID of the seat
            price: Original price of the ticket
            ticket_type: Type of ticket (STANDARD, VIP, etc.)
            
        Returns:
            The created ticket
            
        Raises:
            ValueError: If a ticket already exists for this event and seat
        """
        # Check if ticket already exists for this seat
        if (event_id, seat_id) in self.seat_tickets:
            raise ValueError(f"Ticket already exists for event {event_id} and seat {seat_id}")
        
        # Create new ticket
        ticket = Ticket(
            ticket_id=uuid4(),
            event_id=event_id,
            seat_id=seat_id,
            price=price,
            original_price=price,
            status=TicketStatus.AVAILABLE,
            ticket_type=ticket_type,
            created_at=datetime.now()
        )
        
        return self.save(ticket)
    
    def find_by_id(self, ticket_id: UUID) -> Optional[Ticket]:
        """
        Find a ticket by ID.
        
        Args:
            ticket_id: ID of the ticket to find
            
        Returns:
            The ticket if found, None otherwise
        """
        return self.tickets.get(ticket_id)
    
    def save(self, ticket: Ticket) -> Ticket:
        """
        Save a ticket to the repository.
        
        Args:
            ticket: The ticket to save
            
        Returns:
            The saved ticket with updated fields
        """
        # Ensure the ticket has an ID
        if not hasattr(ticket, 'ticket_id') or ticket.ticket_id is None:
            ticket.ticket_id = uuid4()
        
        # Update last modified timestamp
        ticket.last_modified = datetime.now()
        
        # Store the ticket
        self.tickets[ticket.ticket_id] = ticket
        
        # Update indexes
        if ticket.event_id:
            if ticket.event_id not in self.event_tickets:
                self.event_tickets[ticket.event_id] = []
            if ticket.ticket_id not in self.event_tickets[ticket.event_id]:
                self.event_tickets[ticket.event_id].append(ticket.ticket_id)
        
        if hasattr(ticket, 'owner_id') and ticket.owner_id:
            if ticket.owner_id not in self.user_tickets:
                self.user_tickets[ticket.owner_id] = []
            if ticket.ticket_id not in self.user_tickets[ticket.owner_id]:
                self.user_tickets[ticket.owner_id].append(ticket.ticket_id)
        
        if ticket.event_id and hasattr(ticket, 'seat_id') and ticket.seat_id:
            self.seat_tickets[(ticket.event_id, ticket.seat_id)] = ticket.ticket_id
        
        return ticket
    
    def delete(self, ticket_id: UUID) -> bool:
        """
        Delete a ticket from the repository.
        
        Args:
            ticket_id: ID of the ticket to delete
            
        Returns:
            True if the ticket was deleted, False otherwise
        """
        if ticket_id not in self.tickets:
            return False
        
        ticket = self.tickets[ticket_id]
        
        # Remove from indexes
        if ticket.event_id and ticket.event_id in self.event_tickets:
            if ticket_id in self.event_tickets[ticket.event_id]:
                self.event_tickets[ticket.event_id].remove(ticket_id)
        
        if hasattr(ticket, 'owner_id') and ticket.owner_id and ticket.owner_id in self.user_tickets:
            if ticket_id in self.user_tickets[ticket.owner_id]:
                self.user_tickets[ticket.owner_id].remove(ticket_id)
        
        if ticket.event_id and hasattr(ticket, 'seat_id') and ticket.seat_id:
            if (ticket.event_id, ticket.seat_id) in self.seat_tickets:
                del self.seat_tickets[(ticket.event_id, ticket.seat_id)]
        
        # Remove the ticket
        del self.tickets[ticket_id]
        return True
    
    # Query Operations
    
    def find_by_event(self, event_id: UUID) -> List[Ticket]:
        """
        Find all tickets for an event.
        
        Args:
            event_id: ID of the event
            
        Returns:
            List of tickets for the event
        """
        ticket_ids = self.event_tickets.get(event_id, [])
        return [self.tickets[tid] for tid in ticket_ids if tid in self.tickets]
    
    def find_by_user(self, user_id: UUID) -> List[Ticket]:
        """
        Find all tickets owned by a user.
        
        Args:
            user_id: ID of the user
            
        Returns:
            List of tickets owned by the user
        """
        ticket_ids = self.user_tickets.get(user_id, [])
        return [self.tickets[tid] for tid in ticket_ids if tid in self.tickets]
    
    def find_by_event_and_status(self, event_id: UUID, status: str) -> List[Ticket]:
        """
        Find tickets for an event with a specific status.
        
        Args:
            event_id: ID of the event
            status: Status to filter by
            
        Returns:
            List of tickets matching the criteria
        """
        tickets = self.find_by_event(event_id)
        return [t for t in tickets if t.status == status]
    
    def find_by_event_and_seat(self, event_id: UUID, seat_id: UUID) -> Optional[Ticket]:
        """
        Find a ticket for a specific event and seat.
        
        Args:
            event_id: ID of the event
            seat_id: ID of the seat
            
        Returns:
            The ticket if found, None otherwise
        """
        ticket_id = self.seat_tickets.get((event_id, seat_id))
        if ticket_id:
            return self.tickets.get(ticket_id)
        return None
    
    def find_expired_reservations(self, now: datetime) -> List[Ticket]:
        """
        Find all tickets with expired reservations.
        
        Args:
            now: Current datetime to compare against reservation expiration
            
        Returns:
            List of tickets with expired reservations
        """
        return [
            ticket for ticket in self.tickets.values() 
            if ticket.status == TicketStatus.RESERVED.value and 
               hasattr(ticket, 'reserved_until') and 
               ticket.reserved_until and 
               ticket.reserved_until < now
        ]
    
    # Business Operations
    
    def reserve_ticket(self, ticket_id: UUID, user_id: UUID, duration_minutes: int = None) -> Ticket:
        """
        Reserve a ticket for a user.
        
        Args:
            ticket_id: ID of the ticket to reserve
            user_id: ID of the user reserving the ticket
            duration_minutes: Optional custom reservation duration
            
        Returns:
            The updated ticket
            
        Raises:
            TicketNotFoundException: If the ticket doesn't exist
            TicketNotAvailableException: If the ticket is not available
        """
        ticket = self.find_by_id(ticket_id)
        if not ticket:
            raise TicketNotFoundException(f"Ticket with ID {ticket_id} not found")
        
        if ticket.status != TicketStatus.AVAILABLE.value:
            raise TicketNotAvailableException(f"Ticket is not available. Current status: {ticket.status}")
        
        # Set reservation timeout
        if duration_minutes is None:
            duration_minutes = self.config['reservation_timeout_minutes']
        
        reservation_timeout = datetime.now() + timedelta(minutes=duration_minutes)
        
        # Update ticket
        ticket.status = TicketStatus.RESERVED.value
        ticket.reserved_until = reservation_timeout
        ticket.owner_id = user_id
        
        return self.save(ticket)
    
    def confirm_purchase(self, ticket_id: UUID, user_id: UUID, payment_id: UUID = None) -> Ticket:
        """
        Confirm purchase of a reserved ticket.
        
        Args:
            ticket_id: ID of the ticket to purchase
            user_id: ID of the user purchasing the ticket
            payment_id: Optional ID of the payment
            
        Returns:
            The updated ticket
            
        Raises:
            TicketNotFoundException: If the ticket doesn't exist
            ValueError: If the ticket is not reserved by this user
        """
        ticket = self.find_by_id(ticket_id)
        if not ticket:
            raise TicketNotFoundException(f"Ticket with ID {ticket_id} not found")
        
        if ticket.status != TicketStatus.RESERVED.value:
            raise ValueError(f"Ticket is not reserved. Current status: {ticket.status}")
        
        if ticket.owner_id != user_id:
            raise ValueError(f"Ticket is not reserved by user {user_id}")
        
        # Check if reservation has expired
        if hasattr(ticket, 'reserved_until') and ticket.reserved_until and ticket.reserved_until < datetime.now():
            raise ValueError("Ticket reservation has expired")
        
        # Update ticket
        ticket.status = TicketStatus.SOLD.value
        ticket.reserved_until = None
        if payment_id:
            ticket.payment_id = payment_id
        ticket.purchase_date = datetime.now()
        
        return self.save(ticket)
    
    def cancel_reservation(self, ticket_id: UUID) -> Ticket:
        """
        Cancel a ticket reservation.
        
        Args:
            ticket_id: ID of the ticket
            
        Returns:
            The updated ticket
            
        Raises:
            TicketNotFoundException: If the ticket doesn't exist
        """
        ticket = self.find_by_id(ticket_id)
        if not ticket:
            raise TicketNotFoundException(f"Ticket with ID {ticket_id} not found")
        
        if ticket.status != TicketStatus.RESERVED.value:
            return ticket  # Not reserved, nothing to do
        
        # Reset ticket
        ticket.status = TicketStatus.AVAILABLE.value
        ticket.reserved_until = None
        ticket.owner_id = None
        
        return self.save(ticket)
    
    def release_expired_reservations(self) -> int:
        """
        Release all expired seat reservations.
        
        Returns:
            Number of reservations released
        """
        now = datetime.now()
        expired_tickets = self.find_expired_reservations(now)
        
        count = 0
        for ticket in expired_tickets:
            ticket.status = TicketStatus.AVAILABLE.value
            ticket.reserved_until = None
            ticket.owner_id = None
            self.save(ticket)
            count += 1
        
        return count
    
    def transfer_ticket(self, ticket_id: UUID, from_user_id: UUID, to_user_id: UUID) -> Ticket:
        """
        Transfer a ticket from one user to another.
        
        Args:
            ticket_id: ID of the ticket to transfer
            from_user_id: ID of the current owner
            to_user_id: ID of the new owner
            
        Returns:
            The updated ticket
            
        Raises:
            TicketNotFoundException: If the ticket doesn't exist
            ValueError: If the ticket is not owned by from_user_id
        """
        ticket = self.find_by_id(ticket_id)
        if not ticket:
            raise TicketNotFoundException(f"Ticket with ID {ticket_id} not found")
        
        if ticket.status != TicketStatus.SOLD.value:
            raise ValueError(f"Only sold tickets can be transferred. Current status: {ticket.status}")
        
        if ticket.owner_id != from_user_id:
            raise ValueError(f"Ticket is not owned by user {from_user_id}")
        
        # Update owner
        ticket.owner_id = to_user_id
        ticket.transfer_date = datetime.now()
        
        return self.save(ticket)
    
    def list_for_resale(self, ticket_id: UUID, user_id: UUID, resale_price: float) -> Ticket:
        """
        List a ticket for resale.
        
        Args:
            ticket_id: ID of the ticket to resell
            user_id: ID of the current owner
            resale_price: Price for resale
            
        Returns:
            The updated ticket
            
        Raises:
            TicketNotFoundException: If the ticket doesn't exist
            ValueError: If the ticket is not owned by user_id or resale is not enabled
        """
        if not self.config['enable_resale']:
            raise ValueError("Ticket resale is not enabled")
        
        ticket = self.find_by_id(ticket_id)
        if not ticket:
            raise TicketNotFoundException(f"Ticket with ID {ticket_id} not found")
        
        if ticket.status != TicketStatus.SOLD.value:
            raise ValueError(f"Only sold tickets can be resold. Current status: {ticket.status}")
        
        if ticket.owner_id != user_id:
            raise ValueError(f"Ticket is not owned by user {user_id}")
        
        # Update ticket for resale
        ticket.status = TicketStatus.RESALE.value
        ticket.resale_price = resale_price
        ticket.listed_for_resale_at = datetime.now()
        
        return self.save(ticket)
    
    def get_ticket_history(self, ticket_id: UUID) -> List[Dict[str, Any]]:
        """
        Get the history of a ticket.
        
        Args:
            ticket_id: ID of the ticket
            
        Returns:
            List of history events for the ticket
            
        Raises:
            TicketNotFoundException: If the ticket doesn't exist
        """
        ticket = self.find_by_id(ticket_id)
        if not ticket:
            raise TicketNotFoundException(f"Ticket with ID {ticket_id} not found")
        
        history = []
        
        # Add creation event
        if hasattr(ticket, 'created_at'):
            history.append({
                "type": "CREATED",
                "timestamp": ticket.created_at.isoformat(),
                "details": {
                    "price": ticket.original_price,
                    "status": TicketStatus.AVAILABLE.value
                }
            })
        
        # Add purchase event
        if hasattr(ticket, 'purchase_date') and ticket.purchase_date:
            history.append({
                "type": "PURCHASED",
                "timestamp": ticket.purchase_date.isoformat(),
                "details": {
                    "user_id": str(ticket.owner_id),
                    "price": ticket.price,
                    "payment_id": str(ticket.payment_id) if hasattr(ticket, 'payment_id') and ticket.payment_id else None
                }
            })
        
        # Add transfer events
        if hasattr(ticket, 'transfer_date') and ticket.transfer_date:
            history.append({
                "type": "TRANSFERRED",
                "timestamp": ticket.transfer_date.isoformat(),
                "details": {
                    "to_user_id": str(ticket.owner_id)
                }
            })
        
        # Add resale events
        if hasattr(ticket, 'listed_for_resale_at') and ticket.listed_for_resale_at:
            history.append({
                "type": "LISTED_FOR_RESALE",
                "timestamp": ticket.listed_for_resale_at.isoformat(),
                "details": {
                    "resale_price": ticket.resale_price
                }
            })
        
        return sorted(history, key=lambda x: x["timestamp"])