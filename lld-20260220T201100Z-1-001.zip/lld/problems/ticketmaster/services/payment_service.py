from datetime import datetime
from typing import Dict, List, Optional, Any
from uuid import UUID

from ..models.payment import Payment, PaymentMethod, PaymentStatus
from ..models.booking import Booking
from ..factory.payment_gateway_factory import PaymentGatewayFactory
class PaymentService:
    """Service for managing payments."""
    
    def __init__(self, payment_gateway_factory: PaymentGatewayFactory):
        self.payments: List[Payment] = []
        self.payment_gateway_factory = payment_gateway_factory
    
    def process_payment(self, booking: Booking, payment_method: str, payment_details: Dict[str, Any]) -> Payment:
        """Process a payment for a booking."""
        # Create payment record
        payment = Payment(
            booking_id=booking.id,
            user_id=booking.user_id,
            amount=booking.total_amount,
            method=PaymentMethod(payment_method),
            status=PaymentStatus.PENDING,
            payment_time=datetime.now()
        )
        
        payment = self.save(payment)
        
        # Get appropriate payment gateway
        payment_gateway = self.payment_gateway_factory.get_gateway(payment_method)
        
        # Process payment through gateway
        try:
            transaction_id = payment_gateway.process_payment(
                amount=payment.amount,
                payment_details=payment_details
            )
            
            # Update payment with transaction ID and status
            payment.transaction_id = transaction_id
            payment.status = PaymentStatus.COMPLETED
            
        except Exception as e:
            # Payment failed
            payment.status = PaymentStatus.FAILED
        
        # Save updated payment
        return self.save(payment)
    
    def process_refund(self, payment_id: UUID) -> Payment:
        """Process a refund for a payment."""
        payment = self.find_by_id(payment_id)
        
        if not payment:
            raise ValueError(f"Payment {payment_id} not found")
        
        if payment.status != PaymentStatus.COMPLETED:
            raise ValueError(f"Payment {payment_id} is not in COMPLETED state")
        
        # Get appropriate payment gateway
        payment_gateway = self.payment_gateway_factory.get_gateway(payment.method.value)
        
        # Process refund through gateway
        try:
            payment_gateway.process_refund(
                transaction_id=payment.transaction_id,
                amount=payment.amount
            )
            
            # Update payment status
            payment.status = PaymentStatus.REFUNDED
            
        except Exception as e:
            # Refund failed
            raise ValueError(f"Refund failed: {str(e)}")
        
        # Save updated payment
        return self.save(payment)
    
    def get_payment_by_booking(self, booking_id: UUID) -> Optional[Payment]:
        """Get payment for a booking."""
        return self.find_by_booking_id(booking_id) 
    
    def save(self, payment: Payment) -> Payment:
        """Save a payment."""
        self.payments.append(payment)
        return payment
    
    def find_by_id(self, payment_id: UUID) -> Optional[Payment]:
        """Find a payment by ID."""
        return next((payment for payment in self.payments if payment.id == payment_id), None)
    
    def find_by_booking_id(self, booking_id: UUID) -> Optional[Payment]:
        """Find a payment by booking ID."""
        return next((payment for payment in self.payments if payment.booking_id == booking_id), None)