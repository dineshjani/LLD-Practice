from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from uuid import UUID

from ..models.booking import Booking, BookingStatus, PaymentStatus
from ..models.ticket import Ticket, TicketStatus
from ..models.payment import Payment
from ..models.user import User

class BookingService:
    """Service for managing bookings."""
    
    def __init__(self, payment_service, notification_service):
        self.payment_service = payment_service
        self.notification_service = notification_service
        self.reservation_timeout = timedelta(minutes=15)  # Tickets are reserved for 15 minutes
    
    def create_booking(self, user: User, tickets: List[Ticket]) -> Booking:
        """Create a booking for a user with the specified tickets."""
        total_amount = sum(ticket.price for ticket in tickets)
        
        # Reserve tickets
        for ticket in tickets:
            if ticket.status != TicketStatus.AVAILABLE:
                raise ValueError(f"Ticket {ticket.ticketId} is not available")
            ticket.status = TicketStatus.RESERVED
            ticket.reserved_until = datetime.now() + self.reservation_timeout
            ticket.ownerId = user.userId
        
        # Create booking
        booking = Booking(
            user=user,
            tickets=tickets,
            paymentStatus=PaymentStatus.PENDING,
            timestamp=datetime.now()
        )
        
        # Notify user
        self.notification_service.send_booking_confirmation(user, booking)
        
        return booking
    
    def confirm_booking(self, booking: Booking, payment_method: str, payment_details: Dict[str, Any]) -> Booking:
        """Confirm a booking after payment."""
        if not booking:
            raise ValueError("Booking not found")
        
        # Process payment
        payment_successful = self.payment_service.process_payment(payment_method, payment_details, booking)
        
        if payment_successful:
            booking.paymentStatus = PaymentStatus.SUCCESS
            
            # Update tickets to booked status
            for ticket in booking.tickets:
                ticket.status = TicketStatus.BOOKED
                ticket.qrCode = f"QR-{ticket.ticketId}-{datetime.now().timestamp()}"
        else:
            booking.paymentStatus = PaymentStatus.FAILED
            
            # Release tickets
            for ticket in booking.tickets:
                ticket.status = TicketStatus.AVAILABLE
                ticket.reserved_until = None
                ticket.ownerId = None
        
        # Notify user
        self.notification_service.send_payment_confirmation(booking.user, booking)
        
        return booking
    
    def cancel_booking(self, booking_id: UUID) -> Booking:
        """Cancel a booking and release tickets."""
        booking = self.find_by_id(booking_id)
        
        if not booking:
            raise ValueError(f"Booking {booking_id} not found")
        
        if booking.status not in [BookingStatus.PENDING, BookingStatus.CONFIRMED]:
            raise ValueError(f"Booking {booking_id} cannot be cancelled")
        
        # If payment was made, process refund
        if booking.payment_id:
            self.payment_service.process_refund(booking.payment_id)
        
        # Update booking status
        booking.status = BookingStatus.CANCELLED
        booking = self.save(booking)
        
        # Release tickets
        for ticket_id in booking.ticket_ids:
            ticket = self.ticket_service.find_by_id(ticket_id)
            if ticket:
                ticket.status = TicketStatus.AVAILABLE
                ticket.reserved_until = None
                ticket.owner_id = None
                ticket.booking_id = None
                self.ticket_service.save(ticket)
        
        # Send cancellation notification
        self.notification_service.send_booking_cancellation(booking)
        
        return booking
    
    def get_user_bookings(self, user_id: UUID) -> List[Booking]:
        """Get all bookings for a user."""
        return self.find_by_user_id(user_id) 