from typing import List
from uuid import UUID
from datetime import datetime, timedelta
from ..models.event import Event
from ..models.ticket import Ticket
from ..models.ticket import TicketStatus
from typing import Dict, Any

class EventService:
    def __init__(self):
        self.event: List[Event] = []
    
    def save(self, event: Event) -> Event:
        self.event.append(event)
        return event
    
    def find_by_id(self, event_id: UUID) -> Event:
        return next((event for event in self.event if event.id == event_id), None)
    
    def find_by_filters(self, filters: Dict[str, Any]) -> List[Event]:
        return [event for event in self.event if all(getattr(event, key) == value for key, value in filters.items())]
    
    def find_by_event_and_status(self, event_id: UUID, status: TicketStatus) -> List[Ticket]:
        return [ticket for ticket in self.ticket if ticket.event_id == event_id and ticket.status == status]

    def make_tickets_available_for_upcoming_games(self):
        """Make tickets available for games happening in 2 days."""
        two_days_from_now = datetime.now() + timedelta(days=2)
        upcoming_games = [
            game for game in self.games 
            if game.startTime.date() == two_days_from_now.date()
        ]
        
        for game in upcoming_games:
            for ticket in game.tickets:
                ticket.status = TicketStatus.AVAILABLE
                self.ticket_service.save(ticket)
            
            print(f"Made tickets available for game: {game.homeTeam} vs {game.awayTeam}")
