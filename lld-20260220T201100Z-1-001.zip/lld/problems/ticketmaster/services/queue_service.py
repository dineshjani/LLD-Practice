from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from uuid import UUID, uuid4

from ..models.queue import Queue
from ..models.event import Game
from ..models.user import User
from ..services.game_service import GameService

class QueueService:
    """
    Service for managing virtual queues for high-demand events.
    
    This service handles:
    - Creating and managing queues for high-demand games
    - Adding users to queues
    - Processing users through queues
    - Queue position notifications
    """
    
    def __init__(
        self,
        game_service: GameService,
        config: Dict[str, Any] = None
    ):
        self.game_service = game_service
        self.queues = {}  # Dictionary to store queues by ID
        self.game_queues = {}  # Dictionary to map game IDs to queue IDs
        
        # Default configuration
        self.config = {
            'queue_batch_size': 100,  # Process users in batches of 100
            'queue_processing_interval': 60,  # Process a batch every 60 seconds
            'queue_timeout': 300,  # Users have 5 minutes to purchase after being admitted
            'max_queue_size': 10000  # Maximum users in a queue
        }
        
        # Override defaults with provided config
        if config:
            self.config.update(config)
    
    # CRUD Operations
    
    def save(self, queue: Queue) -> Queue:
        """
        Save a queue to the repository.
        
        Args:
            queue: The queue to save
            
        Returns:
            The saved queue with updated fields
        """
        # Ensure the queue has an ID
        if not hasattr(queue, 'queue_id') or queue.queue_id is None:
            queue.queue_id = uuid4()
        
        # Store the queue in our dictionaries
        self.queues[queue.queue_id] = queue
        
        # Map game ID to queue ID for easy lookup
        if hasattr(queue, 'game') and queue.game and hasattr(queue.game, 'gameId'):
            self.game_queues[queue.game.gameId] = queue.queue_id
        
        return queue
    
    def delete(self, queue_id: UUID) -> bool:
        """
        Delete a queue from the repository.
        
        Args:
            queue_id: ID of the queue to delete
            
        Returns:
            True if the queue was deleted, False otherwise
        """
        if queue_id in self.queues:
            queue = self.queues[queue_id]
            
            # Remove game to queue mapping
            if hasattr(queue, 'game') and queue.game and hasattr(queue.game, 'gameId'):
                if queue.game.gameId in self.game_queues:
                    del self.game_queues[queue.game.gameId]
            
            # Remove the queue
            del self.queues[queue_id]
            return True
        return False
    
    # Query Operations
    
    def find_by_id(self, queue_id: UUID) -> Optional[Queue]:
        """
        Find a queue by ID.
        
        Args:
            queue_id: ID of the queue to find
            
        Returns:
            The queue if found, None otherwise
        """
        return self.queues.get(queue_id)
    
    def find_by_game_id(self, game_id: UUID) -> Optional[Queue]:
        """
        Find a queue by game ID.
        
        Args:
            game_id: ID of the game to find the queue for
            
        Returns:
            The queue if found, None otherwise
        """
        queue_id = self.game_queues.get(game_id)
        if queue_id:
            return self.queues.get(queue_id)
        return None
    
    def find_all(self) -> List[Queue]:
        """
        Find all queues.
        
        Returns:
            List of all queues
        """
        return list(self.queues.values())
    
    def find_active_queues(self) -> List[Queue]:
        """
        Find all active queues (queues with waiting users).
        
        Returns:
            List of active queues
        """
        return [q for q in self.queues.values() if q.user_ids]
    
    # Queue Management
    
    def enter_queue_for_high_demand_game(self, user_id: UUID, game_id: UUID) -> Dict[str, Any]:
        """
        Add a user to the queue for a high-demand game.
        
        Args:
            user_id: The ID of the user to add to the queue
            game_id: The ID of the game to queue for
            
        Returns:
            Dictionary with queue information including position and estimated wait time
            
        Raises:
            ValueError: If the game is not high-demand or doesn't exist
        """
        # Verify the game exists and is high-demand
        game = self.game_service.find_by_id(game_id)
        if not game:
            raise ValueError(f"Game with ID {game_id} not found")
            
        if not game.is_high_demand:
            # No queue needed for regular games
            return {
                'in_queue': False,
                'message': 'No queue required for this game'
            }
        
        # Find or create queue for this game
        queue = self.find_by_game_id(game_id)
        if not queue:
            queue = Queue(
                game=game,
                created_at=datetime.now()
            )
            # Initialize queue properties
            queue.user_ids = []
            queue.admitted_users = []
            queue.admission_times = {}
            queue.last_updated = datetime.now()
            queue.last_processed = None
            self.save(queue)
        
        # Check if queue is at capacity
        if len(queue.user_ids) >= self.config['max_queue_size']:
            return {
                'in_queue': False,
                'position': -1,
                'message': 'Queue is at maximum capacity. Please try again later.'
            }
        
        # Add user to queue if not already in it
        if user_id not in queue.user_ids:
            queue.user_ids.append(user_id)
            queue.last_updated = datetime.now()
            self.save(queue)
        
        # Get user's position in queue
        position = queue.user_ids.index(user_id) + 1
        
        # Calculate estimated wait time
        estimated_wait_minutes = self._calculate_wait_time(position)
        
        return {
            'in_queue': True,
            'queue_id': str(queue.queue_id),
            'position': position,
            'total_in_queue': len(queue.user_ids),
            'estimated_wait_minutes': estimated_wait_minutes,
            'message': f'You are in position {position}. Estimated wait: {estimated_wait_minutes} minutes.'
        }
    
    def _calculate_wait_time(self, position: int) -> int:
        """
        Calculate estimated wait time based on queue position.
        
        Args:
            position: User's position in queue
            
        Returns:
            Estimated wait time in minutes
        """
        batch_size = self.config['queue_batch_size']
        interval_seconds = self.config['queue_processing_interval']
        
        # Calculate which batch the user is in
        batch_number = (position - 1) // batch_size + 1
        
        # Calculate wait time in minutes
        wait_seconds = batch_number * interval_seconds
        wait_minutes = wait_seconds // 60
        
        return max(1, wait_minutes)  # Minimum 1 minute wait
    
    def process_queue_batch(self, queue_id: UUID) -> List[UUID]:
        """
        Process the next batch of users in the queue.
        
        Args:
            queue_id: The ID of the queue to process
            
        Returns:
            List of user IDs that have been admitted from the queue
        """
        queue = self.find_by_id(queue_id)
        if not queue or not queue.user_ids:
            return []
        
        batch_size = min(self.config['queue_batch_size'], len(queue.user_ids))
        admitted_users = queue.user_ids[:batch_size]
        
        # Remove admitted users from queue
        queue.user_ids = queue.user_ids[batch_size:]
        
        # Initialize admitted_users list if it doesn't exist
        if not hasattr(queue, 'admitted_users'):
            queue.admitted_users = []
        queue.admitted_users.extend(admitted_users)
        
        # Initialize admission_times dict if it doesn't exist
        if not hasattr(queue, 'admission_times'):
            queue.admission_times = {}
        
        queue.last_processed = datetime.now()
        queue.last_updated = datetime.now()
        
        # Set expiration time for admitted users
        timeout = self.config['queue_timeout']
        expiration_time = datetime.now() + timedelta(seconds=timeout)
        
        for user_id in admitted_users:
            queue.admission_times[str(user_id)] = {
                'admitted_at': datetime.now().isoformat(),
                'expires_at': expiration_time.isoformat()
            }
        
        self.save(queue)
        return admitted_users
    
    def process_all_queues(self) -> Dict[UUID, List[UUID]]:
        """
        Process a batch for all active queues.
        
        Returns:
            Dictionary mapping queue IDs to lists of admitted user IDs
        """
        results = {}
        active_queues = self.find_active_queues()
        
        for queue in active_queues:
            admitted = self.process_queue_batch(queue.queue_id)
            if admitted:
                results[queue.queue_id] = admitted
        
        return results
    
    def check_queue_status(self, user_id: UUID, game_id: UUID) -> Dict[str, Any]:
        """
        Check a user's current status in the queue.
        
        Args:
            user_id: The ID of the user
            game_id: The ID of the game
            
        Returns:
            Dictionary with the user's current queue status
        """
        queue = self.find_by_game_id(game_id)
        if not queue:
            return {
                'in_queue': False,
                'message': 'No queue exists for this game'
            }
        
        # Check if user has been admitted
        if hasattr(queue, 'admitted_users') and user_id in queue.admitted_users:
            user_id_str = str(user_id)
            if hasattr(queue, 'admission_times') and user_id_str in queue.admission_times:
                admission_info = queue.admission_times[user_id_str]
                expires_at = datetime.fromisoformat(admission_info['expires_at'])
                
                if datetime.now() > expires_at:
                    return {
                        'in_queue': False,
                        'admitted': True,
                        'status': 'expired',
                        'message': 'Your admission has expired. Please rejoin the queue.'
                    }
                
                return {
                    'in_queue': False,
                    'admitted': True,
                    'status': 'active',
                    'expires_at': admission_info['expires_at'],
                    'message': 'You have been admitted! You can now purchase tickets.'
                }
        
        # Check if user is still in queue
        if user_id in queue.user_ids:
            position = queue.user_ids.index(user_id) + 1
            estimated_wait_minutes = self._calculate_wait_time(position)
            
            return {
                'in_queue': True,
                'position': position,
                'total_in_queue': len(queue.user_ids),
                'estimated_wait_minutes': estimated_wait_minutes,
                'message': f'You are in position {position}. Estimated wait: {estimated_wait_minutes} minutes.'
            }
        
        return {
            'in_queue': False,
            'message': 'You are not in the queue for this game'
        }
    
    def remove_from_queue(self, user_id: UUID, game_id: UUID) -> bool:
        """
        Remove a user from the queue.
        
        Args:
            user_id: The ID of the user to remove
            game_id: The ID of the game queue
            
        Returns:
            True if user was removed, False otherwise
        """
        queue = self.find_by_game_id(game_id)
        if not queue:
            return False
        
        # Remove from waiting queue if present
        if user_id in queue.user_ids:
            queue.user_ids.remove(user_id)
            queue.last_updated = datetime.now()
            self.save(queue)
            return True
        
        # Remove from admitted list if present
        if hasattr(queue, 'admitted_users') and user_id in queue.admitted_users:
            queue.admitted_users.remove(user_id)
            # Remove admission time info
            if hasattr(queue, 'admission_times') and str(user_id) in queue.admission_times:
                del queue.admission_times[str(user_id)]
            queue.last_updated = datetime.now()
            self.save(queue)
            return True
        
        return False
    
    def clean_expired_admissions(self, queue_id: UUID) -> int:
        """
        Remove users whose admission time has expired.
        
        Args:
            queue_id: The ID of the queue to clean
            
        Returns:
            Number of expired admissions removed
        """
        queue = self.find_by_id(queue_id)
        if not queue:
            return 0
        
        now = datetime.now()
        expired_users = []
        
        # Find expired admissions
        if hasattr(queue, 'admitted_users') and hasattr(queue, 'admission_times'):
            for user_id in queue.admitted_users:
                user_id_str = str(user_id)
                if user_id_str in queue.admission_times:
                    expires_at = datetime.fromisoformat(queue.admission_times[user_id_str]['expires_at'])
                    if now > expires_at:
                        expired_users.append(user_id)
            
            # Remove expired users
            for user_id in expired_users:
                queue.admitted_users.remove(user_id)
                del queue.admission_times[str(user_id)]
            
            if expired_users:
                queue.last_updated = now
                self.save(queue)
        
        return len(expired_users)
    
    def clean_all_expired_admissions(self) -> Dict[UUID, int]:
        """
        Clean expired admissions for all queues.
        
        Returns:
            Dictionary mapping queue IDs to number of expired admissions removed
        """
        results = {}
        for queue_id in self.queues:
            count = self.clean_expired_admissions(queue_id)
            if count > 0:
                results[queue_id] = count
        return results
    
    def get_queue_statistics(self, queue_id: UUID) -> Dict[str, Any]:
        """
        Get statistics about a queue.
        
        Args:
            queue_id: ID of the queue
            
        Returns:
            Dictionary with queue statistics
        """
        queue = self.find_by_id(queue_id)
        if not queue:
            return {}
        
        waiting_count = len(queue.user_ids)
        admitted_count = len(queue.admitted_users) if hasattr(queue, 'admitted_users') else 0
        
        # Calculate average wait time
        avg_wait_time = 0
        if waiting_count > 0:
            positions = range(1, waiting_count + 1)
            wait_times = [self._calculate_wait_time(pos) for pos in positions]
            avg_wait_time = sum(wait_times) / len(wait_times)
        
        # Get game details
        game_info = {}
        if hasattr(queue, 'game') and queue.game:
            game = queue.game
            game_info = {
                'game_id': str(game.gameId),
                'home_team': game.homeTeam,
                'away_team': game.awayTeam,
                'start_time': game.startTime.isoformat() if hasattr(game, 'startTime') else None
            }
        
        return {
            'queue_id': str(queue_id),
            'game': game_info,
            'created_at': queue.created_at.isoformat() if hasattr(queue, 'created_at') else None,
            'last_updated': queue.last_updated.isoformat() if hasattr(queue, 'last_updated') else None,
            'last_processed': queue.last_processed.isoformat() if hasattr(queue, 'last_processed') else None,
            'waiting_users': waiting_count,
            'admitted_users': admitted_count,
            'total_users': waiting_count + admitted_count,
            'average_wait_time_minutes': avg_wait_time,
            'batch_size': self.config['queue_batch_size'],
            'processing_interval_seconds': self.config['queue_processing_interval']
        } 