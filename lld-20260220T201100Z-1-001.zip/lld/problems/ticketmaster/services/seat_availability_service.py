from datetime import datetime
from typing import Dict, List, Optional, Any
from uuid import UUID

from ..models.ticket import Ticket, TicketStatus
from ..services.ticket_service import TicketService
class SeatAvailabilityService:
    """Service for managing seat availability."""
    
    def __init__(self, ticket_service: TicketService):
        self.ticket_service = ticket_service
    
    def get_available_seats(self, event_id: UUID) -> List[Ticket]:
        """Get all available seats for an event."""
        return self.ticket_service.find_by_event_and_status(event_id, TicketStatus.AVAILABLE)
    
    def check_seat_availability(self, event_id: UUID, seat_id: UUID) -> bool:
        """Check if a specific seat is available for an event."""
        ticket = self.ticket_service.find_by_event_and_seat(event_id, seat_id)
        return ticket is not None and ticket.status == TicketStatus.AVAILABLE
    
    def release_expired_reservations(self) -> int:
        """Release all expired seat reservations."""
        now = datetime.now()
        expired_tickets = self.ticket_service.find_expired_reservations(now)
        
        count = 0
        for ticket in expired_tickets:
            ticket.status = TicketStatus.AVAILABLE
            ticket.reserved_until = None
            ticket.owner_id = None
            ticket.booking_id = None
            self.ticket_repository.save(ticket)
            count += 1
        
        return count
    
    def get_seat_map(self, event_id: UUID) -> Dict[str, Any]:
        """Get a map of all seats and their availability for an event."""
        all_tickets = self.ticket_service.find_by_event(event_id)
        
        seat_map = {
            "available": [],
            "reserved": [],
            "sold": [],
            "resale": []
        }
        
        for ticket in all_tickets:
            seat_info = {
                "ticket_id": str(ticket.id),
                "seat_id": str(ticket.seat_id),
                "price": ticket.price
            }
            
            if ticket.status == TicketStatus.AVAILABLE:
                seat_map["available"].append(seat_info)
            elif ticket.status == TicketStatus.RESERVED:
                seat_map["reserved"].append(seat_info)
            elif ticket.status == TicketStatus.SOLD:
                seat_map["sold"].append(seat_info)
            elif ticket.status == TicketStatus.RESALE:
                seat_map["resale"].append(seat_info)
        
        return seat_map 