from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from uuid import UUID

from ..models.user import User
from ..models.ticket import Ticket

class AntiScalpingService:
    """Service for preventing ticket scalping."""
    
    def __init__(self, ticket_repository, booking_repository, user_repository):
        self.ticket_repository = ticket_repository
        self.booking_repository = booking_repository
        self.user_repository = user_repository
        self.max_tickets_per_user = 8  # Maximum tickets a user can buy for an event
        self.max_price_increase = 1.2  # Maximum 20% price increase for resale
    
    def check_purchase_limit(self, user_id: UUID, event_id: UUID, num_tickets: int) -> bool:
        """Check if a user is within the purchase limit for an event."""
        # Get existing tickets for this user and event
        existing_tickets = self.ticket_repository.find_by_owner_and_event(user_id, event_id)
        
        # Check if adding new tickets would exceed the limit
        return len(existing_tickets) + num_tickets <= self.max_tickets_per_user
    
    def validate_resale_price(self, ticket: Ticket, resale_price: float) -> bool:
        """Validate that the resale price is not excessive."""
        return resale_price <= ticket.original_price * self.max_price_increase
    
    def detect_suspicious_activity(self, user_id: UUID) -> bool:
        """Detect suspicious activity that might indicate scalping."""
        # Get user's recent bookings
        recent_bookings = self.booking_repository.find_recent_by_user(
            user_id, 
            since=datetime.now() - timedelta(days=30)
        )
        
        # Check for patterns indicating scalping
        # 1. High volume of purchases
        if len(recent_bookings) > 20:
            return True
        
        # 2. High volume of resales
        resold_tickets = self.ticket_repository.find_resold_by_owner(
            user_id,
            since=datetime.now() - timedelta(days=30)
        )
        
        if len(resold_tickets) > 15:
            return True
        
        # 3. Quick resales after purchase
        for ticket in resold_tickets:
            booking = self.booking_repository.find_by_id(ticket.booking_id)
            if booking and (ticket.updated_at - booking.booking_time).days < 2:
                return True
        
        return False
    
    def flag_user(self, user_id: UUID, reason: str) -> None:
        """Flag a user for suspicious activity."""
        user = self.user_repository.find_by_id(user_id)
        if not user:
            return
        
        # Add flag to user record
        if "flags" not in user.preferences:
            user.preferences["flags"] = []
        
        user.preferences["flags"].append({
            "reason": reason,
            "timestamp": datetime.now().isoformat()
        })
        
        self.user_repository.save(user) 