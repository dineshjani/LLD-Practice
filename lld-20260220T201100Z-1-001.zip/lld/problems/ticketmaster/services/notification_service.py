# notification_service.py
from typing import Dict, Set, Any, List
from datetime import datetime
import uuid
from ..models.booking import Booking
from ..models.user import User
from abc import ABC, abstractmethod
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import smtplib
import requests

class NotificationObserver(ABC):
    @abstractmethod
    def update(self, event_type: str, data: Dict[str, Any]) -> None:
        """Receive update from subject."""
        pass


class EmailNotifier(NotificationObserver):
    def __init__(self, smtp_server="smtp.gmail.com", smtp_port=587, 
                 sender_email="notifications@ticketmaster.com", 
                 sender_password="your_app_password"):
        self.smtp_server = smtp_server
        self.smtp_port = smtp_port
        self.sender_email = sender_email
        self.sender_password = sender_password
    
    def update(self, event_type: str, data: Dict[str, Any]) -> None:
        email = data.get('email')
        if not email:
            return
            
        subject = data.get('subject', 'Notification from Ticketmaster')
        message = data.get('message', '')
        
        try:
            self._send_email(email, subject, message)
            print(f"Email sent to {email}: {subject}")
        except Exception as e:
            print(f"Failed to send email to {email}: {str(e)}")
    
    def _send_email(self, recipient_email: str, subject: str, message: str) -> None:
        msg = MIMEMultipart()
        msg['From'] = self.sender_email
        msg['To'] = recipient_email
        msg['Subject'] = subject
        msg.attach(MIMEText(message, 'plain'))
        
        try:
            server = smtplib.SMTP(self.smtp_server, self.smtp_port)
            server.starttls()
            server.login(self.sender_email, self.sender_password)
            server.send_message(msg)
            server.quit()
        except Exception as e:
            print(f"SMTP Error: {str(e)}")
            raise


class NotificationService:
    def __init__(self):
        self.notifications: List[Dict] = []
        self.observers: Dict[str, Set[NotificationObserver]] = {}
        
        # Register default observers
        self.register_observer("all", EmailNotifier())
        self.register_observer("all", SMSNotifier())
    
    def register_observer(self, event_type: str, observer: NotificationObserver) -> None:
        if event_type not in self.observers:
            self.observers[event_type] = set()
        self.observers[event_type].add(observer)
    
    def remove_observer(self, event_type: str, observer: NotificationObserver) -> None:
        if event_type in self.observers:
            self.observers[event_type].discard(observer)
    
    def notify(self, event_type: str, data: Dict[str, Any]) -> None:
        notification_record = {
            'notification_id': str(uuid.uuid4()),
            'event_type': event_type,
            'data': data,
            'sent_time': datetime.now()
        }
        self.notifications.append(notification_record)
        
        if event_type in self.observers:
            for observer in self.observers[event_type]:
                observer.update(event_type, data)
                
        if "all" in self.observers and event_type != "all":
            for observer in self.observers["all"]:
                observer.update(event_type, data)
    
    def send_booking_confirmation(self, booking: Booking) -> None:
        message = f"Your booking (ID: {booking.bookingId}) is confirmed."
        
        data = {
            "user_id": booking.user.userId,
            "email": booking.user.email,
            "phone": booking.user.phone,
            "subject": "Booking Confirmation",
            "message": message,
            "booking_id": booking.bookingId
        }
        
        self.notify("booking_confirmation", data)
        print(f"Notification sent: {message}")
    
    def send_cancellation_confirmation(self, booking: Booking) -> None:
        message = f"Your booking (ID: {booking.bookingId}) has been cancelled."
        
        data = {
            "user_id": booking.user.userId,
            "email": booking.user.email,
            "phone": booking.user.phone,
            "subject": "Booking Cancellation",
            "message": message,
            "booking_id": booking.bookingId
        }
        
        self.notify("booking_cancellation", data)
        print(f"Notification sent: {message}")


class SMSNotifier(NotificationObserver):
    def __init__(self, api_key="your_sms_api_key", api_secret="your_sms_api_secret"):
        self.api_key = api_key
        self.api_secret = api_secret
        self.sms_api_url = "https://api.sms-provider.com/send"
    
    def update(self, event_type: str, data: Dict[str, Any]) -> None:
        phone = data.get('phone')
        if not phone:
            return
            
        message = data.get('message', '')
        
        try:
            self._send_sms(phone, message)
            print(f"SMS sent to {phone}")
        except Exception as e:
            print(f"Failed to send SMS to {phone}: {str(e)}")
    
    def _send_sms(self, phone_number: str, message: str) -> None:
        payload = {
            'api_key': self.api_key,
            'api_secret': self.api_secret,
            'to': phone_number,
            'text': message
        }
        
        try:
            response = requests.post(self.sms_api_url, json=payload)
            response.raise_for_status()
            
            result = response.json()
            if result.get('status') != 'success':
                raise Exception(f"SMS API error: {result.get('error_message')}")
                
        except requests.exceptions.RequestException as e:
            print(f"SMS API Error: {str(e)}")
            raise

class NotificationService:
    def __init__(self):
        self.notifications: List[Dict] = []
        self.observers: Dict[str, Set[NotificationObserver]] = {}
        
        # Register default observers
        self.register_observer("all", EmailNotifier())
        self.register_observer("all", SMSNotifier())
    
    def register_observer(self, event_type: str, observer: NotificationObserver) -> None:
        if event_type not in self.observers:
            self.observers[event_type] = set()
        self.observers[event_type].add(observer)
    
    def remove_observer(self, event_type: str, observer: NotificationObserver) -> None:
        if event_type in self.observers:
            self.observers[event_type].discard(observer)
    
    def notify(self, event_type: str, data: Dict[str, Any]) -> None:
        notification_record = {
            'notification_id': str(uuid.uuid4()),
            'event_type': event_type,
            'data': data,
            'sent_time': datetime.now()
        }
        self.notifications.append(notification_record)
        
        if event_type in self.observers:
            for observer in self.observers[event_type]:
                observer.update(event_type, data)
                
        if "all" in self.observers and event_type != "all":
            for observer in self.observers["all"]:
                observer.update(event_type, data)
    
    def send_booking_confirmation(self, booking: Booking) -> None:
        message = f"Your booking (ID: {booking.bookingId}) is confirmed."
        
        data = {
            "user_id": booking.user.userId,
            "email": booking.user.email,
            "phone": booking.user.phone,
            "subject": "Booking Confirmation",
            "message": message,
            "booking_id": booking.bookingId
        }
        
        self.notify("booking_confirmation", data)
        print(f"Notification sent: {message}")
    
    def send_cancellation_confirmation(self, booking: Booking) -> None:
        message = f"Your booking (ID: {booking.bookingId}) has been cancelled."
        
        data = {
            "user_id": booking.user.userId,
            "email": booking.user.email,
            "phone": booking.user.phone,
            "subject": "Booking Cancellation",
            "message": message,
            "booking_id": booking.bookingId
        }
        
        self.notify("booking_cancellation", data)
        print(f"Notification sent: {message}")