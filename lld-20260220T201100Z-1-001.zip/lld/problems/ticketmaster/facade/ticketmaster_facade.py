from typing import Dict, List, Optional, Any, Tuple
from uuid import UUID
from datetime import datetime, timedelta

from ..models.venue import Venue
from ..models.seat import Seat
from ..models.user import User
from ..models.booking import Booking, BookingStatus
from ..models.ticket import Ticket, TicketStatus
from ..models.payment import Payment, PaymentStatus, PaymentMethod
from ..models.event import Game
from ..models.event import Event
from ..services.pricing_service import PricingService
from ..services.ticket_service import TicketService
from ..services.venue_service import VenueService
from ..services.booking_service import BookingService
from ..services.anti_scalping_service import AntiScalpingService
from ..services.seat_availability_service import SeatAvailabilityService
from ..services.notification_service import NotificationService
from ..services.payment_service import PaymentService
from ..factory.payment_gateway_factory import PaymentGatewayFactory
from ..services.event_service import EventService

class TicketmasterFacade:
    """
    Facade for the Ticketmaster system that provides a simplified interface
    for client applications to interact with the system.
    """
    
    def __init__(self):
        self.ticket_service = TicketService()
        self.seat_availability_service = SeatAvailabilityService(self.ticket_service)
        self.venue_service = VenueService(self.seat_availability_service)
        self.pricing_service = PricingService(self.ticket_service)
        self.notification_service = NotificationService()
        self.payment_gateway_factory = PaymentGatewayFactory()
        self.payment_service = PaymentService(self.payment_gateway_factory)
        self.booking_service = BookingService(self.notification_service)
        self.event_service = EventService()
        self.anti_scalping_service = AntiScalpingService(
            self.ticket_service, self.booking_service, self.venue_service
        )
        self.reservation_timeout = timedelta(minutes=15)
        self.max_tickets_per_user = 8
        self.max_price_increase = 1.2
    
    # Event-related operations
    def get_all_events(self, 
                      city: Optional[str] = None,
                      venue_id: Optional[UUID] = None,
                      start_date: Optional[datetime] = None,
                      end_date: Optional[datetime] = None,
                      category: Optional[str] = None) -> List[Event]:
        """
        Get all events matching the specified criteria.
        
        Args:
            city: Filter events by city
            venue_id: Filter events by venue
            start_date: Filter events starting after this date
            end_date: Filter events ending before this date
            category: Filter events by category
            
        Returns:
            List of events matching the criteria
        """
        filters = {
            'city': city,
            'venue_id': venue_id,
            'start_date': start_date,
            'end_date': end_date,
            'category': category
        }
        
        return self.event_service.find_events_by_filters(filters)
    
    def get_event_details(self, event_id: UUID) -> Optional[Event]:
        """
        Get detailed information about a specific event.
        
        Args:
            event_id: ID of the event to retrieve
            
        Returns:
            Event details or None if not found
        """
        return self.event_service.find_by_id(event_id)
    
    def create_event(self, event_data: Dict[str, Any], venue_id: UUID) -> Event:
        """Create a new event with tickets for all seats in the venue."""
        return self.event_factory.create_event_with_tickets(event_data, venue_id)
    
    # Venue-related operations
    def search_venues(self, 
                     name: Optional[str] = None,
                     city: Optional[str] = None,
                     state: Optional[str] = None,
                     country: Optional[str] = None) -> List[Venue]:
        """Search for venues based on various criteria."""
        filters = {
            'name': name,
            'city': city,
            'state': state,
            'country': country
        }
        return self.storage.find_venues_by_filters(filters)
    
    def get_venue_details(self, venue_id: UUID) -> Optional[Venue]:
        """Get detailed information about a specific venue."""
        return self.storage.get_venue(venue_id)
    
    def get_venue_seating_layout(self, venue_id: UUID) -> Dict[str, Any]:
        """Get the seating layout for a venue."""
        venue = self.storage.get_venue(venue_id)
        if not venue:
            return {}
        
        return venue.seating_layout
    
    # Ticket and seat-related operations
    def get_available_seats_for_event(self, event_id: UUID) -> List[Seat]:
        """
        Get all available seats for a specific event.
        
        Args:
            event_id: ID of the event to check
            
        Returns:
            List of available seats for the event
        """
        # First, release any expired reservations
        self.seat_availability_service.release_expired_reservations()
        
        # Get all available tickets for the event
        available_tickets = self.ticket_service.find_by_event_and_status(
            event_id, TicketStatus.AVAILABLE
        )
        
        # Get the corresponding seats
        available_seats = []
        for ticket in available_tickets:
            seat = self.venue_service.get_seat_by_id(ticket.seat.seatId)
            if seat:
                # Attach the ticket price to the seat for display purposes
                seat.price = ticket.price
                seat.ticketId = ticket.ticketId
                available_seats.append(seat)
        
        return available_seats
    
    def check_seat_availability(self, event_id: UUID, seat_id: UUID) -> bool:
        """
        Check if a specific seat is available for an event.
        
        Args:
            event_id: ID of the event to check
            seat_id: ID of the seat to check
            
        Returns:
            True if the seat is available, False otherwise
        """
        return self.seat_availability_service.check_seat_availability(event_id, seat_id)
    
    # Booking and payment operations
    def book_seats(self, user_id: UUID, event_id: UUID, seat_ids: List[UUID]) -> Tuple[Booking, List[Ticket]]:
        """
        Book specific seats for an event.
        
        Args:
            user_id: ID of the user making the booking
            event_id: ID of the event to book
            seat_ids: IDs of the seats to book
            
        Returns:
            Tuple containing the booking and the tickets
        """
        # Get the user
        user = self.find_user_by_id(user_id)
        if not user:
            raise ValueError(f"User {user_id} not found")
        
        # Check purchase limits for anti-scalping
        if not self.anti_scalping_service.check_purchase_limit(user_id, event_id, len(seat_ids)):
            raise ValueError("Purchase limit exceeded for this event")
        
        # Check if seats are available
        tickets = []
        for seat_id in seat_ids:
            if not self.check_seat_availability(event_id, seat_id):
                # If any seat is not available, release any tickets already reserved
                for ticket in tickets:
                    self.ticket_service.release_ticket(ticket.ticketId)
                raise ValueError(f"Seat {seat_id} is not available")
            
            # Reserve the ticket
            ticket = self.ticket_service.reserve_ticket(event_id, seat_id, user_id)
            tickets.append(ticket)
        
        # Create the booking
        booking = self.booking_service.create_booking(user, tickets)
        
        return booking, tickets
    
    def confirm_booking(self, booking_id: UUID, payment_method: str, payment_details: Dict[str, Any]) -> Booking:
        """
        Confirm a booking after payment.
        
        Args:
            booking_id: ID of the booking to confirm
            payment_method: Method of payment (e.g., "credit_card", "paypal")
            payment_details: Details of the payment
            
        Returns:
            Updated booking
        """
        # Get the booking
        booking = self.booking_service.find_by_id(booking_id)
        if not booking:
            raise ValueError(f"Booking {booking_id} not found")
        
        # Confirm the booking
        return self.booking_service.confirm_booking(booking, payment_method, payment_details)
    
    def cancel_booking(self, booking_id: UUID) -> Booking:
        """
        Cancel a booking and release the tickets.
        
        Args:
            booking_id: ID of the booking to cancel
            
        Returns:
            Updated booking
        """
        # Get the booking
        booking = self.booking_service.find_by_id(booking_id)
        if not booking:
            raise ValueError(f"Booking {booking_id} not found")
        
        # Cancel the booking
        return self.booking_service.cancel_booking(booking)
    
    def get_user_bookings(self, user_id: UUID) -> List[Booking]:
        """Get all bookings for a user."""
        return self.storage.find_bookings_by_user(user_id)
    
    # Resale operations
    def list_ticket_for_resale(self, ticket_id: UUID, resale_price: float, user_id: UUID) -> Ticket:
        """List a ticket for resale."""
        ticket = self.storage.get_ticket(ticket_id)
        
        if not ticket:
            raise ValueError(f"Ticket {ticket_id} not found")
        
        if ticket.owner_id != user_id:
            raise ValueError("You can only resell tickets you own")
        
        # Validate resale price
        if resale_price > ticket.original_price * self.max_price_increase:
            raise ValueError("Resale price exceeds maximum allowed markup")
        
        # Update ticket for resale
        ticket.status = TicketStatus.RESALE
        ticket.price = resale_price
        
        return self.storage.save_ticket(ticket)
    
    # Season pass operations
    def create_season_pass(self, season_data: Dict[str, Any], venue_id: UUID) -> List[Event]:
        """Create a season pass with multiple events."""
        return self.event_factory.create_season_pass_events(season_data, venue_id)
    
    # Helper methods
    def find_user_by_id(self, user_id: UUID) -> Optional[User]:
        """Find a user by ID."""
        # In a real implementation, this would query a user repository
        # For now, we'll return a mock user
        return User(name="John Doe", email="john@example.com", phone="123-456-7890", account_type="CUSTOMER") 