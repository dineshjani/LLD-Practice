Question: Design a flight ticket booking system like MakeMyTrip where users can search for flights, compare prices, and book tickets.
Key Requirements:
Users should be able to search for flights between cities on specific dates
System should support one-way, round-trip, and multi-city searches
System should display flight options with prices, timings, and layovers
Users should be able to select seats and add-ons (meals, baggage, etc.)
System should support fare comparison across dates and airlines
Follow-up Questions:
How would you design the system to efficiently search across multiple airlines?
How would you implement fare caching to improve search performance?
How would you handle flight schedule changes and notify affected bookings?