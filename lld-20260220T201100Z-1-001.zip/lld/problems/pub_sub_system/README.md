# Publish/Subscribe System Design

Design a distributed publish/subscribe (pub/sub) system or event bus.

## Requirements

### Core Features
- Topic-based message routing
- Publisher and subscriber registration
- Message delivery guarantees
- Subscription management (durable vs. transient)
- Message filtering capabilities
- Support for different message types

### Advanced Features
- Hierarchical topic structure
- Wildcard subscriptions
- Message retention policies
- Dead-letter handling for failed deliveries
- Replay capabilities for durable subscriptions
- Access control and authorization

### Performance Requirements
- Low latency for message delivery
- High throughput for popular topics
- Scalability for large numbers of topics and subscribers
- Reliability with no message loss for durable subscriptions

### System Design Components
1. **Topic Management**
   - Topic creation and deletion
   - Hierarchical topic structure
   - Metadata storage

2. **Subscription Management**
   - Subscriber registration and tracking
   - Subscription types (durable, transient)
   - Offset management for durable subscriptions

3. **Message Routing**
   - Efficient topic matching
   - Wildcard resolution
   - Filtering mechanisms

4. **Message Storage**
   - Persistence for durable subscriptions
   - Retention policy enforcement
   - Message deduplication

5. **Delivery Mechanisms**
   - Push vs. pull delivery models
   - Batching for efficiency
   - Retry policies for failed deliveries

## Implementation Guidelines
- Design for horizontal scalability
- Implement efficient topic matching algorithms
- Consider trade-offs between delivery guarantees and performance
- Use appropriate storage mechanisms for different subscription types
- Implement proper error handling and recovery mechanisms

## Evaluation Criteria
- Correctness of the implementation
- Performance under various workloads
- Handling of edge cases (e.g., slow subscribers)
- Code quality and organization
- Flexibility of the design 